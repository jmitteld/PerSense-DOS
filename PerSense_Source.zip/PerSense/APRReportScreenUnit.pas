unit APRReportScreenUnit;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, Childwin, FileIOUnit;

type
  TAPRReportScreen = class(TMDIChild)
    Panel1: TPanel;
    Panel2: TPanel;
    Panel3: TPanel;
    Panel4: TPanel;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    Label9: TLabel;
    Label10: TLabel;
    Label11: TLabel;
    PaymentCountLabel: TLabel;
    PaymentAmountLabel: TLabel;
    PaymentDateLabel: TLabel;
    APRLabel: TLabel;
    FinanceLabel: TLabel;
    AmountLabel: TLabel;
    TotalLabel: TLabel;
    ExtraLabel1: TLabel;
    ExtraLabel2: TLabel;
    SaveDialog1: TSaveDialog;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormActivate(Sender: TObject);
  protected
    ccosts :real;
    pcosts :real;
    savpayamt: real;
    local_d: real;
    procedure ModifyLoanData();
    procedure RestoreLoanData();
  public
    constructor Create( AOwner: TComponent ); override;
    function GetType(): TScreenType; override;
    procedure OnPrint( Header: string ); override;
    function SaveFile( FileName, ScreenName : string ): boolean; override;
    function CreateReport(): boolean;
  end;

var
  APRReportScreen: TAPRReportScreen;

implementation

uses amortize, amortop, peData, peTypes, Globals, videodat, intsutil,
     APROptionsDlgUnit, Printers, HelpSystemUnit, LogUnit;

{$R *.dfm}
constructor TAPRReportScreen.Create( AOwner: TComponent );
begin
  inherited Create( AOwner );
  ccosts := 0;
  pcosts := 0;
end;

function TAPRReportScreen.GetType(): TScreenType;
begin
  GetType := APRReportType;
end;

procedure TAPRReportScreen.OnPrint( Header: string );
var
  TextHeight: integer;
  UsablePageWidth: integer;
  yPos: integer;
  FontSize: integer;
  yHeaderEnd: integer;
const
  Margin=80;
begin
  Printer.BeginDoc();
  Printer.Canvas.Font.Assign( Font );
  Printer.Canvas.Brush.Color := clWhite;
  Printer.Title := 'Persense APR Report Screen';
  TextHeight := Printer.Canvas.TextHeight( 'Amount' );
  UsablePageWidth := Printer.PageWidth-(2*Margin);
  PrintHeader( Printer, yHeaderEnd, Header );
  yPos := yHeaderEnd + 100;
  yHeaderEnd := yPos;
  FontSize := Printer.Canvas.Font.Size;
  // titles across the top
  Printer.Canvas.Font.Size := 12;
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.05), yPos, '  Annual' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.3), yPos, 'Finance' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.55), yPos, ' Amount' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.8), yPos, ' Total Of' );
  yPos := yPos + Printer.Canvas.TextHeight( 'Height' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.05), yPos, 'Percentage' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.3), yPos, 'Charge' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.55), yPos, 'Financed' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.8), yPos, 'Payments' );
  yPos := yPos + Printer.Canvas.TextHeight( 'Height' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.05), yPos, '   Rate' );
  Printer.Canvas.Font.Size := FontSize;
  yPos := yPos + 2*TextHeight;
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.03), yPos, 'The cost of your credit as' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.28), yPos, 'The dollar amount the credit' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.53), yPos, 'The amount of credit provided' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.78), yPos, 'The amount you will have paid' );
  yPos := yPos + TextHeight;
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.03), yPos, 'a yearly rate' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.28), yPos, 'will cost you' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.53), yPos, 'to you or on your behalf' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.78), yPos, 'after you have made all' );
  yPos := yPos + TextHeight;
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.78), yPos, 'payments as scheduled' );
  yPos := yPos + 2*TextHeight;
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.03), yPos, APRLabel.Caption );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.28), yPos, FinanceLabel.Caption );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.53), yPos, AmountLabel.Caption );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.78), yPos, TotalLabel.Caption );
  yPos := yPos + 2*TextHeight;
  // the boxes that surround
  Printer.Canvas.Pen.Width := 6;
  Printer.Canvas.MoveTo( Margin, yHeaderEnd );
  Printer.Canvas.LineTo( Printer.PageWidth-Margin, yHeaderEnd );
  Printer.Canvas.LineTo( Printer.PageWidth-Margin, yPos );
  Printer.Canvas.LineTo( Margin, yPos );
  Printer.Canvas.LineTo( Margin, yHeaderEnd );
  Printer.Canvas.MoveTo( Trunc( UsablePageWidth * 0.25), yHeaderEnd );
  Printer.Canvas.LineTo( Trunc( UsablePageWidth * 0.25), yPos );
  Printer.Canvas.MoveTo( Trunc( UsablePageWidth * 0.5), yHeaderEnd );
  Printer.Canvas.LineTo( Trunc( UsablePageWidth * 0.5), yPos );
  Printer.Canvas.MoveTo( Trunc( UsablePageWidth * 0.75), yHeaderEnd );
  Printer.Canvas.LineTo( Trunc( UsablePageWidth * 0.75), yPos );
  yPos := yPos + TextHeight;
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.1), yPos, 'Number of regular payments: ' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.35), yPos, PaymentCountLabel.Caption );
  yPos := yPos + TextHeight;
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.1), yPos, 'Amount of regular payments: ' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.35), yPos, PaymentAmountLabel.Caption );
  yPos := yPos + TextHeight;
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.1), yPos, 'When payments are due: ' );
  Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.35), yPos, PaymentDateLabel.Caption );
  Printer.EndDoc();
end;

function TAPRReportScreen.SaveFile( FileName, ScreenName : string ): boolean;
var
  OutFile: TextFile;
  hFile: integer;
  Position: integer;
  bWarnOnOverwrite: boolean;
  bCancelPressed: boolean;
  Extension: string;
  i: integer;
  OutLine: string;
begin
  MasterLog.Write( LVL_LOW, 'TAPRReportScreen.SaveFile' );
  SaveFile := false;
  bWarnOnOverwrite := false;
  if( ScreenName <> '' ) then
    SaveDialog1.Title := 'Save ' + ScreenName + ' As';
  SaveDialog1.Filter := 'Text Files (*.txt)|*.TXT';
  if( FileName = '' ) then begin
    if( not SaveDialog1.Execute() ) then begin
      SaveFile := false;
      exit;
    end;
    bWarnOnOverwrite := true;
    FileName := SaveDialog1.FileName;
  end;
  Position := Pos( '.', FileName );
  if( Position = 0 ) then
    FileName := FileName + '.txt';
  if( not FileExists( FileName ) ) then begin
    hFile := FileCreate( FileName );
    if( hFile = -1 ) then begin
      MasterLog.Write( LVL_MED, 'SaveFile failed to create new file for saving' );
      SaveFile := false;
      exit;
    end;
    FileClose( hFile );
  end else if( bWarnOnOverwrite ) then begin
    MessageBoxWithCancel( 'File Exists, would you like to save over it?', bCancelPressed, DO_OverwriteFile );
    if( bCancelPressed ) then begin
      SaveFile := false;
      exit;
    end;
  end;
  AssignFile( OutFile, FileName );
  Rewrite( OutFile );


  WriteLn( OutFile, '****************************************************************************' );
  WriteLn( OutFile, '* ANNUAL         * FINANCE CHARGE    * AMOUNT FINANCED * TOTAL OF PAYMENTS *' );
  WriteLn( OutFile, '* PERCENTAGE     *                   *                 *                   *' );
  WriteLn( OutFile, '* RATE           *                   *                 * The amount you    *' );
  WriteLn( OutFile, '*                *                   * The amount of   * will have paid    *' );
  WriteLn( OutFile, '* The cost of    * The dollar amount * credit provided * after you have    *' );
  WriteLn( OutFile, '* your credit as * the credit will   * to you or on    * made all payments *' );
  WriteLn( OutFile, '* a yearly rate  * cost you          * your behalf     * as scheduled      *' );
  WriteLn( OutFile, '*                *                   *                 *                   *' );
  OutLine := '* ' + APRLabel.Caption;
  for i:=14-length(APRLabel.Caption) downto 0 do
    OutLine := OutLine + ' ';
  OutLine := OutLine + '* ' + FinanceLabel.Caption;
  for i:=17-length(FinanceLabel.Caption) downto 0 do
    OutLine := OutLine + ' ';
  OutLine := OutLine + '* ' + AMountLabel.Caption;
  for i:=15-length(AMountLabel.Caption) downto 0 do
    OutLine := OutLine + ' ';
  OutLine := OutLine + '* ' + TotalLabel.Caption;
  for i:=17-length(TotalLabel.Caption) downto 0 do
    OutLine := OutLine + ' ';
  OutLine := OutLine + '*';
  WriteLn( OutFile, OutLine );
  WriteLn( OutFile, '****************************************************************************' );
  WriteLn( OutFile, '' );
  OutLine := 'Number of regular payments: ' + PaymentCountLabel.Caption;
  WriteLn( OutFile, OutLine );
  OutLine := 'Amount of regular payments: ' + PaymentAmountLabel.Caption;
  WriteLn( OutFile, OutLine );
  OutLine := 'When payments are due: ' + PaymentDateLabel.Caption;
  WriteLn( OutFile, OutLine );
  CloseFile( OutFile );
end;

//
// The following functions where lifted from APReport.pas
// They seem pretty simple, so I'm figuring no need to include the
// original source.
procedure TAPRReportScreen.ModifyLoanData();
var
  save_balloon :saved_balloon_state;
begin
  h^.points:=h^.points+ccosts/h^.amount;
  h^.pointsstatus:=inp;
  savpayamt:=h^.payamt;
  h^.payamt:=h^.payamt+pcosts;
  local_d := h^.payamt;
  if ((screenstatus and needs_calc)>0) then AMORTIZE.Enter(0);
  if (fancy) then begin
    v_rate:=0; aprvalue:=0;
    save_balloon.Save;
    RepayFancyLoan(p, usap, h^.loandate, h^.firstdate, nil, false, entire, value_calc, 0);
    cumint:=aprvalue-h^.amount*(1-h^.points);
    save_balloon.Restore;
  end else
    cumint:=local_d*h^.nperiods-h^.amount*(1-h^.points);
end;

procedure TAPRReportScreen.RestoreLoanData();
begin
  h^.points:=h^.points-ccosts/h^.amount;
  h^.payamt:=savpayamt;
  local_d:=h^.payamt;
end;

function TAPRReportScreen.CreateReport(): boolean;
var
  Hold: string;
  OutputType: TOutputToType;
begin
  CreateReport := false;
  if (h^.amount<=tiny) then begin
    MessageBox('Loan amount must be positive to compute APR.', DO_LoanAmountMustBePositive);
    exit;
  end;
  Enter( no_tab );
  if( errorflag ) then exit;
  if( not SufficientDataOnScreen() ) then begin
    InsufficientDataMessage( 'APR', DO_InsufficentDataForAPR );
    exit;
  end;
  if (h^.pointsstatus<defp) then begin
    h^.pointsstatus:=defp;
    h^.points:=0;
  end;
  APROptionsDlg.Init( h^.points*100, ccosts, pcosts );
  APROptionsDlg.ShowModal();
  if( APROptionsDlg.ModalResult <> mrOK ) then exit;
  APROptionsDlg.GetResults( h^.points, ccosts, pcosts );
  ModifyLoanData;
  if( errorflag ) then exit;
  if (not EstimateAndRefineAPRWithPoints) then begin
    MessageBox('APR computation did not converge.', DO_APRDidNotConverge);
    RestoreLoanData;
    exit;
  end;
  aprpmtsum:=cumint+h^.amount*(1-h^.points);
  // output time
  APRLabel.caption := ftoa4(h^.apr*100,7);
  FinanceLabel.caption := ftoa2(cumint,10,df.h.commas);
  AmountLabel.caption := ftoa2(h^.amount*(1-h^.points),10,df.h.commas);
  TotalLabel.caption := ftoa2(aprpmtsum,10,df.h.commas);

  PaymentCountLabel.caption := strb(h^.nperiods,0);
  Hold := ftoa2(h^.payamt,10,df.h.commas);
  StripSpaces( Hold );
  PaymentAmountLabel.caption := Hold;
  PaymentDateLabel.caption := PerYrString(h^.peryr,0)+' beginning '+Datestr(h^.firstdate);

  ExtraLabel1.Caption := '';
  ExtraLabel2.Caption := '';
  if (fancy) then begin
    if (mor^.first_repaystatus>empty) or (targ^.targetstatus>empty) or (nlines[AMZChangesBlock]>0) then
      ExtraLabel1.Caption := 'Payment amounts described in attached schedule.';
    if (nballoons>0) or (npre>0) then
      ExtraLabel2.Caption := 'Extra payments as described in attached schedule.';
  end;
  RestoreLoanData();
  OutputType := APROptionsDlg.OutputTo();
  // we're pruposely returning false so the screen
  // won't show up.
  if( OutputType = OutputFile ) then begin
    SaveFile( '', '' );
    exit;
  end else if( OutputType = OutputPrinter ) then begin
    OnPrint( '' );
    exit;
  end;
  // returning true will make the screen appear
  CreateReport := true;
end;

procedure TAPRReportScreen.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
  inherited;
  OnFormClose( Action );
end;

procedure TAPRReportScreen.FormActivate(Sender: TObject);
begin
  inherited;
  Width := 522;
  Height := 320;
end;

end.
