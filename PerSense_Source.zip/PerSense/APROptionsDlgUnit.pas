unit APROptionsDlgUnit;

interface

uses Windows, SysUtils, Classes, Graphics, Forms, Controls, StdCtrls, 
  Buttons, ExtCtrls;

type
  TOutputToType = ( OutputScreen, OutputFile, OutputPrinter );

  TAPROptionsDlg = class(TForm)
    OKBtn: TButton;
    CancelBtn: TButton;
    Bevel1: TBevel;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    PointsEdit: TEdit;
    CostsEdit: TEdit;
    PaymentEdit: TEdit;
    Label4: TLabel;
    OutputComboBox: TComboBox;
    procedure OKBtnClick(Sender: TObject);
  protected
    m_OutputTo: TOutputToType;
  public
    procedure Init( Points, Costs, Payments: real );
    procedure GetResults( var Points: real; var Costs: real; var Payments: real );
    function OutputTo(): TOutputToType;
  end;

var
  APROptionsDlg: TAPROptionsDlg;

implementation

uses peData, Globals;

{$R *.dfm}
procedure TAPROptionsDlg.Init( Points, Costs, Payments: real );
begin
  PointsEdit.Text := ftoa4( Points, 10 );
  CostsEdit.Text := ftoa2( Costs, 10, df.h.commas );
  PaymentEdit.Text := ftoa2( Payments, 10, df.h.commas );
end;

procedure TAPROptionsDlg.GetResults( var Points: real; var Costs: real; var Payments: real );
var
  IsError: boolean;
begin
  Points := (StringFormat2Double( PointsEdit.Text, IsError ))/100.0;
  Costs := StringFormat2Double( CostsEdit.Text, IsError );
  Payments := StringFormat2Double( PaymentEdit.Text, IsError );
end;

function TAPROptionsDlg.OutputTo(): TOutputToType;
begin
  OutputTo := m_OutputTo;
end;

procedure TAPROptionsDlg.OKBtnClick(Sender: TObject);
begin
  if( OutputComboBox.ItemIndex = 0 ) then
    m_OutputTo := OutputScreen
  else if( OutputComboBox.ItemIndex = 1 ) then
    m_OutputTo := OutputFile
  else if( OutputComboBox.ItemIndex = 2 ) then
    m_OutputTo := OutputPrinter;
end;

end.
