program HashCode;
{$apptype CONSOLE}

uses
  WINDOWS,SYSUTILS;


procedure TestVolumeID;
type dword=longword;
var
  VolumeSerialNumber: DWORD;
  MaximumComponentLength: DWORD;
  FileSystemFlags: DWORD;
  SerialNumber: string;
begin
  GetVolumeInformation('C:\',
                       nil,
                       0,
                       @VolumeSerialNumber,
                       MaximumComponentLength,
                       FileSystemFlags,
                       nil,
                       0);
  SerialNumber := IntToHex(HiWord(VolumeSerialNumber), 4) +
                  '-' +
                  IntToHex(LoWord(VolumeSerialNumber), 4);
  writeln(volumeserialnumber,' -> ',serialnumber);
  readln;
end;

begin
TestVolumeID;
end.
