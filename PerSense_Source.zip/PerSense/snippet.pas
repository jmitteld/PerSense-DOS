{ here's the snip of code that is failing somewhere.  Given what
  it is or isn't asking him I can assume it's making it to certain
  points.  I've added comments to show where I think it's succeeding
  and failing }

  if( not Registry.OpenKey(RegKey, TRUE)) then
    // one possible fail point.  The Registry exists in all our target
    // Windows platforms, and the Registry module I used comes with Delphi,
    // so I'm assuming it works well.  Also, if this failed he wouldn't
    // see any of the following dialogs, so I'm assuming it works.
    exit;
  try
    UserName := Registry.ReadString( 'UserName' );
  except
    on ERegistryException do UserName := '';
  end;
  if( UserName = '' ) then begin
    // IF UserName was empty then it would be asking him for his
    // user name every time.  Since he said he only put it in once
    // then I'm assuming that his UserName is being successfully
    // read from the Registry.  This tells me that the Registry 
    // can be read and written to (because I was allowed to write
    // the name in the first place).  This section is clearly NOT
    // being executed on his system.
    RegistrationDialog.SetForName();
    if( RegistrationDialog.ShowModal() <> mrOk ) then exit;
    UserName := RegistrationDialog.GetText();
    if( UserName = '' ) then exit;
  end;
  bHaveUserName := true;
  SerialNumber := ReadHardDriveSerial();
  HashCode := MakeHash( UserName, SerialNumber );
  // here's another possible fail point.  However again it's very difficult
  // to fail given it's just a simple scrambling of the name array and addition
  // of the serial number (no multiplication that could result in zero given
  // a zero input).  Also if it failed here then PerSense would never present
  // him with a Registration Code.  So I'm assuming this does not fail.
  if( HashCode = 0 ) then exit;
  HashString := inttostr( HashCode );
  Registry.WriteString( 'UserName', UserName );
  Registration := NonsenseNumber mod HashCode;
  RegistrationString := inttostr( Registration );
  // okay, we now have the Registration number
  // let's see if the user has a Key
  try
    Key := Registry.ReadString( 'Key' );
  except
    // This is a possible failure that makes some sense.  If Key
    // comes back as an empty string then it will asume it's wrong
    // and ask him for a new one.  What confuses me is that we've 
    // already read the UserName from the SAME registry object and
    // from the same section of the registry.  There's nothing different
    // between the UserName and the Key entires except for their name.  If
    // you can read one, you should be able to read the other.
    on ERegistryException do Key := '';
  end;
  if( Key <> '' ) then begin
    if( Key = RegistrationString ) then
      // this is the success case that isn't being reached.
      m_bIsRegistered := true
    else
      // this is another possible failure case.  Where Key did not equal
      // Registration string.  However I did the numbers with a calculator
      // and they all worked perfectly.  Plus the math is so simple it's
      // hard to imagine what could have gone wrong.
      m_Registration := ScrambleHashCode( HashString );
  end else begin
    // if they don't then create a Registration Number
    // for them to report to us to get a Key
    m_Registration := ScrambleHashCode( HashString );
  end;
