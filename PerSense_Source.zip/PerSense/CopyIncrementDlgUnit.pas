unit CopyIncrementDlgUnit;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, OKCANCL1, StdCtrls, ExtCtrls {OKCANCL1};

type
  TCopyIncrementDlg = class(TOKBottomDlg)
    Label2: TLabel;
    Label3: TLabel;
    RepetitionEdit: TEdit;
    Label1: TLabel;
    PerYrCombo: TComboBox;
    procedure OKBtnClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure RepetitionEditKeyPress(Sender: TObject; var Key: Char);
  public
    function RepetitionCount(): integer;
    function GetPerYr(): real;
  private
    m_Repetition: integer;
    m_PerYr: real;
  end;

var
  CopyIncrementDlg: TCopyIncrementDlg;

implementation

uses peData;

{$R *.dfm}

function TCopyIncrementDlg.RepetitionCount(): integer;
begin
  RepetitionCount := m_Repetition;
end;

procedure TCopyIncrementDlg.OKBtnClick(Sender: TObject);
begin
  inherited;
  if( RepetitionEdit.Text <> '' ) then
    m_Repetition := strtoint(RepetitionEdit.Text)
  else
    m_Repetition := 0;
  if( PerYrCombo.ItemIndex = 0 ) then
    m_PerYr := 52
  else if( PerYrCombo.ItemIndex = 1 ) then
    m_PerYr := 26
  else if( PerYrCombo.ItemIndex = 2 ) then
    m_PerYr := 12
  else if( PerYrCombo.ItemIndex = 3 ) then
    m_PerYr := 6
  else if( PerYrCombo.ItemIndex = 4 ) then
    m_PerYr := 4
  else if( PerYrCombo.ItemIndex = 5 ) then
    m_PerYr := 3
  else if( PerYrCombo.ItemIndex = 6 ) then
    m_PerYr := 2
  else if( PerYrCombo.ItemIndex = 7 ) then
    m_PerYr := 1
  else if( PerYrCombo.ItemIndex = 8 ) then
    m_PerYr := 0.5;
end;

procedure TCopyIncrementDlg.FormCreate(Sender: TObject);
begin
  inherited;
  if( df.c.peryr = 52 ) then
    PerYrCombo.ItemIndex := 0
  else if( df.c.peryr = 26 ) then
    PerYrCombo.ItemIndex := 1
  else if( df.c.peryr = 12 ) then
    PerYrCombo.ItemIndex := 2
  else if( df.c.peryr = 6 ) then
    PerYrCombo.ItemIndex := 3
  else if( df.c.peryr = 4 ) then
    PerYrCombo.ItemIndex := 4
  else if( df.c.peryr = 3 ) then
    PerYrCombo.ItemIndex := 5
  else if( df.c.peryr = 2 ) then
    PerYrCombo.ItemIndex := 6
  else if( df.c.peryr = 1 ) then
    PerYrCombo.ItemIndex := 7;
end;

function TCopyIncrementDlg.GetPerYr(): real;
begin
  GetPerYr := m_PerYr;
end;

procedure TCopyIncrementDlg.RepetitionEditKeyPress(Sender: TObject;
  var Key: Char);
begin
  inherited;
  if( not (((Key>='0') and (Key<='9')) or (Key=#8) or (Key=#13)) ) then
    Key := #0;
end;

end.
