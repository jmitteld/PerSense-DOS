object CopyIncrementDlg: TCopyIncrementDlg
  Left = 798
  Top = 125
  Width = 251
  Height = 226
  Caption = 'Copy and Increment Dates'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = True
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Label2: TLabel
    Left = 16
    Top = 16
    Width = 199
    Height = 26
    Caption = 
      'This function allows you to copy one date and paste it as many i' +
      'ncrementing dates.  '
    WordWrap = True
  end
  object Label3: TLabel
    Left = 16
    Top = 64
    Width = 155
    Height = 13
    Caption = 'Number of times to copy this line:'
    WordWrap = True
  end
  object Label1: TLabel
    Left = 16
    Top = 96
    Width = 180
    Height = 13
    Caption = 'Increment date by this much per copy:'
  end
  object RepetitionEdit: TEdit
    Left = 184
    Top = 64
    Width = 41
    Height = 21
    TabOrder = 0
    OnKeyPress = RepetitionEditKeyPress
  end
  object PerYrCombo: TComboBox
    Left = 48
    Top = 120
    Width = 145
    Height = 21
    Style = csDropDownList
    ItemHeight = 13
    TabOrder = 1
    Items.Strings = (
      '1 week'
      '2 weeks'
      '1 month'
      '2 months'
      '3 months'
      '4 months'
      '6 months'
      '1 year'
      '2 years')
  end
end
