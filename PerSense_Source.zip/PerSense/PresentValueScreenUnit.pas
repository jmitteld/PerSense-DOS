unit PresentValueScreenUnit;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ChildWin, StdCtrls, Grids, PersenseGrid, Presvalu, FileIOUnit,
  peData, peTypes, PresentValueUndoBufferUnit, TableOutUnit, ComCtrls,
  ExtCtrls, PersenseGroupBox;

const
  // LumpSum cols
  LSMDateCol                    = 0;
  LSMAmountCol                  = 1;
  LSMValueCol                   = 2;
  // periodic cols
  PERFromDateCol                = 0;
  PERToDateCol                  = 1;
  PERPerYrCol                   = 2;
  PERAmountCol                  = 3;
  PERCOLACol                    = 4;
  PERValueCol                   = 5;
  // presentval cols
  PRVAsOfCol                    = 0;
  PRVTrueRateCol                = 1;
  PRVLoanRateCol                = 2;
  PRVYieldCol                   = 3;
  PRVValueCol                   = 4;
  // rateline cols
  RTLDateCol                    = 0;
  RTLTrueRateCol                = 1;
  RTLLoanRateCol                = 2;
  RTLYieldCol                   = 3;
  // xpresval cols
  XPRAsOfCol                    = 0;
  XPRComputationCol             = 1;
  XPRValueCol                   = 2;

type
  TPresentValueScreen = class(TMDIChild)
    LumpSumGrid: TPersenseGrid;
    PeriodicGrid: TPersenseGrid;
    PresentValueGrid: TPersenseGrid;
    RatelineGrid: TPersenseGrid;
    XPresValGrid: TPersenseGrid;
    SaveDialog1: TSaveDialog;
    PresentValueStatusBar: TStatusBar;
    Image1: TImage;
    TopBar: TImage;
    Image3: TImage;
    LumpSumBox: TPersenseGroupBox;
    PeriodicBox: TPersenseGroupBox;
    PresentValueBox: TPersenseGroupBox;
    BackgroundImage: TImage;
    RatelineBox: TPersenseGroupBox;
    XPresValBox: TPersenseGroupBox;
    procedure LumpSumGridLeftBeforeGrid(Sender: TObject; var Default: Boolean);
    procedure LumpSumGridRightAfterGrid(Sender: TObject; var Default: Boolean);
    procedure PeriodicGridRightAfterGrid(Sender: TObject; var Default: Boolean);
    procedure PeriodicGridLeftBeforeGrid(Sender: TObject; var Default: Boolean);
    procedure LumpSumGridDownAfterGrid(Sender: TObject);
    procedure PeriodicGridDownAfterGrid(Sender: TObject);
    procedure PresentValueGridUpBeforeGrid(Sender: TObject);
    procedure LumpSumGridCellAfterEdit(Sender: TObject; ACol, ARow: Integer; const Value: String; DataChanged: boolean);
    procedure PeriodicGridCellAfterEdit(Sender: TObject; ACol, ARow: Integer; const Value: String; DataChanged: boolean);
    procedure PresentValueGridCellAfterEdit(Sender: TObject; ACol, ARow: Integer; const Value: String; DataChanged: boolean);
    procedure RatelineGridLeftBeforeGrid(Sender: TObject; var Default: Boolean);
    procedure RatelineGridUpBeforeGrid(Sender: TObject);
    procedure XPresValGridUpBeforeGrid(Sender: TObject);
    procedure XPresValGridLeftBeforeGrid(Sender: TObject; var Default: Boolean);
    procedure RatelineGridRightAfterGrid(Sender: TObject; var Default: Boolean);
    procedure LumpSumGridEditEnterKeyPressed(Sender: TObject; ACol, ARow: Integer; ValueChanged: Boolean; var DefaultAction: Boolean);
    procedure PeriodicGridEditEnterKeyPressed(Sender: TObject; ACol, ARow: Integer; ValueChanged: Boolean; var DefaultAction: Boolean);
    procedure RatelineGridEditEnterKeyPressed(Sender: TObject; ACol, ARow: Integer; ValueChanged: Boolean; var DefaultAction: Boolean);
    procedure PresentValueGridEditEnterKeyPressed(Sender: TObject; ACol, ARow: Integer; ValueChanged: Boolean; var DefaultAction: Boolean);
    procedure XPresValGridEditEnterKeyPressed(Sender: TObject; ACol, ARow: Integer; ValueChanged: Boolean; var DefaultAction: Boolean);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure RatelineGridCellAfterEdit(Sender: TObject; ACol, ARow: Integer; const Value: String; DataChanged: boolean);
    procedure XPresValGridCellAfterEdit(Sender: TObject; ACol, ARow: Integer; const Value: String; DataChanged: boolean);
    procedure LumpSumGridEditCut(Sender: TObject);
    procedure PeriodicGridEditCut(Sender: TObject);
    procedure PresentValueGridEditCut(Sender: TObject);
    procedure RatelineGridEditCut(Sender: TObject);
    procedure XPresValGridEditCut(Sender: TObject);
    procedure LumpSumGridEditCopy(Sender: TObject);
    procedure PeriodicGridEditCopy(Sender: TObject);
    procedure PresentValueGridEditCopy(Sender: TObject);
    procedure RatelineGridEditCopy(Sender: TObject);
    procedure XPresValGridEditCopy(Sender: TObject);
    procedure LumpSumGridEditPaste(Sender: TObject);
    procedure PeriodicGridEditPaste(Sender: TObject);
    procedure PresentValueGridEditPaste(Sender: TObject);
    procedure RatelineGridEditPaste(Sender: TObject);
    procedure XPresValGridEditPaste(Sender: TObject);
    procedure PeriodicGridCellBeforeEdit(Sender: TObject; ACol, ARow: Integer; const Value: String);
    procedure PeriodicGridVerifyCellString(Sender: TObject; ACol, ARow: Integer; Value: String; var IsError: Boolean);
    procedure PresentValueGridVerifyCellString(Sender: TObject; ACol, ARow: Integer; Value: String; var IsError: Boolean);
    procedure RatelineGridVerifyCellString(Sender: TObject; ACol, ARow: Integer; Value: String; var IsError: Boolean);
    procedure FormResize(Sender: TObject);
    procedure LumpSumGridCellBeforeEdit(Sender: TObject; ACol, ARow: Integer; const Value: String);
    procedure LumpSumGridSelectCell(Sender: TObject; ACol, ARow: Integer; var CanSelect: Boolean);
    procedure PeriodicGridSelectCell(Sender: TObject; ACol, ARow: Integer; var CanSelect: Boolean);
    procedure PresentValueGridSelectCell(Sender: TObject; ACol, ARow: Integer; var CanSelect: Boolean);
    procedure RatelineGridSelectCell(Sender: TObject; ACol, ARow: Integer; var CanSelect: Boolean);
    procedure XPresValGridSelectCell(Sender: TObject; ACol, ARow: Integer; var CanSelect: Boolean);
    procedure LumpSumGridIntelligentNextCell(Sender: TObject; ACol,
      ARow: Integer; var bUseSimpleMovement: Boolean);
    procedure PeriodicGridIntelligentNextCell(Sender: TObject; ACol,
      ARow: Integer; var bUseSimpleMovement: Boolean);
    procedure RatelineGridIntelligentNextCell(Sender: TObject; ACol,
      ARow: Integer; var bUseSimpleMovement: Boolean);
    procedure LumpSumGridNoEditEnterKeyPressed(Sender: TObject; ACol,
      ARow: Integer);
    procedure PeriodicGridNoEditEnterKeyPressed(Sender: TObject; ACol,
      ARow: Integer);
    procedure RatelineGridNoEditEnterKeyPressed(Sender: TObject; ACol,
      ARow: Integer);
    procedure PresentValueGridNoEditEnterKeyPressed(Sender: TObject; ACol,
      ARow: Integer);
    procedure XPresValGridNoEditEnterKeyPressed(Sender: TObject; ACol,
      ARow: Integer);
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy(); override;
    function GetType(): TScreenType; override;
    procedure OnCalculate(); override;
    procedure OnHardenValue(); override;
    procedure OnUndo(); override;
    procedure OnRedo(); override;
    procedure OnCut(); override;
    procedure OnCopy(); override;
    procedure OnCopyAndIncrement(); override;
    procedure OnPaste(); override;
    procedure OnDelete(); override;
    procedure OpenFile( var TheFile: TFileIO ); override;
    function SaveFile( FileName, ScreenName : string ): boolean; override;
    function ExportFile(): boolean; override;
    procedure ClearScreen( IsRegistered: boolean ); override;
    procedure ClearRow(); override;
    procedure OnPrint( Header: string ); override;
    procedure PrintInternals( Top: integer; PageHeight: integer; var Bottom: integer );
    procedure OnContextualHelp(); override;
    procedure OnComputationalSettingsChanges( OldSettings: compdefaults; NewSettings: compdefaults ); override;
    procedure SetUISettings( CellColour, OutpCellColour, SelectedColour: TColor; CellFont, OutpCellFont: TFont ); override;
    procedure InsertRow(); override;
    procedure DeleteRow(); override;
    procedure SetCanadianString( NewString: string );
    procedure ToggleAdvanced();
    function AdvancedIsOn(): boolean;
    function IsBackedUpForHelp(): boolean;
    procedure BackupForHelpSystem();
    procedure RestoreFromHelpSystem();
    procedure TableOutput();
    procedure FixRates( OldPerYr: byte );
    procedure SetSettingsString( SettingsString: string );
  protected
    m_UndoBuffer: TPresentValueUndoBuffer;
    m_bBackedUpForHelp: boolean;
    m_HelpBackupLumpSum : lumpsumarray;
    m_HelpBackupPeriodic : periodicarray;
    m_HelpBackupRateLine : ratelinearray;
    m_HelpBackupPresVal : presvalarray;
    m_HelpBackupXPresVal : xpresval;
    m_BackupFileName: string;
    m_BackupCaption: string;
    m_bBackupUnsaved: boolean;
    m_TableOut: TTableOut;
    procedure DoCalculation();
    procedure EmptyAllData();
    procedure CreateTextOutput( var Output: TStringList );
    // getting data to and from the grids
    procedure AssignLumpSumValues( Data: lumpsumarray; ACol, ARow: integer; Value: string; Status: inout );
    procedure LumpSumValues2Grid( Data: LumpSumArray; Grid: TPersenseGrid );
    procedure AssignPeriodicValues( Data: periodicarray; ACol, ARow: integer; Value: string; Status: inout );
    procedure PeriodicValues2Grid( Data: periodicarray; Grid: TPersenseGrid );
    procedure AssignPresentValueValues( Data: presvalarray; ACol, ARow: integer; Value: string; Status: inout );
    procedure PresentValueValues2Grid( Data: presvalarray; Grid: TPersenseGrid );
    procedure AssignRateLineValues( Data: ratelinearray; ACol, ARow: integer; Value: string; Status: inout );
    procedure RateLineValues2Grid( Data: ratelinearray; Grid: TPersenseGrid );
    procedure AssignXPresValValues( Data: xpresvalptr; ACol: integer; Value: string; Status: inout );
    procedure XPresValValues2Grid( Data: xpresvalptr; Grid: TPersenseGrid );
    procedure AllPresentValueData2Grids();
    // per grid functions
    function GetFocusedGrid(): TPersenseGrid;
    // cut
    procedure LumpSumGridCut();
    procedure PeriodicGridCut();
    procedure RateLineGridCut();
    procedure XPresValGridCut();
    procedure PresentValueGridCut();
    // paste
    procedure LumpSumGridPaste();
    procedure PeriodicGridPaste();
    procedure RateLineGridPaste();
    procedure XPresValGridPaste();
    procedure PresentValueGridPaste();
    // delete
    procedure LumpSumGridDelete();
    procedure PeriodicGridDelete();
    procedure RateLineGridDelete();
    procedure XPresValGridDelete();
    procedure PresentValueGridDelete();
    // harden
    procedure HardenLumpSumGrid();
    procedure HardenPeriodicGrid();
    procedure HardenRateLineGrid();
    procedure HardenXPresValGrid();
    procedure HardenPresentValueGrid();
    // moving data
    procedure MoveLumpSumRow( Source, Destination: integer );
    procedure MovePeriodicRow( Source, Destination: integer );
    procedure MoveRateLineRow( Source, Destination: integer );
  end;

var
  PresentValueScreen: TPresentValueScreen;

implementation

uses Globals, intsutil, LogUnit, MAIN, Printers, HelpSystemUnit,
     StrUtils, CopyIncrementDlgUnit;

{$R *.dfm}

constructor TPresentValueScreen.Create(AOwner: TComponent);
var
  i: integer;
  Strings: TStringList;
  CanSelect: boolean;
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.Create begin' );
  inherited Create( AOwner );
  DoubleBuffered := true;
  for i:=1 to maxlines do begin
    GetMem( a[i], sizeof(lumpsum) );
    ZeroLumpSum( lumpsumptr(a[i]) );
    GetMem( b[i], sizeof(periodic) );
    ZeroPeriodic( periodicptr(b[i]) );
    GetMem( cc[i], sizeof(rateline) );
    ZeroRateLine( ratelineptr(cc[i]) );
    GetMem( m_HelpBackupLumpSum[i], sizeof(lumpsum) );
    GetMem( m_HelpBackupPeriodic[i], sizeof(periodic) );
    GetMem( m_HelpBackupRateLine[i], sizeof(rateline) );
  end;
  for i:=1 to presvallines do begin
    GetMem( c[i], sizeof(presval) );
    ZeroPresVal( presvalptr(c[i]) );
    GetMem( m_HelpBackupPresVal[i], sizeof(presval) );
  end;
  GetMem( d, sizeof(xpresval) );
  ZeroXPresVal( xpresvalptr(d) );
  LumpSumGrid.RowCount := maxlines;
  PeriodicGrid.RowCount := maxlines;
  PresentValueGrid.RowCount := presvallines;
  RateLineGrid.RowCount := maxlines;
  LumpSumGrid.SetupColumn( 0, 0.0, ColTypeDate, DateCellLength );
  LumpSumGrid.SetupColumn( 1, 0.25, ColTypeDollar, 15 );
  LumpSumGrid.SetupColumn( 2, 0.55, ColTypeDollar, 15 );
  PeriodicGrid.SetupColumn( 0, 0.0, ColTypeDate, DateCellLength );
  PeriodicGrid.SetupColumn( 1, 0.18, ColTypeDate, DateCellLength );
  PeriodicGrid.SetupColumn( 2, 0.36, ColTypeInt, 2 );
  PeriodicGrid.SetupColumn( 3, 0.42, ColTypeDollar, 14 );
  PeriodicGrid.SetupColumn( 4, 0.62, ColType4Real, 9 );
  PeriodicGrid.SetupColumn( 5, 0.74, ColTypeDollar, 15 );
  PresentValueGrid.SetupColumn( 0, 0.0, ColTypeDate, DateCellLength );
  PresentValueGrid.SetupColumn( 1, 0.2, ColType4Real, 13 );
  PresentValueGrid.SetupColumn( 2, 0.37, ColType4Real, 13 );
  PresentValueGrid.SetupColumn( 3, 0.54, ColType4Real, 13 );
  PresentValueGrid.SetupColumn( 4, 0.69, ColTypeDollar, 16 );
  RatelineGrid.SetupColumn( 0, 0.0, ColTypeDate, DateCellLength );
  RatelineGrid.SetupColumn( 1, 0.24, ColType4Real, 14 );
  RatelineGrid.SetupColumn( 2, 0.48, ColType4Real, 13 );
  RatelineGrid.SetupColumn( 3, 0.73, ColType4Real, 13 );
  RatelineGrid.SetCellReadOnly( 0, 0 );
  XPresValGrid.SetupColumn( 0, 0.0, ColTypeDate, DateCellLength );
  XPresValGrid.SetupColumn( 1, 0.33, ColTypeStringList, 8 );
  XPresValGrid.SetupColumn( 2, 0.66, ColTypeDollar, 18 );
  Strings := TStringList.Create();
  Strings.Add( 'Simple' );
  Strings.Add( 'Compound' );
  XPresValGrid.SetColumnStringList( 1, Strings );
  XPresValGrid.SetCell( 'Compound', XPRComputationCol, 0, inp );
  Strings.Free();
  m_bBackedUpForHelp := false;
  Width := 690;
  Height := 370;
  m_UndoBuffer := TPresentValueUndoBuffer.Create();
  // header boxes
  LumpSumBox.BackgroundColor := $fdfdff;
  LumpSumBox.Color := $d0e8f0;
  LumpSumBox.Font.Color := $206058;
  LumpSumBox.SetCaption( 0, 'Date', '', 0.1 );
  LumpSumBox.SetCaption( 1, 'Amount', '', 0.38 );
  LumpSumBox.SetCaption( 2, 'Value', '', 0.68 );
  PeriodicBox.BackgroundColor := $fdfdff;
  PeriodicBox.Color := $d0e8f0;
  PeriodicBox.Font.Color := $206058;
  PeriodicBox.SetCaption( 0, 'From', '', 0.1 );
  PeriodicBox.SetCaption( 1, 'Through', '', 0.27 );
  PeriodicBox.SetCaption( 2, 'PerYr', '', 0.4 );
  PeriodicBox.SetCaption( 3, 'Amount', '', 0.53 );
  PeriodicBox.SetCaption( 4, 'COLA%', '', 0.7 );
  PeriodicBox.SetCaption( 5, 'Value', '', 0.88 );
  PresentValueBox.BackgroundColor := $fdfdff;
  PresentValueBox.Color := $d0e8f0;
  PresentValueBox.Font.Color := $206058;
  PresentValueBox.SetCaption( 0, '', 'As Of', 0.1 );
  PresentValueBox.SetCaption( 1, 'True', 'Rate %', 0.3 );
  PresentValueBox.SetCaption( 2, 'Loan', 'Rate %', 0.48 );
  PresentValueBox.SetCaption( 3, '', 'Yield %', 0.64 );
  PresentValueBox.SetCaption( 4, '', 'Value', 0.84 );
  RatelineBox.BackgroundColor := $fdfdff;
  RatelineBox.Color := $d0e8f0;
  RatelineBox.Font.Color := $206058;
  RatelineBox.SetCaption( 0, 'Effective', 'Date', 0.15 );
  RatelineBox.SetCaption( 1, 'True', 'Rate %', 0.38 );
  RatelineBox.SetCaption( 2, 'Loan', 'Rate %', 0.6 );
  RatelineBox.SetCaption( 3, '', 'Yield %', 0.8 );
  XPresValBox.BackgroundColor := $fdfdff;
  XPresValBox.Color := $d0e8f0;
  XPresValBox.Font.Color := $206058;
  XPresValBox.SetCaption( 0, '', 'As Of', 0.16 );
  XPresValBox.SetCaption( 1, 'Interest', 'Computation', 0.5 );
  XPresValBox.SetCaption( 2, 'Total', 'Value', 0.8 );
  // must do this to get the status text going
  LumpSumGridSelectCell( Self, 0, 0, CanSelect );
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.Create end' );
end;

destructor TPresentValueScreen.Destroy();
var
  i: integer;
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.Destroy begin' );
  m_UndoBuffer.Destroy();
  for i:=1 to maxlines do begin
    FreeMem( a[i] );
    FreeMem( b[i] );
    FreeMem( cc[i] );
    FreeMem( m_HelpBackupLumpSum[i] );
    FreeMem( m_HelpBackupPeriodic[i] );
    FreeMem( m_HelpBackupRateLine[i] );
  end;
  for i:=1 to presvallines do begin
    FreeMem( c[i] );
    FreeMem( m_HelpBackupPresVal[i] );
  end;
  FreeMem( d );
  m_TableOut.Free();
  inherited Destroy();
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.Destroy end' );
end;

function TPresentValueScreen.GetType(): TScreenType;
begin
  GetType := PresentValueType;
end;

procedure TPresentValueScreen.OnCalculate();
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.OnCalculate' );
  DoCalculation();
  m_UndoBuffer.StoreData( a, b, c, cc, xpresvalptr(d) );
end;

procedure TPresentValueScreen.DoCalculation();
var
  CurrentGrid: TPersenseGrid;
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.DoCalculation' );
  CurrentGrid := GetFocusedGrid();
  if( CurrentGrid <> nil ) then begin
    if( CurrentGrid.EditorMode ) then
      CurrentGrid.EditorMode := false;
  end;
  nlines[PVLLumpSumBlock] := LumpSumGrid.GetUsedRowCount();
  nlines[PVLPeriodicBlock] := PeriodicGrid.GetUsedRowCount();
  if( pvlfancy ) then begin
    nlines[PVLPresValBlock] := RateLineGrid.GetUsedRowCount();
    nlines[PVLXBlock] := XPresValGrid.GetUsedRowCount();
    cc[1].date := earliest;    // not sure why, but these are locked in like this
    cc[1].datestatus := defp;
  end else
    nlines[PVLPresValBlock] := PresentValueGrid.GetUsedRowCount();
  Enter( no_tab );
  AllPresentValueData2Grids();
end;

function TPresentValueScreen.AdvancedIsOn(): boolean;
begin
  AdvancedIsOn := pvlfancy;
end;

procedure TPresentValueScreen.ToggleAdvanced();
var
  FocusedGrid: TPersenseGrid;
begin
  FocusedGrid := GetFocusedGrid();
  if( pvlfancy ) then begin
    // doing this will set the focus to the XPresValGrid
    // so it must come before the LumpSumGrid.SetFocus()
    XPresValGrid.DisableComboBox();
    if( (FocusedGrid=RatelineGrid) or (FocusedGrid=XPresValGrid) ) then
      LumpSumGrid.SetFocus();
  end else begin
    if( FocusedGrid=PresentValueGrid ) then
      LumpSumGrid.SetFocus();
    RateLineGrid.Cells[0,0] := 'XX         ';
  end;
  // hide or show things based on whether or not they should
  // be seen
  RatelineGrid.Visible := not pvlfancy;
  RatelineBox.Visible := not pvlfancy;
  XPresValGrid.Visible := not pvlfancy;
  XPresValBox.Visible := not pvlfancy;
  PresentValueGrid.Visible := pvlfancy;
  PresentValueBox.Visible := pvlfancy;
  pvlfancy := not pvlfancy;
end;

procedure TPresentValueScreen.OnHardenValue();
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.OnHardenValue' );
  if( LumpSumGrid.Focused() ) then
    HardenLumpSumGrid()
  else if( PeriodicGrid.Focused() ) then
    HardenPeriodicGrid();
  if( AdvancedIsOn() ) then begin
    if( RateLineGrid.Focused() ) then
      HardenRateLineGrid()
    else if( XPresValGrid.Focused() ) then
      HardenXPresValGrid();
  end else begin
    if( PresentValueGrid.Focused() ) then
      HardenPresentValueGrid();
  end;
  m_UndoBuffer.StoreData( a, b, c, cc, xpresvalptr(d) );
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.OnUndo();
var
  Success : boolean;
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.OnUndo' );
  m_UndoBuffer.Undo( a, b, c, cc, xpresvalptr(d), Success );
  if( not Success ) then begin
    MasterLog.Write( LVL_LOW, 'Undo1Click failed to Undo' );
    exit;
  end;
  AllPresentValueData2Grids();
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.OnRedo();
var
  Success : boolean;
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.OnRedo' );
  m_UndoBuffer.Redo( a, b, c, cc, xpresvalptr(d), Success );
  if( not Success ) then begin
    MasterLog.Write( LVL_LOW, 'Redo1Click failed to Redo' );
    exit;
  end;
  AllPresentValueData2Grids();
  SetUnsavedData( true );
end;

function TPresentValueScreen.GetFocusedGrid(): TPersenseGrid;
begin
  GetFocusedGrid := nil;
  if( LumpSumGrid.Focused() ) then
    GetFocusedGrid := LumpSumGrid
  else if( PeriodicGrid.Focused() ) then
    GetFocusedGrid := PeriodicGrid;
  if( AdvancedIsOn() ) then begin
    if( RateLineGrid.Focused() ) then
      GetFocusedGrid := RateLineGrid
    else if( XPresValGrid.Focused() ) then
      GetFocusedGrid := XPresValGrid;
  end else begin
    if( PresentValueGrid.Focused() ) then
      GetFocusedGrid := PresentValueGrid;
  end;
end;

procedure TPresentValueScreen.OnCut();
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.OnCut' );
  if( LumpSumGrid.Focused() ) then
    LumpSumGridCut()
  else if( PeriodicGrid.Focused() ) then
    PeriodicGridCut();
  if( AdvancedIsOn() ) then begin
    if( RateLineGrid.Focused() ) then
      RateLineGridCut()
    else if( XPresValGrid.Focused() ) then
      XPresValGridCut();
  end else begin
    if( PresentValueGrid.Focused() ) then
      PresentValueGridCut();
  end;
  m_UndoBuffer.StoreData( a, b, c, cc, xpresvalptr(d) );
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.OnCopy();
var
  Grid: TPersenseGrid;
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.OnCopy' );
  Grid := GetFocusedGrid();
  if( Grid <> nil ) then
    Grid.CopyToClipboard();
end;

procedure TPresentValueScreen.OnCopyAndIncrement();
var
  Grid: TPersenseGrid;
  NewDate: daterec;
  ThroughDate: daterec;
  IsError: boolean;
  Count: integer;
  Info: TList;
  OrigDay: integer;
  ThroughOrigDay: integer;
  i: integer;
  EmptyRow: integer;
  MaxRowToMove: integer;
  PerYr: Real;
  b2Years: boolean;
  SourceRow: integer;
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.OnCopyAndIncrement' );
  Grid := GetFocusedGrid();
  if( (Grid<>LumpSumGrid) and (Grid<>PeriodicGrid) ) then exit;
  SourceRow := Grid.Row;
  // see discussion of what makes a row valid or not in
  // AmortizationScreenUnit.pas
  if( Grid = LumpSumGrid ) then begin
    if( a[SourceRow+1].datestatus = empty ) then begin
      if( not LumpSumIsEmpty( lumpsumptr(a[SourceRow+1]) ) ) then
        exit;
      if( Grid.GetUsedRowCount() <> SourceRow ) then
        exit;
      if( SourceRow=0 ) then
        exit;
      SourceRow := SourceRow-1;
      if( a[SourceRow+1].datestatus=empty ) then
        exit;
    end;
  end else if( Grid = PeriodicGrid ) then begin
    if( b[SourceRow+1].fromdatestatus = empty ) then begin
      if( not PeriodicIsEmpty( periodicptr(b[Grid.Row+1]) ) ) then
        exit;
      if( Grid.GetUsedRowCount() <> SourceRow ) then
        exit;
      if( SourceRow=0 ) then
        exit;
      SourceRow := SourceRow-1;
      if( b[SourceRow+1].fromdatestatus=empty ) then
        exit;
    end;
  end;
  // okay, be it lump sum or periodic, we now have a valid SourceRow
  if( CopyIncrementDlg.ShowModal() <> IDOK ) then exit;
  Count := CopyIncrementDlg.RepetitionCount();
  PerYr := CopyIncrementDlg.GetPerYr();
  if( PerYr = 0.5 ) then begin
    PerYr := 1;
    b2Years := true;
  end else
    b2Years := false;
  NewDate := StringFormat2Date( Grid.Cells[0,SourceRow], IsError );
  OrigDay := NewDate.d;
  EmptyRow := SourceRow+1;
  if( Grid = LumpSumGrid ) then begin
    // stole this code from InsertRow
    for i:=0 to maxlines-1 do begin
      if( not LumpSumIsEmpty( LumpSumPtr(a[i+1]) ) ) then
        MaxRowToMove := i;
    end;
    if( (MaxRowToMove+Count) > Grid.RowCount ) then exit;
    for i:=MaxRowToMove downto EmptyRow do begin
      if( not LumpSumIsEmpty( LumpSumPtr(a[i+1]) ) ) then
        MoveLumpSumRow( i, i+Count );
    end;
    for i:=0 to Count-1 do begin
      if( b2Years ) then
        AddPeriod( NewDate, Trunc(PerYr), OrigDay, false );
      AddPeriod( NewDate, Trunc(PerYr), OrigDay, false );
      LumpSumGrid.CopyRow( SourceRow, SourceRow+i+1 );
      LumpSumGrid.SetCell( DateToStr(NewDate), 0, SourceRow+i+1, inp );
      a[SourceRow+i+2].date := NewDate;
      a[SourceRow+i+2].datestatus := inp;
      a[SourceRow+i+2].amt0 := a[SourceRow+1].amt0;
      a[SourceRow+i+2].amt0status := a[SourceRow+1].amt0status;
      a[SourceRow+i+2].val0 := a[SourceRow+1].val0;
      a[SourceRow+i+2].val0status := a[SourceRow+1].val0status;
    end;
  end else begin
    ThroughDate := StringFormat2Date( Grid.Cells[1,Grid.Row], IsError );
    ThroughOrigDay := ThroughDate.d;
    // stole this code from InsertRow
    for i:=0 to maxlines-1 do begin
      if( not PeriodicIsEmpty( periodicPtr(b[i+1]) ) ) then
        MaxRowToMove := i;
    end;
    if( (MaxRowToMove+Count) > Grid.RowCount ) then exit;
    for i:=MaxRowToMove downto EmptyRow do begin
      if( not PeriodicIsEmpty( periodicPtr(b[i+1]) ) ) then
        MovePeriodicRow( i, i+Count );
    end;
    for i:=0 to Count-1 do begin
      if( b2Years ) then begin
        AddPeriod( NewDate, Trunc(PerYr), OrigDay, false );
        AddPeriod( ThroughDate, Trunc(PerYr), ThroughOrigDay, false );
      end;
      AddPeriod( NewDate, Trunc(PerYr), OrigDay, false );
      AddPeriod( ThroughDate, Trunc(PerYr), ThroughOrigDay, false );
      PeriodicGrid.CopyRow( SourceRow, SourceRow+i+1 );
      PeriodicGrid.SetCell( DateToStr(NewDate), 0, SourceRow+i+1, inp );
      PeriodicGrid.SetCell( DateToStr(ThroughDate), 1, SourceRow+i+1, inp );
      b[SourceRow+i+2].fromdate := NewDate;
      b[SourceRow+i+2].fromdatestatus := inp;
      b[SourceRow+i+2].todate := ThroughDate;
      b[SourceRow+i+2].todatestatus := b[SourceRow+1].todatestatus;
      b[SourceRow+i+2].peryr := b[SourceRow+1].peryr;
      b[SourceRow+i+2].peryrstatus := b[SourceRow+1].peryrstatus;
      b[SourceRow+i+2].amtn := b[SourceRow+1].amtn;
      b[SourceRow+i+2].amtnstatus := b[SourceRow+1].amtnstatus;
      b[SourceRow+i+2].cola := b[SourceRow+1].cola;
      b[SourceRow+i+2].colastatus := b[SourceRow+1].colastatus;
      b[SourceRow+i+2].valn := b[SourceRow+1].valn;
      b[SourceRow+i+2].valnstatus := b[SourceRow+1].valnstatus;
    end;
  end;
  // this operation might have left invalid data on the screen
  // so go ahead and recalc to fix it.
  DoCalculation();
end;

procedure TPresentValueScreen.OnPaste();
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.OnPaste' );
  if( LumpSumGrid.Focused() ) then
    LumpSumGridPaste()
  else if( PeriodicGrid.Focused() ) then
    PeriodicGridPaste();
  if( AdvancedIsOn() ) then begin
    if( RateLineGrid.Focused() ) then
      RateLineGridPaste()
    else if( XPresValGrid.Focused() ) then
      XPresValGridPaste();
  end else begin
    if( PresentValueGrid.Focused() ) then
      PresentValueGridPaste();
  end;
  m_UndoBuffer.StoreData( a, b, c, cc, xpresvalptr(d) );
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.OnDelete();
var
  Grid: TPersenseGrid;
  DelStart, DelEnd: Integer;
  TheText, First, Second: string;
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.OnDelete' );
  Grid := GetFocusedGrid();
  if( Grid = nil ) then exit;
  if( Grid.EditorMode ) then begin
    TheText := Grid.InplaceEditor.Text;
    DelStart := Grid.InplaceEditor.SelStart;
    DelEnd := DelStart + Grid.InplaceEditor.SelLength;
    if( DelStart = DelEnd ) then begin
      First := copy( TheText, 0, DelStart );
      Second := copy( TheText, DelStart+2, length(TheText)-DelStart );
    end else begin
      First := copy( TheText, 0, DelStart );
      Second := copy( TheText, DelEnd+1, length(TheText)-(DelEnd-DelStart) );
    end;
    Grid.InplaceEditor.Text := First + Second;
    Grid.SetEditText( Grid.Col, Grid.Row, Grid.InplaceEditor.Text );
    Grid.InplaceEditor.SelStart := DelStart;
  end else begin
    if( LumpSumGrid.Focused() ) then
      LumpSumGridDelete()
    else if( PeriodicGrid.Focused() ) then
      PeriodicGridDelete();
    if( AdvancedIsOn() ) then begin
      if( RateLineGrid.Focused() ) then
        RateLineGridDelete()
      else if( XPresValGrid.Focused() ) then
        XPresValGridDelete();
    end else begin
      if( PresentValueGrid.Focused() ) then
        PresentValueGridDelete();
    end;
  end;
  m_UndoBuffer.StoreData( a, b, c, cc, xpresvalptr(d) );
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.EmptyAllData();
var
  i: integer;
begin
  for i:=1 to maxlines do begin
    LumpSumGrid.EmptyRow( i-1 );
    ZeroLumpSum( lumpsumptr(a[i]) );
    PeriodicGrid.EmptyRow( i-1 );
    ZeroPeriodic( periodicptr(b[i]) );
    RatelineGrid.EmptyRow( i-1 );
    ZeroRateLine( ratelineptr(cc[i]) );
  end;
  for i:=1 to presvallines do begin
    PresentValueGrid.EmptyRow( i-1 );
    ZeroPresVal( presvalptr(c[i]) );
  end;
  XPresValGrid.EmptyRow( 0 );
  ZeroXPresVal( xpresvalptr(d) );
  XPresValGrid.SetCell( 'Simple', XPRComputationCol, 0, inp );
end;

procedure TPresentValueScreen.OpenFile( var TheFile: TFileIO );
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.OpenFile' );
  EmptyAllData();
  // now fill with new data
  TheFile.GetPresentValueData( a, b, c, cc, xpresvalptr(d) );
  if( not m_bBackedUpForHelp ) then
    m_FileName := TheFile.GetFileName()
  else
    m_FileName := '';
  m_UndoBuffer.StoreData( a, b, c, cc, xpresvalptr(d) );
  // put the screen in the right mode
  if( pvlfancy <> (TheFile.GetFancyByte()=1) ) then begin
    MainForm.CalcPvlToggleAdvancedOptions1Execute(Self);
  end;
  AllPresentValueData2Grids();
  SetUnsavedData( false );
end;

function TPresentValueScreen.SaveFile( FileName, ScreenName : string ): boolean;
var
  TheFile: TFileIO;
  hFile: integer;
  Position: integer;
  bWarnOnOverwrite: boolean;
  bCancelPressed: boolean;
  Extension: string;
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.SaveFile' );
  bWarnOnOverwrite := false;
  if( ScreenName <> '' ) then
    SaveDialog1.Title := 'Save ' + ScreenName + ' As';
  SaveDialog1.Filter := 'Present Value Files (*.pvl)|*.PVL| Comma Seperated (*.csv)|*.CSV';
  if( FileName = '' ) then begin
    if( not SaveDialog1.Execute() ) then begin
      SaveFile := false;
      exit;
    end;
    bWarnOnOverwrite := true;
    FileName := SaveDialog1.FileName;
  end;
  Position := Pos( '.', FileName );
  if( Position = 0 ) then
    FileName := FileName + '.pvl';
  if( not FileExists( FileName ) ) then begin
    hFile := FileCreate( FileName );
    if( hFile = -1 ) then begin
      MasterLog.Write( LVL_MED, 'SaveFile failed to create new file for saving' );
      SaveFile := false;
      exit;
    end;
    FileClose( hFile );
  end else if( bWarnOnOverwrite ) then begin
    MessageBoxWithCancel( 'File Exists, would you like to save over it?', bCancelPressed, DO_OverwriteFile );
    if( bCancelPressed ) then begin
      SaveFile := false;
      exit;
    end;
  end;
  TheFile := TFileIO.Create();
  TheFile.SavePresentValue( FileName, a, b, c, cc, xpresvalptr(d) );
  m_FileName := FileName;
  TheFile.Free();
  SetUnsavedData( false );
  SaveFile := true;
end;

function TPresentValueScreen.ExportFile(): boolean;
var
  TheFile: TFileIO;
  hFile: integer;
  Position: integer;
  bWarnOnOverwrite: boolean;
  bCancelPressed: boolean;
  bIsCSV: boolean;
  Extension: string;
  FileName: string;
  Output: TStringList;
  Settings: string;
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.ExportFile' );
  bWarnOnOverwrite := false;
  SaveDialog1.Title := 'Export Present Value Screen As';
  SaveDialog1.Filter := 'Comma Seperated (*.csv)|*.CSV|Text File (*.txt)|*.TXT';
  if( not SaveDialog1.Execute() ) then begin
    ExportFile := false;
    exit;
  end;
  bWarnOnOverwrite := true;
  FileName := SaveDialog1.FileName;
  Position := Pos( '.', FileName );
  if( Position = 0 ) then begin
    if( SaveDialog1.FilterIndex = 0 ) then begin
      FileName := FileName + '.csv';
      bIsCSV := true;
    end else begin
      FileName := FileName + '.txt';
      bIsCSV := false;
    end;
  end else begin
    Extension := AnsiRightStr( FileName, 3 );
    Extension := AnsiLowerCase( Extension );
    if( Extension = 'csv' ) then
      bIsCSV := true
    else
      bIsCSV := false;
  end;
  if( not FileExists( FileName ) ) then begin
    hFile := FileCreate( FileName );
    if( hFile = -1 ) then begin
      MasterLog.Write( LVL_MED, 'ExportFile failed to create new file for saving' );
      ExportFile := false;
      exit;
    end;
    FileClose( hFile );
  end else if( bWarnOnOverwrite ) then begin
    MessageBoxWithCancel( 'File Exists, would you like to save over it?', bCancelPressed, DO_OverwriteFile );
    if( bCancelPressed ) then begin
      ExportFile := false;
      exit;
    end;
  end;
  TheFile := TFileIO.Create();
  if( bIsCSV ) then
    TheFile.SavePresentValueAsCSV( FileName, a, b, c, cc, xpresvalptr(d),
                                   LumpSumGrid, PeriodicGrid, PresentValueGrid, RateLineGrid, XPresValGrid )
  else begin
    Output := TStringList.Create();
    CreateTextOutput( Output );
    GetPVLSettingsString( Settings );
    Output.Add( '' );
    Output.Add( '' );
    Output.Add( Settings );
    Output.SaveToFile( FileName );
    Output.Free();
  end;
  TheFile.Free();
  SetUnsavedData( false );
  ExportFile := true;
end;

procedure TPresentValueScreen.ClearScreen( IsRegistered: boolean );
var
  RetCode: integer;
begin
  if( IsRegistered and HasUnsavedData() ) then begin
    MessageBoxYesNoCancel( 'Unsaved Present Value data.  Would you like to save?', RetCode, DO_UnsavedMortgage );
    if( RetCode = DLG_YES ) then begin
      if( not SaveFile( GetFileName(), Caption ) ) then
        exit;
    end;
  end;
  EmptyAllData();
  SetUnsavedData( false );
  m_FileName := '';
  Caption := 'Present Value Screen';
end;

procedure TPresentValueScreen.ClearRow();
var
  Grid: TPersenseGrid;
begin
  Grid := GetFocusedGrid();
  Grid.EmptyRow( Grid.Row );
  if( Grid = LumpSumGrid ) then
    ZeroLumpSum( lumpsumptr(a[Grid.Row+1]) )
  else if( Grid = PeriodicGrid ) then
    ZeroPeriodic( periodicptr(b[Grid.Row+1]) )
  else if( Grid = PresentValueGrid ) then
    ZeroPresVal( presvalptr(c[Grid.Row+1]) )
  else if( Grid = RateLineGrid ) then
    ZeroRateLine( ratelineptr(cc[Grid.Row+1]) )
  else if( Grid = XPresValGrid ) then
    ZeroXPresVal( xpresvalptr(d) );
end;

procedure TPresentValueScreen.OnPrint( Header: string );
var
  yPos, yHold: integer;
  UsablePageWidth: integer;
  yHeaderEnd: integer;
  TheRect: TRect;
  PageHeight: integer;
  TextHeight: integer;
  SettingsString: string;
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.OnPrint' );
  GetPVLSettingsString( SettingsString );
  Printer.BeginDoc();
  Printer.Canvas.Font.Assign( Font );
  Printer.Title := 'Persense Present Value Screen';
  TextHeight := Printer.Canvas.TextHeight( 'Amount' );
  PageHeight := Printer.PageHeight - 2*TextHeight;
  PrintHeader( Printer, yHeaderEnd, Header );
  yPos := yHeaderEnd + 2*TextHeight;
  PrintInternals( yPos, PageHeight, yPos );
  Printer.Canvas.TextOut( 0, PageHeight+TextHeight, SettingsString );
  Printer.EndDoc();
end;

procedure TPresentValueScreen.PrintInternals( Top: integer; PageHeight: integer; var Bottom: integer );
var
  yPos, yHold: integer;
  PenWidth: integer;
  LumpRowsPrinted, PeriodicRowsPrinted, ThirdRowsPrinted: integer;
  CurrentLumpRow, CurrentPeriodicRow, CurrentThirdRow: integer;
  LumpCellHeight, PeriodicCellHeight, ThirdCellHeight: integer;
  MaxLumpRowCount, MaxPeriodicRowCount, MaxThirdRowCount: integer;
  BoxTop: integer;
  i: integer;
  TextHeight: integer;
  UsablePageWidth: integer;
  Margin: integer;
  TheRect: TRect;
  SettingsString: string;
begin
  GetPVLSettingsString( SettingsString );
  TextHeight := Printer.Canvas.TextHeight( 'Amount' );
  Margin := trunc(Printer.PageWidth * MarginPercent);
  UsablePageWidth := Printer.PageWidth-(2*Margin);
  yPos := Top;
  // the LumpSum and Periodic rows
  MaxLumpRowCount := 0;
  MaxPeriodicRowCount := 0;
  for i:=1 to maxlines do begin
    if( not LumpSumIsEmpty( lumpsumptr(a[i]) ) ) then
      MaxLumpRowCount := i;
    if( not PeriodicIsEmpty( periodicptr(b[i]) ) ) then
      MaxPeriodicRowCount := i;
  end;
  CurrentLumpRow := 0;
  CurrentPeriodicRow := 0;
  while( (CurrentLumpRow<MaxLumpRowCount) or (CurrentPeriodicRow<MaxPeriodicRowCount) ) do begin
    Printer.Canvas.Brush.Color := clWhite;
    TheRect.Top := yPos;
    TheRect.Left := 0;
    TheRect.Right := UsablePageWidth;
    if( CurrentLumpRow < MaxLumpRowCount ) then begin
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.05), yPos, 'Single Payments' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.05), yPos+Trunc( TextHeight), 'Date' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.15), yPos+Trunc( TextHeight), 'Amount' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.25), yPos+Trunc( TextHeight), 'Value' );
      Printer.Canvas.Pen.Width := 6;
      Printer.Canvas.MoveTo( 0, yPos );
      Printer.Canvas.LineTo( Trunc(UsablePageWidth*0.36), yPos );
      Printer.Canvas.LineTo( Trunc(UsablePageWidth*0.36), yPos+Trunc( 2.5*TextHeight) );
      Printer.Canvas.LineTo( 0, yPos+Trunc( 2.5*TextHeight) );
      Printer.Canvas.LineTo( 0, yPos);
    end;
    if( CurrentPeriodicRow < MaxPeriodicRowCount ) then begin
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.45), yPos, 'Periodic Payments' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.45), yPos+Trunc( TextHeight), 'From' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.55), yPos+Trunc( TextHeight), 'Through' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.63), yPos+Trunc( TextHeight), 'PerYr' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.7), yPos+Trunc( TextHeight), 'Amount' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.8), yPos+Trunc( TextHeight), 'COLA%' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.9), yPos+Trunc( TextHeight), 'Value' );
      Printer.Canvas.Pen.Width := 6;
      Printer.Canvas.MoveTo( Trunc(UsablePageWidth*0.41), yPos );
      Printer.Canvas.LineTo( UsablePageWidth, yPos );
      Printer.Canvas.LineTo( UsablePageWidth, yPos+Trunc( 2.5*TextHeight) );
      Printer.Canvas.LineTo( Trunc(UsablePageWidth*0.41), yPos+Trunc( 2.5*TextHeight) );
      Printer.Canvas.LineTo( Trunc(UsablePageWidth*0.41), yPos);
    end;
    yPos := yPos + trunc(2.5*TextHeight);
    if( CurrentLumpRow < MaxLumpRowCount ) then begin
      LumpCellHeight := PageHeight-yPos-2*Margin;
      LumpSumGrid.Print( CurrentLumpRow, yPos, 0, Trunc(UsablePageWidth*0.36), LumpCellHeight, MaxLumpRowCount, LumpRowsPrinted );
      CurrentLumpRow := CurrentLumpRow + LumpRowsPrinted;
    end else
      LumpCellHeight := 0;
    if( CurrentPeriodicRow < MaxPeriodicRowCount ) then begin
      PeriodicCellHeight := PageHeight-yPos-2*Margin;
      PeriodicGrid.Print( CurrentPeriodicRow, yPos, Trunc(UsablePageWidth*0.41), Trunc(UsablePageWidth*0.59), PeriodicCellHeight, MaxPeriodicRowCount, PeriodicRowsPrinted );
      CurrentPeriodicRow := CurrentPeriodicRow + PeriodicRowsPrinted;
    end else
      PeriodicCellHeight := 0;
    // possibly set up for new page
    if( (CurrentLumpRow < MaxLumpRowCount) or (CurrentPeriodicRow < MaxPeriodicRowCount) ) then begin
      if( PeriodicCellHeight > LumpCellHeight ) then
        TheRect.Bottom := yPos + PeriodicCellHeight
      else
        TheRect.Bottom := yPos + LumpCellHeight;
      Printer.Canvas.MoveTo( TheRect.Left, TheRect.top );
      Printer.Canvas.LineTo( TheRect.Right, TheRect.top );
      Printer.Canvas.LineTo( TheRect.Right, TheRect.Bottom );
      Printer.Canvas.LineTo( TheRect.Left, TheRect.Bottom );
      Printer.Canvas.LineTo( TheRect.Left, TheRect.top );
      Printer.Canvas.TextOut( 0, PageHeight+TextHeight, SettingsString );
      Printer.NewPage();
      yPos := 2*TextHeight;
      TheRect.Top := yPos;
    end else if( PeriodicCellHeight > LumpCellHeight ) then
      yPos := yPos + PeriodicCellHeight
    else
      yPos := yPos + LumpCellHeight;
  end;
  // put in a page break if we need one
  if( (PageHeight-yPos) < 5*TextHeight ) then begin
    TheRect.Bottom := PageHeight;
    Printer.Canvas.MoveTo( TheRect.Left, TheRect.top );
    Printer.Canvas.LineTo( TheRect.Right, TheRect.top );
    Printer.Canvas.LineTo( TheRect.Right, TheRect.Bottom );
    Printer.Canvas.LineTo( TheRect.Left, TheRect.Bottom );
    Printer.Canvas.LineTo( TheRect.Left, TheRect.top );
    Printer.Canvas.TextOut( 0, PageHeight+TextHeight, SettingsString );
    Printer.NewPage();
    yPos := 2*TextHeight;
    TheRect.Top := yPos;
  end else
    yPos := yPos + TextHeight;
  // now print out the rest
  if( pvlfancy ) then begin
    // the XPresVal stuff
    Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.65), yPos, 'Value computed with rate table at left:' );
    Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.7), yPos+TextHeight, 'Interest' );
    Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.55), yPos+2*TextHeight, 'As of' );
    Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.7), yPos+2*TextHeight, 'Computation' );
    Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.9), yPos+2*TextHeight, 'Total Value' );
    Printer.Canvas.Pen.Width := 6;
    Printer.Canvas.MoveTo( Trunc(UsablePageWidth*0.52), yPos );
    Printer.Canvas.LineTo( UsablePageWidth, yPos );
    Printer.Canvas.LineTo( UsablePageWidth, yPos+Trunc(3.5*TextHeight) );
    Printer.Canvas.LineTo( Trunc(UsablePageWidth*0.52), yPos+Trunc(3.5*TextHeight) );
    Printer.Canvas.LineTo( Trunc(UsablePageWidth*0.52), yPos );
    ThirdCellHeight := PageHeight-Trunc(3.5*TextHeight);
    XPresValGrid.Print( 0, yPos+Trunc(3.5*TextHeight), Trunc(UsablePageWidth*0.52), Trunc(UsablePageWidth*0.48), ThirdCellHeight, 1, PeriodicRowsPrinted );
    TheRect.Bottom := yPos+Trunc(3.5*TextHeight) + ThirdCellHeight;
    // now the RateLine Grid
    MaxThirdRowCount := 0;
    for i:=1 to maxlines do begin
      if( not RateLineIsEmpty( ratelineptr(cc[i]) ) ) then
        MaxThirdRowCount := i;
    end;
    CurrentThirdRow := 0;
    while( CurrentThirdRow < MaxThirdRowCount ) do begin
      yHold := yPos;
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.05), yPos, 'Effective' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.2), yPos, 'True' );
      if (df.c.peryr and canadian >0) then
        Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.3), yPos, 'Canadian' )
      else if (df.c.peryr and daily >0) then
        Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.3), yPos, 'Daily' )
      else
        Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.3), yPos, 'Loan' );
      yPos := yPos + TextHeight;
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.05), yPos, 'Date' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.2), yPos, 'Rate %' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.3), yPos, 'Rate %' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.4), yPos, 'Yield %' );
      Printer.Canvas.Pen.Width := 6;
      Printer.Canvas.MoveTo( 0, yHold );
      Printer.Canvas.LineTo( Trunc(UsablePageWidth*0.49), yHold );
      Printer.Canvas.LineTo( Trunc(UsablePageWidth*0.49), yPos + Trunc(1.5*TextHeight) );
      Printer.Canvas.LineTo( 0, yPos + Trunc(1.5*TextHeight) );
      Printer.Canvas.LineTo( 0, yHold );
      yPos := yPos + Trunc(1.5*TextHeight);
      ThirdCellHeight := PageHeight-yPos;
      RateLineGrid.Print( CurrentThirdRow, yPos, 0, Trunc(UsablePageWidth*0.49), ThirdCellHeight, MaxThirdRowCount, ThirdRowsPrinted );
      if( yPos + ThirdCellHeight > TheRect.Bottom ) then
        TheRect.Bottom := yPos + ThirdCellHeight;
      CurrentThirdRow := CurrentThirdRow + ThirdRowsPrinted;
      if( CurrentThirdRow < MaxThirdRowCount ) then begin
        Printer.Canvas.MoveTo( TheRect.Left, TheRect.top );
        Printer.Canvas.LineTo( TheRect.Right, TheRect.top );
        Printer.Canvas.LineTo( TheRect.Right, TheRect.Bottom );
        Printer.Canvas.LineTo( TheRect.Left, TheRect.Bottom );
        Printer.Canvas.LineTo( TheRect.Left, TheRect.top );
        Printer.Canvas.TextOut( 0, PageHeight+TextHeight, SettingsString );
        Printer.NewPage();
        yPos := 2*TextHeight;
        TheRect.Top := yPos;
      end;
    end;
  end else begin
    // now the PresVal Grid
    MaxThirdRowCount := 0;
    for i:=1 to presvallines do begin
      if( not PresValIsEmpty( presvalptr(c[i]) ) ) then
        MaxThirdRowCount := i;
    end;
    CurrentThirdRow := 0;
    while( CurrentThirdRow < MaxThirdRowCount ) do begin
      yHold := yPos;
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.27), yPos, 'Present Value:' );
      yPos := yPos + TextHeight;
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.36), yPos, 'True' );
      if (df.c.peryr and canadian >0) then
        Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.45), yPos, 'Canadian' )
      else if (df.c.peryr and daily >0) then
        Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.45), yPos, 'Daily' )
      else
        Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.45), yPos, 'Loan' );
      yPos := yPos + TextHeight;
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.27), yPos, 'As Of' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.36), yPos, 'Rate %' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.45), yPos, 'Rate %' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.54), yPos, 'Yield %' );
      Printer.Canvas.TextOut( Trunc( UsablePageWidth * 0.7), yPos, 'Value' );
      Printer.Canvas.Pen.Width := 6;
      Printer.Canvas.MoveTo( Trunc(UsablePageWidth*0.25), yHold );
      Printer.Canvas.LineTo( Trunc(UsablePageWidth*0.25) + Trunc(UsablePageWidth*0.5), yHold );
      Printer.Canvas.LineTo( Trunc(UsablePageWidth*0.25) + Trunc(UsablePageWidth*0.5), yPos+Trunc(1.5*TextHeight) );
      Printer.Canvas.LineTo( Trunc(UsablePageWidth*0.25), yPos+Trunc(1.5*TextHeight) );
      Printer.Canvas.LineTo( Trunc(UsablePageWidth*0.25), yHold );
      yPos := yPos + Trunc(1.5*TextHeight);
      ThirdCellHeight := PageHeight-yPos-2*Margin;
      PresentValueGrid.Print( CurrentThirdRow, yPos, Trunc(UsablePageWidth*0.25), Trunc(UsablePageWidth*0.5), ThirdCellHeight, MaxThirdRowCount, ThirdRowsPrinted );
      TheRect.Bottom := yPos + ThirdCellHeight;
      CurrentThirdRow := CurrentThirdRow + ThirdRowsPrinted;
      if( CurrentThirdRow < MaxThirdRowCount ) then begin
        Printer.Canvas.MoveTo( TheRect.Left, TheRect.top );
        Printer.Canvas.LineTo( TheRect.Right, TheRect.top );
        Printer.Canvas.LineTo( TheRect.Right, TheRect.Bottom );
        Printer.Canvas.LineTo( TheRect.Left, TheRect.Bottom );
        Printer.Canvas.LineTo( TheRect.Left, TheRect.top );
        Printer.Canvas.TextOut( 0, PageHeight+TextHeight, SettingsString );
        Printer.NewPage();
        yPos := 2*TextHeight;
        TheRect.Top := yPos;
      end;
    end;
  end;
  Printer.Canvas.MoveTo( TheRect.Left, TheRect.top );
  Printer.Canvas.LineTo( TheRect.Right, TheRect.top );
  Printer.Canvas.LineTo( TheRect.Right, TheRect.Bottom );
  Printer.Canvas.LineTo( TheRect.Left, TheRect.Bottom );
  Printer.Canvas.LineTo( TheRect.Left, TheRect.top );
  Bottom := TheRect.Bottom;
end;

procedure TPresentValueScreen.SetUISettings( CellColour, OutpCellColour, SelectedColour: TColor; CellFont, OutpCellFont: TFont );
begin
  LumpSumGrid.CellBackgroundColor := CellColour;
  LumpSumGrid.OutpCellBackgroundColor := OutpCellColour;
  LumpSumGrid.SelectedCellColor := SelectedColour;
  LumpSumGrid.CellFont := CellFont;
  LumpSumGrid.OutpCellFont := OutpCellFont;
  LumpSumGrid.Repaint();
  PeriodicGrid.CellBackgroundColor := CellColour;
  PeriodicGrid.OutpCellBackgroundColor := OutpCellColour;
  PeriodicGrid.SelectedCellColor := SelectedColour;
  PeriodicGrid.CellFont := CellFont;
  PeriodicGrid.OutpCellFont := OutpCellFont;
  PeriodicGrid.Repaint();
  PresentValueGrid.CellBackgroundColor := CellColour;
  PresentValueGrid.OutpCellBackgroundColor := OutpCellColour;
  PresentValueGrid.SelectedCellColor := SelectedColour;
  PresentValueGrid.CellFont := CellFont;
  PresentValueGrid.OutpCellFont := OutpCellFont;
  PresentValueGrid.Repaint();
  RatelineGrid.CellBackgroundColor := CellColour;
  RatelineGrid.OutpCellBackgroundColor := OutpCellColour;
  RatelineGrid.SelectedCellColor := SelectedColour;
  RatelineGrid.CellFont := CellFont;
  RatelineGrid.OutpCellFont := OutpCellFont;
  RatelineGrid.Repaint();
  XPresValGrid.CellBackgroundColor := CellColour;
  XPresValGrid.OutpCellBackgroundColor := OutpCellColour;
  XPresValGrid.SelectedCellColor := SelectedColour;
  XPresValGrid.CellFont := CellFont;
  XPresValGrid.OutpCellFont := OutpCellFont;
  XPresValGrid.Repaint();
  FormResize( Self );
end;

procedure TPresentValueScreen.FormResize(Sender: TObject);
var
  BottomGroupY: integer;
begin
  TopBar.Width := ClientWidth - Image1.Width - Image3.Width;
  Image3.Left := ClientWidth - Image3.Width;
  BackgroundImage.Width := ClientWidth;
  BottomGroupY := ClientHeight - 150;
  // top boxes
  LumpSumBox.Left := 11;
  LumpSumBox.Width := trunc(ClientWidth*0.4)-11;
  LumpSumBox.Height := BottomGroupY-40;
  LumpSumGrid.Left := 16;
  LumpSumGrid.Width := LumpSumBox.Width-10;
  LumpSumGrid.Height := BottomGroupY-75;
  PeriodicBox.Left := trunc(ClientWidth*0.42);
  PeriodicBox.Width := ClientWidth-PeriodicBox.Left-11;
  PeriodicBox.Height := BottomGroupY-40;
  PeriodicGrid.Left := PeriodicBox.Left+5;
  PeriodicGrid.Width := PeriodicBox.Width-10;
  PeriodicGrid.Height := BottomGroupY-75;
  // bottom grid in simple mode
  PresentValueBox.Top := BottomGroupY;
  PresentValueBox.Height := 120;
  PresentValueBox.Left := trunc(ClientWidth*0.2);
  PresentValueBox.Width := trunc(ClientWidth*0.6);
  PresentValueGrid.Top := BottomGroupY+40;
  PresentValueGrid.Height := PresentValueBox.Height-45;
  PresentValueGrid.Left := PresentValueBox.Left+5;
  PresentValueGrid.Width := PresentValueBox.Width-10;
  // bottom grid in complex mode
  RatelineBox.Top := BottomGroupY;
  RateLineBox.Height := 120;
  RateLineBox.Left := 11;
  RateLineBox.Width := trunc(ClientWidth*0.5)-11;
  RatelineGrid.Top := BottomGroupY+40;
  RatelineGrid.Height := RateLineBox.Height-45;
  RatelineGrid.Left := RatelineBox.Left+5;
  RatelineGrid.Width := RatelineBox.Width-10;
  XPresValBox.Top := BottomGroupY;
  XPresValBox.Height := 75;
  XPresValBox.Left := trunc(ClientWidth*0.52);
  XPresValBox.Width := ClientWidth-XPresValBox.Left-11;
  XPresValGrid.Top := BottomGroupY+40;
  XPresValGrid.Left := XPresValBox.Left+5;
  XPresValGrid.Width := XPresValBox.Width-10;
end;

function TPresentValueScreen.IsBackedUpForHelp(): boolean;
begin
  IsBackedUpForHelp := m_bBackedUpForHelp;
end;

procedure TPresentValueScreen.BackupForHelpSystem();
var
  i: integer;
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.BackupForHelpSystem' );
  m_bBackedUpForHelp := true;
  m_BackupFileName := m_FileName;
  m_BackupCaption := Caption;
  m_bBackupUnsaved := HasUnsavedData();
  for i:=1 to maxlines do begin
    m_HelpBackupLumpSum[i]^ := a[i]^;
    m_HelpBackupPeriodic[i]^ := b[i]^;
    m_HelpBackupRateLine[i]^ := cc[i]^;
  end;
  for i:=1 to presvallines do
    m_HelpBackupPresVal[i]^ := c[i]^;
  m_HelpBackupXPresVal := d^;
  m_FileName := '';
  Caption := 'Present Value Help';
  SetUnsavedData( false );
end;

procedure TPresentValueScreen.RestoreFromHelpSystem();
var
  i: integer;
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.RestoreFromHelpSystem' );
  m_bBackedUpForHelp := false;
  for i:=1 to maxlines do begin
    a[i]^ := m_HelpBackupLumpSum[i]^;
    b[i]^ := m_HelpBackupPeriodic[i]^;
    cc[i]^ := m_HelpBackupRateLine[i]^;
  end;
  for i:=1 to presvallines do
    c[i]^ := m_HelpBackupPresVal[i]^;
  d^ := m_HelpBackupXPresVal;
  AllPresentValueData2Grids();
  m_FileName := m_BackupFileName;
  Caption := m_BackupCaption;
  SetUnsavedData( m_bBackupUnsaved );
end;

procedure TPresentValueScreen.LumpSumGridLeftBeforeGrid(Sender: TObject; var Default: Boolean);
var
  SelectedRect: TGridRect;
begin
  inherited;
  PeriodicGrid.SetFocus();
  SelectedRect := PeriodicGrid.Selection;
  SelectedRect.Left := 5;
  SelectedRect.Right := 5;
  PeriodicGrid.Selection := SelectedRect;
end;

procedure TPresentValueScreen.LumpSumGridRightAfterGrid(Sender: TObject; var Default: Boolean);
var
  SelectedRect: TGridRect;
begin
  inherited;
  PeriodicGrid.SetFocus();
  SelectedRect := PeriodicGrid.Selection;
  SelectedRect.Left := 0;
  SelectedRect.Right := 0;
  PeriodicGrid.Selection := SelectedRect;
end;

procedure TPresentValueScreen.PeriodicGridRightAfterGrid(Sender: TObject; var Default: Boolean);
var
  SelectedRect: TGridRect;
begin
  inherited;
  LumpSumGrid.SetFocus();
  SelectedRect := LumpSumGrid.Selection;
  SelectedRect.Left := 0;
  SelectedRect.Right := 0;
  LumpSumGrid.Selection := SelectedRect;
end;

procedure TPresentValueScreen.PeriodicGridLeftBeforeGrid(Sender: TObject; var Default: Boolean);
var
  SelectedRect: TGridRect;
begin
  inherited;
  LumpSumGrid.SetFocus();
  SelectedRect := LumpSumGrid.Selection;
  SelectedRect.Left := 2;
  SelectedRect.Right := 2;
  LumpSumGrid.Selection := SelectedRect;
end;

procedure TPresentValueScreen.LumpSumGridDownAfterGrid(Sender: TObject);
var
  SelectedRect: TGridRect;
begin
  inherited;
  if( AdvancedIsOn() ) then begin
    SelectedRect := RateLineGrid.Selection;
    if( (SelectedRect.Left=0) and (SelectedRect.Top=0) ) then begin
      SelectedRect.Left := 1;
      SelectedRect.Right := 1;
      RateLineGrid.Selection := SelectedRect;
    end;
    RateLineGrid.SetFocus()
  end else
    PresentValueGrid.SetFocus();
end;

procedure TPresentValueScreen.PeriodicGridDownAfterGrid(Sender: TObject);
var
  SelectedRect: TGridRect;
begin
  inherited;
  if( AdvancedIsOn() ) then begin
    SelectedRect := RateLineGrid.Selection;
    if( (SelectedRect.Left=0) and (SelectedRect.Top=0) ) then begin
      SelectedRect.Left := 1;
      SelectedRect.Right := 1;
      RateLineGrid.Selection := SelectedRect;
    end;
    RateLineGrid.SetFocus()
  end else
    PresentValueGrid.SetFocus();
end;

procedure TPresentValueScreen.PresentValueGridUpBeforeGrid( Sender: TObject);
begin
  inherited;
  PeriodicGrid.SetFocus();
end;

procedure TPresentValueScreen.RatelineGridLeftBeforeGrid(Sender: TObject; var Default: Boolean);
var
  SelectedRect: TGridRect;
begin
  inherited;
  XPresValGrid.SetFocus();
  SelectedRect := XPresValGrid.Selection;
  SelectedRect.Left := 2;
  SelectedRect.Right := 2;
  XPresValGrid.Selection := SelectedRect;
end;

procedure TPresentValueScreen.RatelineGridUpBeforeGrid(Sender: TObject);
begin
  inherited;
  PeriodicGrid.SetFocus();
end;

procedure TPresentValueScreen.RatelineGridRightAfterGrid(Sender: TObject; var Default: Boolean);
var
  SelectedRect: TGridRect;
begin
  inherited;
  XPresValGrid.SetFocus();
  SelectedRect := XPresValGrid.Selection;
  SelectedRect.Left := 0;
  SelectedRect.Right := 0;
  XPresValGrid.Selection := SelectedRect;
end;

procedure TPresentValueScreen.XPresValGridUpBeforeGrid(Sender: TObject);
begin
  inherited;
  PeriodicGrid.SetFocus();
end;

procedure TPresentValueScreen.XPresValGridLeftBeforeGrid(Sender: TObject; var Default: Boolean);
var
  SelectedRect: TGridRect;
begin
  inherited;
  RateLineGrid.SetFocus();
  SelectedRect := RateLineGrid.Selection;
  SelectedRect.Left := 3;
  SelectedRect.Right := 3;
  RateLineGrid.Selection := SelectedRect;
end;

procedure TPresentValueScreen.LumpSumGridCellBeforeEdit(Sender: TObject;
  ACol, ARow: Integer; const Value: String);
begin
  inherited;
  if( ACol = LSMAmountCol ) then begin
    if( a[ARow+1].val0status <> empty ) then
      LumpSumGrid.SetCell( '', LSMValueCol, ARow, empty );
  end else if( ACol = LSMValueCol ) then begin
    if( a[ARow+1].amt0status <> empty ) then
      LumpSumGrid.SetCell( '', LSMAmountCol, ARow, empty );
  end;
end;

procedure TPresentValueScreen.LumpSumGridCellAfterEdit(Sender: TObject; ACol, ARow: Integer; const Value: String; DataChanged: boolean);
begin
  inherited;
  AssignLumpSumValues( a, ACol, ARow, Value, inp );
  if( DataChanged ) then begin
    m_UndoBuffer.StoreData( a, b, c, cc, xpresvalptr(d) );
    SetUnsavedData( true );
  end;
end;

procedure TPresentValueScreen.AssignLumpSumValues( Data: lumpsumarray; ACol, ARow: integer; Value: string; Status: inout );
var
  IsError: boolean;
begin
  case ACol of
    LSMDateCol: begin
      if( Value = '' ) then begin
        Data[ARow+1].date := unkdate;
        Data[ARow+1].datestatus := empty;
        LumpSumGrid.SetCellHardness( ACol, ARow, empty );
      end else begin
        Data[ARow+1].date := StringFormat2Date( Value, IsError );
        Data[ARow+1].datestatus := Status;
        LumpSumGrid.SetCellHardness( ACol, ARow, Status );
      end;
    end;
    LSMAmountCol: begin
      if( Value = '' ) then begin
        Data[ARow+1].amt0 := 0;
        Data[ARow+1].amt0status := empty;
        LumpSumGrid.SetCellHardness( ACol, ARow, empty );
      end else begin
        Data[ARow+1].amt0 := StringFormat2Double( Value, IsError );
        Data[ARow+1].amt0status := Status;
        LumpSumGrid.SetCellHardness( ACol, ARow, Status );
        Data[ARow+1].val0 := 0;
        Data[ARow+1].val0Status := empty;
        LumpSumGrid.SetCell( '', LSMValueCol, ARow, empty );
      end;
    end;
    LSMValueCol: begin
      if( Value = '' ) then begin
        Data[ARow+1].val0 := 0;
        Data[ARow+1].val0status := empty;
        LumpSumGrid.SetCellHardness( ACol, ARow, empty );
      end else begin
        Data[ARow+1].val0 := StringFormat2Double( Value, IsError );
        Data[ARow+1].val0status := Status;
        LumpSumGrid.SetCellHardness( ACol, ARow, Status );
        Data[ARow+1].amt0 := 0;
        Data[ARow+1].amt0Status := empty;
        LumpSumGrid.SetCell( '', LSMAmountCol, ARow, empty );
      end;
    end;
  end;
end;

procedure TPresentValueScreen.LumpSumValues2Grid( Data: LumpSumArray; Grid: TPersenseGrid );
var
  pLumpSum: lumpsumptr;
  i: integer;
  NumStr: string;
begin
  for i:=1 to maxlines do begin
    pLumpSum := lumpsumptr(Data[i]);
    if( not( (i > Grid.GetUsedRowCount()) and LumpSumIsEmpty( pLumpSum )) ) then begin
      if( pLumpSum.datestatus <> empty ) then begin
        NumStr := DateToStr( pLumpSum.date );
        LumpSumGrid.SetCell( NumStr, LSMDateCol, i-1, pLumpSum.datestatus );
      end else
        LumpSumGrid.SetCell( '', LSMDateCol, i-1, empty );

      if( pLumpSum.amt0status <> empty ) then begin
        NumStr := FloatToStr( pLumpSum.amt0 );
        LumpSumGrid.SetCell( NumStr, LSMAmountCol, i-1, pLumpSum.amt0status );
      end else
        LumpSumGrid.SetCell( '', LSMAmountCol, i-1, empty );

      if( pLumpSum.val0status <> empty ) then begin
        NumStr := FloatToStr( pLumpSum.val0 );
        LumpSumGrid.SetCell( NumStr, LSMValueCol, i-1, pLumpSum.val0status );
      end else
        LumpSumGrid.SetCell( '', LSMValueCol, i-1, empty );
    end;
  end;
end;

procedure TPresentValueScreen.PeriodicGridCellBeforeEdit(Sender: TObject;
  ACol, ARow: Integer; const Value: String);
begin
  inherited;
  if( ACol <> PERPerYrCol ) then begin
    if( b[ARow+1].peryrstatus = empty ) then begin
      b[ARow+1].peryrstatus := defp;
      if( (df.c.peryr and CANADIAN) > 0 ) then begin
        b[ARow+1].peryr := 2;
        PeriodicGrid.SetEditText( PERPerYrCol, ARow, '2' );
      end else if( df.c.peryr = DAILY ) then begin
        b[ARow+1].peryr := 12;
        PeriodicGrid.SetEditText( PERPerYrCol, ARow, '12' );
      end else begin
        b[ARow+1].peryr := df.c.peryr;
        PeriodicGrid.SetEditText( PERPerYrCol, ARow, IntToStr( df.c.peryr) );
      end;
    end;
  end;
  if( ACol = PERAmountCol ) then begin
    b[ARow+1].valnstatus := empty;
    b[ARow+1].valn := 0;
    PeriodicGrid.SetCell( '', PERValueCol, ARow, empty );
  end else if( ACol = PERValueCol ) then begin
    b[ARow+1].amtnstatus := empty;
    b[ARow+1].amtn := 0;
    PeriodicGrid.SetCell( '', PERAmountCol, ARow, empty );
  end;
end;

procedure TPresentValueScreen.PeriodicGridCellAfterEdit(Sender: TObject;
  ACol, ARow: Integer; const Value: String; DataChanged: boolean);
begin
  inherited;
  AssignPeriodicValues( b, ACol, ARow, Value, inp );
  if( DataChanged ) then begin
    m_UndoBuffer.StoreData( a, b, c, cc, xpresvalptr(d) );
    SetUnsavedData( true );
  end;
end;

procedure TPresentValueScreen.AssignPeriodicValues( Data: periodicarray; ACol, ARow: integer; Value: string; Status: inout );
var
  IsError: boolean;
  Hold: double;
begin
  case ACol of
    PERFromDateCol: begin
      if( Value = '' ) then begin
        Data[ARow+1].fromdate := unkdate;
        Data[ARow+1].fromdatestatus := empty;
        PeriodicGrid.SetCellHardness( ACol, ARow, empty );
      end else begin
        Data[ARow+1].fromdate := StringFormat2Date( Value, IsError );
        Data[ARow+1].fromdatestatus := Status;
        PeriodicGrid.SetCellHardness( ACol, ARow, Status );
      end;
    end;
    PERToDateCol: begin
      if( Value = '' ) then begin
        Data[ARow+1].todate := unkdate;
        Data[ARow+1].todatestatus := empty;
        PeriodicGrid.SetCellHardness( ACol, ARow, empty );
      end else begin
        Data[ARow+1].todate := StringFormat2Date( Value, IsError );
        Data[ARow+1].todatestatus := Status;
        PeriodicGrid.SetCellHardness( ACol, ARow, Status );
      end;
    end;
    PERPerYrCol: begin
      if( Value = '' ) then begin
        Data[ARow+1].peryr := 0;
        Data[ARow+1].peryrstatus := empty;
        PeriodicGrid.SetCellHardness( ACol, ARow, empty );
      end else begin
        Data[ARow+1].peryr := StringFormat2Int( Value, IsError );
        Data[ARow+1].peryrstatus := Status;
        PeriodicGrid.SetCellHardness( ACol, ARow, Status );
      end;
    end;
    PERAmountCol: begin
      if( Value = '' ) then begin
        Data[ARow+1].amtn := 0;
        Data[ARow+1].amtnstatus := empty;
        PeriodicGrid.SetCellHardness( ACol, ARow, empty );
      end else begin
        Data[ARow+1].amtn := StringFormat2Double( Value, IsError );
        Data[ARow+1].amtnstatus := Status;
        PeriodicGrid.SetCellHardness( ACol, ARow, Status );
      end;
    end;
    PERCOLACol: begin
      if( Value = '' ) then begin
        Data[ARow+1].cola := 0;
        Data[ARow+1].colastatus := empty;
        PeriodicGrid.SetCellHardness( ACol, ARow, empty );
      end else begin
        Hold := StringFormat2Double( Value, IsError )/100.0;
        Data[ARow+1].cola := RateFromYield( Hold, 1 );
        Data[ARow+1].colastatus := Status;
        PeriodicGrid.SetCellHardness( ACol, ARow, Status );
      end;
    end;
    PERValueCol: begin
      if( Value = '' ) then begin
        Data[ARow+1].valn := 0;
        Data[ARow+1].valnstatus := empty;
        PeriodicGrid.SetCellHardness( ACol, ARow, empty );
      end else begin
        Data[ARow+1].valn := StringFormat2Double( Value, IsError );
        Data[ARow+1].valnstatus := Status;
        PeriodicGrid.SetCellHardness( ACol, ARow, Status );
      end;
    end;
  end;
end;

procedure TPresentValueScreen.PeriodicValues2Grid( Data: periodicarray; Grid: TPersenseGrid );
var
  pPeriodic: periodicptr;
  i: integer;
  NumStr: string;
begin
  for i:=1 to maxlines do begin
    pPeriodic := periodicptr(Data[i]);
    if( not( (i > Grid.GetUsedRowCount()) and PeriodicIsEmpty( pPeriodic )) ) then begin
      if( pPeriodic.fromdatestatus <> empty ) then begin
        NumStr := DateToStr( pPeriodic.fromdate );
        PeriodicGrid.SetCell( NumStr, PERFromDateCol, i-1, pPeriodic.fromdatestatus );
      end else
        PeriodicGrid.SetCell( '', PERFromDateCol, i-1, empty );

      if( pPeriodic.todatestatus <> empty ) then begin
        NumStr := DateToStr( pPeriodic.todate );
        PeriodicGrid.SetCell( NumStr, PERToDateCol, i-1, pPeriodic.todatestatus );
      end else
        PeriodicGrid.SetCell( '', PERToDateCol, i-1, empty );

      if( pPeriodic.peryrstatus <> empty ) then begin
        NumStr := IntToStr( pPeriodic.peryr );
        PeriodicGrid.SetCell( NumStr, PERPerYrCol, i-1, pPeriodic.peryrstatus );
      end else
        PeriodicGrid.SetCell( '', PERPerYrCol, i-1, empty );

      if( pPeriodic.amtnstatus <> empty ) then begin
        NumStr := FloatToStr( pPeriodic.amtn );
        PeriodicGrid.SetCell( NumStr, PERAmountCol, i-1, pPeriodic.amtnstatus );
      end else
        PeriodicGrid.SetCell( '', PERAmountCol, i-1, empty );

      if( pPeriodic.colastatus <> empty ) then begin
        NumStr := FloatToStr( YieldFromRate( pPeriodic.cola, 1 )*100 );
        PeriodicGrid.SetCell( NumStr, PERCOLACol, i-1, pPeriodic.colastatus );
      end else
        PeriodicGrid.SetCell( '', PERCOLACol, i-1, empty );

      if( pPeriodic.valnstatus <> empty ) then begin
        NumStr := FloatToStr( pPeriodic.valn );
        PeriodicGrid.SetCell( NumStr, PERValueCol, i-1, pPeriodic.valnstatus );
      end else
        PeriodicGrid.SetCell( '', PERValueCol, i-1, empty );
    end;
  end;
end;

procedure TPresentValueScreen.PresentValueGridCellAfterEdit(
  Sender: TObject; ACol, ARow: Integer; const Value: String; DataChanged: boolean);
begin
  inherited;
  AssignPresentValueValues( c, ACol, ARow, Value, inp );
  if( (ACol=PRVTrueRateCol) or (ACol=PRVLoanRateCol) or (ACol=PRVYieldCol) ) then
    PresentValueValues2Grid( c, PresentValueGrid );
  if( DataChanged ) then begin
    m_UndoBuffer.StoreData( a, b, c, cc, xpresvalptr(d) );
    SetUnsavedData( true );
  end;
end;

procedure TPresentValueScreen.AssignPresentValueValues( Data: presvalarray; ACol, ARow: integer; Value: string; Status: inout );
var
  IsError: boolean;
  Hold: double;
  NumStr: string;
begin
  case ACol of
    PRVAsOfCol: begin
      if( Value = '' ) then begin
        Data[ARow+1].asof := unkdate;
        Data[ARow+1].asofstatus := empty;
        PresentValueGrid.SetCellHardness( ACol, ARow, empty );
      end else begin
        Data[ARow+1].asof := StringFormat2Date( Value, IsError );
        Data[ARow+1].asofstatus := Status;
        PresentValueGrid.SetCellHardness( ACol, ARow, Status );
      end;
    end;
    // because the 3 rate cols all share the same data we have
    // to be a little careful about how they're assigned.  If
    // someone deletes an outp rate, that shouldn't affect
    // the original, stored, inp rate.
    PRVTrueRateCol: begin
      if( Value = '' ) then begin
        if( Data[ARow+1].r.status = fromrate ) then begin
          Data[ARow+1].r.rate := 0;
          Data[ARow+1].r.status := empty;
          PresentValueGrid.SetCellHardness( ACol, ARow, empty );
        end;
      end else begin
        Hold := StringFormat2Double( Value, IsError )/100;
        if( df.c.basis=x365_360 ) then
          Hold := RateFromYield(YieldFromRate(Hold, df.c.peryr) * kicker, df.c.peryr);
        Data[ARow+1].r.rate := Hold;
        Data[ARow+1].r.status := fromrate;
        PresentValueGrid.SetCellHardness( ACol, ARow, inp );
      end;
    end;
    PRVLoanRateCol: begin
      if( Value = '' ) then begin
        if( Data[ARow+1].r.status = fromapr ) then begin
          Data[ARow+1].r.rate := 0;
          Data[ARow+1].r.status := empty;
          PresentValueGrid.SetCellHardness( ACol, ARow, empty );
        end;
      end else begin
        Hold := StringFormat2Double( Value, IsError )/100;
        Data[ARow+1].r.peryr := df.c.peryr;
        if( df.c.basis=x365_360 )then
          Hold := Hold * kicker;
        if( (pvlfancy) and (d.simple) ) then
          Data[ARow+1].r.rate := Hold
        else
          Data[ARow+1].r.rate := RateFromYield(Hold, Data[ARow+1].r.peryr);
        Data[ARow+1].r.status := fromapr;
        PresentValueGrid.SetCellHardness( ACol, ARow, inp );
      end;
    end;
    PRVYieldCol: begin
      if( Value = '' ) then begin
        if( Data[ARow+1].r.status = fromyield ) then begin
          Data[ARow+1].r.rate := 0;
          Data[ARow+1].r.status := empty;
          PresentValueGrid.SetCellHardness( ACol, ARow, empty );
        end;
      end else begin
        Hold := StringFormat2Double( Value, IsError )/100;
        if( (pvlfancy) and (d.simple) ) then
          Data[ARow+1].r.rate := Hold
        else
          Data[ARow+1].r.rate := RateFromYield(Hold, 1);
        Data[ARow+1].r.status := fromyield;
        if( df.c.basis=x365_360 ) then
          Data[ARow+1].r.rate := RateFromYield(YieldFromRate(Data[ARow+1].r.rate, df.c.peryr) * kicker,df.c.peryr);
        PresentValueGrid.SetCellHardness( ACol, ARow, inp );
      end;
    end;
    PRVValueCol: begin
      if( Value = '' ) then begin
        Data[ARow+1].sumvalue := 0;
        Data[ARow+1].sumvaluestatus := empty;
        PresentValueGrid.SetCellHardness( ACol, ARow, empty );
      end else begin
        Data[ARow+1].sumvalue := StringFormat2Double( Value, IsError );
        Data[ARow+1].sumvaluestatus := Status;
        PresentValueGrid.SetCellHardness( ACol, ARow, Status );
      end;
    end;
  end;
end;

procedure TPresentValueScreen.PresentValueValues2Grid( Data: presvalarray; Grid: TPersenseGrid );
var
  pPresVal: presvalptr;
  i: integer;
  NumStr: string;
  Hold: double;
begin
  for i:=1 to presvallines do begin
    pPresVal := presvalptr(Data[i]);
    if( not( (i > Grid.GetUsedRowCount()) and PresValIsEmpty( pPresVal )) ) then begin
      if( pPresVal.asofstatus <> empty ) then begin
        NumStr := DateToStr( pPresVal.asof );
        PresentValueGrid.SetCell( NumStr, PRVAsOfCol, i-1, pPresVal.asofstatus );
      end else
        PresentValueGrid.SetCell( '', PRVAsOfCol, i-1, empty );
      if( pPresVal.r.status <> empty ) then begin
        // true rate
        Hold := pPresVal.r.rate;
        if( df.c.basis=x365_360 )then
          Hold := RateFromYield( YieldFromRate(Hold,df.c.peryr)/kicker,df.c.peryr);
        NumStr := FloatToStr( Hold*100 );
        if( pPresVal.r.status = fromrate ) then
          PresentValueGrid.SetCell( NumStr, PRVTrueRateCol, i-1, inp )
        else
          PresentValueGrid.SetCell( NumStr, PRVTrueRateCol, i-1, outp );
        // loan rate
        Hold := YieldFromRate( pPresVal.r.rate, df.c.peryr );
        if( df.c.basis=x365_360 ) then
          Hold := Hold / kicker;
        NumStr := FloatToStr(100 * Hold);
        if( pPresVal.r.status = fromapr ) then
          PresentValueGrid.SetCell( NumStr, PRVLoanRateCol, i-1, inp )
        else
          PresentValueGrid.SetCell( NumStr, PRVLoanRateCol, i-1, outp );
        // yield
        Hold := pPresVal.r.rate;
        if( df.c.basis=x365_360 )then
          Hold := RateFromYield(YieldFromRate(Hold,df.c.peryr)/kicker,df.c.peryr);
        NumStr := FloatToStr( 100*YieldFromRate(Hold,1) );
        if( pPresVal.r.status = fromyield ) then
          PresentValueGrid.SetCell( NumStr, PRVYieldCol, i-1, inp )
        else
          PresentValueGrid.SetCell( NumStr, PRVYieldCol, i-1, outp );
      end else begin
        PresentValueGrid.SetCell( '', PRVTrueRateCol, i-1, empty );
        PresentValueGrid.SetCell( '', PRVLoanRateCol, i-1, empty );
        PresentValueGrid.SetCell( '', PRVYieldCol, i-1, empty );
      end;
      if( pPresVal.sumvaluestatus <> empty ) then begin
        NumStr := FloatToStr( pPresVal.sumvalue );
        PresentValueGrid.SetCell( NumStr, PRVValueCol, i-1, pPresVal.sumvaluestatus );
      end else
        PresentValueGrid.SetCell( '', PRVValueCol, i-1, empty );
    end;
  end;
end;

procedure TPresentValueScreen.RatelineGridCellAfterEdit(Sender: TObject;
  ACol, ARow: Integer; const Value: String; DataChanged: boolean);
begin
  inherited;
  AssignRateLineValues( cc, ACol, ARow, Value, inp );
  if( (ACol=PRVTrueRateCol) or (ACol=PRVLoanRateCol) or (ACol=PRVYieldCol) ) then
    RateLineValues2Grid( cc, RateLineGrid );
  if( DataChanged ) then begin
    m_UndoBuffer.StoreData( a, b, c, cc, xpresvalptr(d) );
    SetUnsavedData( true );
  end;
end;

procedure TPresentValueScreen.AssignRateLineValues( Data: ratelinearray; ACol, ARow: integer; Value: string; Status: inout );
var
  IsError: boolean;
  Hold: double;
  NumStr: string;
begin
  case ACol of
    RTLDateCol: begin
      if( Value = '' ) then begin
        Data[ARow+1].date := unkdate;
        Data[ARow+1].datestatus := empty;
        RateLineGrid.SetCellHardness( ACol, ARow, empty );
      end else begin
        Data[ARow+1].date := StringFormat2Date( Value, IsError );
        Data[ARow+1].datestatus := Status;
        RateLineGrid.SetCellHardness( ACol, ARow, Status );
      end;
    end;
    // Same thing as PresentValueGrid rates.  If the cell being
    // set to empty is an outp, then don't bother setting the
    // actual rate to 0.
    RTLTrueRateCol: begin
      if( Value = '' ) then begin
        if( Data[ARow+1].r.status = fromrate ) then begin
          Data[ARow+1].r.rate := 0;
          Data[ARow+1].r.status := empty;
          RateLineGrid.SetCellHardness( ACol, ARow, Status );
        end;
      end else begin
        Hold := StringFormat2Double( Value, IsError )/100;
        if( df.c.basis=x365_360 ) then
          Hold := RateFromYield(YieldFromRate(Hold, df.c.peryr) * kicker, df.c.peryr);
        Data[ARow+1].r.rate := Hold;
        Data[ARow+1].r.status := fromrate;
        RateLineGrid.SetCellHardness( ACol, ARow, inp );
      end;
    end;
    RTLLoanRateCol: begin
      if( Value = '' ) then begin
        if( Data[ARow+1].r.status = fromapr ) then begin
          Data[ARow+1].r.rate := 0;
          Data[ARow+1].r.status := empty;
          RateLineGrid.SetCellHardness( ACol, ARow, Status );
        end;
      end else begin
        Hold := StringFormat2Double( Value, IsError )/100;
        Data[ARow+1].r.peryr := df.c.peryr;
        if( df.c.basis=x365_360 )then
          Hold := Hold * kicker;
        if( (pvlfancy) and (d.simple) ) then
          Data[ARow+1].r.rate := Hold
        else
          Data[ARow+1].r.rate := RateFromYield(Hold, Data[ARow+1].r.peryr);
        Data[ARow+1].r.status := fromapr;
        RateLineGrid.SetCellHardness( ACol, ARow, inp );
      end;
    end;
    RTLYieldCol: begin
      if( Value = '' ) then begin
        if( Data[ARow+1].r.status = fromyield ) then begin
          Data[ARow+1].r.rate := 0;
          Data[ARow+1].r.status := empty;
          RateLineGrid.SetCellHardness( ACol, ARow, Status );
        end;
      end else begin
        Hold := StringFormat2Double( Value, IsError )/100;
        if( (pvlfancy) and (d.simple) ) then
          Data[ARow+1].r.rate := Hold
        else
          Data[ARow+1].r.rate := RateFromYield(Hold, 1);
        Data[ARow+1].r.status := fromyield;
        if( df.c.basis=x365_360 ) then
          Data[ARow+1].r.rate := RateFromYield(YieldFromRate(Data[ARow+1].r.rate, df.c.peryr) * kicker,df.c.peryr);
        RateLineGrid.SetCellHardness( ACol, ARow, inp );
      end;
    end;
  end;
end;

procedure TPresentValueScreen.RateLineValues2Grid( Data: ratelinearray; Grid: TPersenseGrid );
var
  pRateLine: ratelineptr;
  i: integer;
  NumStr: string;
  Origstr: string;
  Hold: double;
begin
  for i:=1 to maxlines do begin
    pRateLine := ratelineptr(Data[i]);
    if( not( (i > Grid.GetUsedRowCount()) and RateLineIsEmpty( pRateLine )) ) then begin
      if( (pRateLine.datestatus <> empty) and (i<>1) ) then begin
        NumStr := DateToStr( pRateLine.date );
        RateLineGrid.SetCell( NumStr, RTLDateCol, i-1, pRateLine.datestatus );
      end else begin
        if( i=1 ) then begin
          RateLineGrid.Cells[0,0] := 'XX         ';
        end else
          RateLineGrid.SetCell( '', RTLDateCol, i-1, empty );
      end;
      if( pRateLine.r.status <> empty ) then begin
        // true rate
        Hold := pRateLine.r.rate;
        if( df.c.basis=x365_360 )then
          Hold := RateFromYield( YieldFromRate(Hold,df.c.peryr)/kicker,df.c.peryr);
        NumStr := FloatToStr( Hold*100 );
        OrigStr := NumStr;
        if( pRateLine.r.status = fromrate ) then
          RateLineGrid.SetCell( NumStr, RTLTrueRateCol, i-1, inp )
        else if( d.simple = true ) then
          RateLineGrid.SetCell( OrigStr, RTLTrueRateCol, i-1, inp )
        else
          RateLineGrid.SetCell( NumStr, RTLTrueRateCol, i-1, outp );
        // loan rate
        Hold := YieldFromRate( pRateLine.r.rate, df.c.peryr );
        if( df.c.basis=x365_360 ) then
          Hold := Hold / kicker;
        NumStr := FloatToStr(100 * Hold);
        if( (pRateLine.r.status = fromapr) and (d.simple=false) ) then
          RateLineGrid.SetCell( NumStr, RTLLoanRateCol, i-1, inp )
        else if( d.simple = true ) then
          RateLineGrid.SetCell( OrigStr, RTLLoanRateCol, i-1, inp )
        else
          RateLineGrid.SetCell( NumStr, RTLLoanRateCol, i-1, outp );
        // yield
        Hold := pRateLine.r.rate;
        if( df.c.basis=x365_360 )then
          Hold := RateFromYield(YieldFromRate(Hold,df.c.peryr)/kicker,df.c.peryr);
        NumStr := FloatToStr( 100*YieldFromRate(Hold,1) );
        if( (pRateLine.r.status = fromyield) and (d.simple=false) ) then
          RateLineGrid.SetCell( NumStr, RTLYieldCol, i-1, inp )
        else if( d.simple = true ) then
          RateLineGrid.SetCell( OrigStr, RTLYieldCol, i-1, inp )
        else
          RateLineGrid.SetCell( NumStr, RTLYieldCol, i-1, outp );
      end else begin
        RateLineGrid.SetCell( '', RTLTrueRateCol, i-1, empty );
        RateLineGrid.SetCell( '', RTLLoanRateCol, i-1, empty );
        RateLineGrid.SetCell( '', RTLYieldCol, i-1, empty );
      end;
    end;
  end;
end;

procedure TPresentValueScreen.XPresValGridCellAfterEdit(Sender: TObject;
  ACol, ARow: Integer; const Value: String; DataChanged: boolean);
begin
  inherited;
  AssignXPresValValues( xpresvalptr(d), ACol, Value, inp );
  if( DataChanged ) then begin
    m_UndoBuffer.StoreData( a, b, c, cc, xpresvalptr(d) );
    SetUnsavedData( true );
  end;
end;

procedure TPresentValueScreen.AssignXPresValValues( Data: xpresvalptr; ACol: integer; Value: string; Status: inout );
var
  IsError: boolean;
  i: integer;
begin
  case ACol of
    XPRAsOfCol: begin
      if( Value = '' ) then begin
        Data.xasof := unkdate;
        Data.xasofstatus := empty;
        XPresValGrid.SetCellHardness( ACol, 0, empty );
      end else begin
        Data.xasof := StringFormat2Date( Value, IsError );
        Data.xasofstatus := Status;
        XPresValGrid.SetCellHardness( ACol, 0, Status );
      end;
    end;
    XPRComputationCol: begin
      if( Value = '' ) then begin
        Data.simplestatus := empty;
        XPresValGrid.SetCellHardness( ACol, 0, empty );
      end else begin
        if( Value = 'Simple' ) then begin
          if( Data.simple = false ) then begin
            // the value has changed.  Convert the rates
            for i:=0 to RateLineGrid.GetUsedRowCount()-1 do begin
              if( cc[i+1].r.status = fromapr ) then
                cc[i+1].r.rate := YieldFromRate( cc[i+1].r.rate, cc[i+1].r.peryr )
              else if( cc[i+1].r.status = fromyield ) then
                cc[i+1].r.rate := YieldFromRate( cc[i+1].r.rate, 1 );
            end;
          end;
          Data.simple := true;
        end else begin
          if( Data.simple = true ) then begin
            // the value has changed.  Convert the rates
            for i:=0 to RateLineGrid.GetUsedRowCount()-1 do begin
              if( cc[i+1].r.status = fromapr ) then
                cc[i+1].r.rate := RateFromYield( cc[i+1].r.rate, cc[i+1].r.peryr )
              else if( cc[i+1].r.status = fromyield ) then
                cc[i+1].r.rate := RateFromYield( cc[i+1].r.rate, 1 );
            end;
          end;
          Data.simple := false;
        end;
        Data.simplestatus := Status;
        XPresValGrid.SetCellHardness( ACol, 0, Status );
        // since changing the simple value will change the shown rates in
        // the rateline grid, call XPresValValues2Grid to handle the
        // canging values.
        XPresValValues2Grid( Data, XPresValGrid );
      end;
    end;
    XPRValueCol: begin
      if( Value = '' ) then begin
        Data.xvalue := 0;
        Data.xvaluestatus := empty;
        XPresValGrid.SetCellHardness( ACol, 0, empty );
      end else begin
        Data.xvalue := StringFormat2Double( Value, IsError );
        Data.xvaluestatus := Status;
        XPresValGrid.SetCellHardness( ACol, 0, Status );
      end;
    end;
  end;
end;

procedure TPresentValueScreen.XPresValValues2Grid( Data: xpresvalptr; Grid: TPersenseGrid );
var
  NumStr: string;
begin
  if( Data.xasofstatus <> empty ) then begin
    NumStr := DateToStr( Data.xasof );
    XPresValGrid.SetCell( NumStr, XPRAsOfCol, 0, Data.xasofstatus );
  end else
    XPresValGrid.SetCell( '', XPRAsOfCol, 0, empty );
  if( Data.simple ) then begin
    XPresValGrid.SetCell( 'Simple', XPRComputationCol, 0, Data.simplestatus );
  end else begin
    XPresValGrid.SetCell( 'Compound', XPRComputationCol, 0, Data.simplestatus );
  end;
  if( Data.xvaluestatus <> empty ) then begin
    NumStr := FloatToStr( Data.xvalue );
    XPresValGrid.SetCell( NumStr, XPRValueCol, 0, Data.xvaluestatus );
  end else
    XPresValGrid.SetCell( '', XPRValueCol, 0, empty );
  RateLineValues2Grid( cc, RateLineGrid );
end;

procedure TPresentValueScreen.AllPresentValueData2Grids();
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.AllPresentValueData2Grid' );
  LumpSumValues2Grid( a, LumpSumGrid );
  PeriodicValues2Grid( b, PeriodicGrid );
  if( pvlfancy ) then begin
    RateLineValues2Grid( cc, RateLineGrid );
    XPresValValues2Grid( xpresvalptr(d), XPresValGrid );
  end else
    PresentValueValues2Grid( c, PresentValueGrid );
end;

procedure TPresentValueScreen.LumpSumGridEditEnterKeyPressed(
  Sender: TObject; ACol, ARow: Integer; ValueChanged: Boolean;
  var DefaultAction: Boolean);
begin
  inherited;
  DoCalculation();
  m_UndoBuffer.OverWriteData( a, b, c, cc, xpresvalptr(d) );
  SetUnsavedData( true );
  if( ACol = 1 ) then begin
    DefaultAction := false;
    LumpSumGrid.Col := 0;
    LumpSumGrid.Row := ARow + 1;
  end;
end;

procedure TPresentValueScreen.PeriodicGridEditEnterKeyPressed(
  Sender: TObject; ACol, ARow: Integer; ValueChanged: Boolean;
  var DefaultAction: Boolean);
begin
  inherited;
  DoCalculation();
  m_UndoBuffer.OverWriteData( a, b, c, cc, xpresvalptr(d) );
  SetUnsavedData( true );
  if( ACol = 3 ) then begin
    DefaultAction := false;
    PeriodicGrid.Col := 0;
    PeriodicGrid.Row := ARow + 1;
  end else if( (ACol = PERCOLACol) and (b[ARow+1].fromdatestatus<>empty) and
               (b[ARow+1].todatestatus<>empty) and (b[ARow+1].peryrstatus<>empty) and
               (b[ARow+1].amtnstatus<>empty) ) then begin
    DefaultAction := false;
    PeriodicGrid.Col := 0;
    PeriodicGrid.Row := ARow + 1;
  end;
end;

procedure TPresentValueScreen.RatelineGridEditEnterKeyPressed(
  Sender: TObject; ACol, ARow: Integer; ValueChanged: Boolean;
  var DefaultAction: Boolean);
begin
  inherited;
  DoCalculation();
  m_UndoBuffer.OverWriteData( a, b, c, cc, xpresvalptr(d) );
  SetUnsavedData( true );
  if( ACol = 3 ) then begin
    DefaultAction := false;
    RatelineGrid.Col := 0;
    RatelineGrid.Row := ARow + 1;
  end;
end;

procedure TPresentValueScreen.PresentValueGridEditEnterKeyPressed(
  Sender: TObject; ACol, ARow: Integer; ValueChanged: Boolean;
  var DefaultAction: Boolean);
begin
  inherited;
  DoCalculation();
  m_UndoBuffer.OverWriteData( a, b, c, cc, xpresvalptr(d) );
  SetUnsavedData( true );
  if( ACol = 4 ) then begin
    DefaultAction := false;
    PresentValueGrid.Col := 0;
    PresentValueGrid.Row := ARow + 1;
  end;
end;

procedure TPresentValueScreen.XPresValGridEditEnterKeyPressed(
  Sender: TObject; ACol, ARow: Integer; ValueChanged: Boolean;
  var DefaultAction: Boolean);
begin
  inherited;
  DoCalculation();
  m_UndoBuffer.OverWriteData( a, b, c, cc, xpresvalptr(d) );
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.FormClose' );
  inherited;
  OnFormClose( Action );
end;

procedure TPresentValueScreen.LumpSumGridEditCut(Sender: TObject);
begin OnCut(); end;

procedure TPresentValueScreen.LumpSumGridCut();
var
  ACol, ARow: integer;
  SelectedRect: TGridRect;
begin
  SelectedRect := LumpSumGrid.Selection;
  LumpSumGrid.CutToClipboard();
  for ARow:=SelectedRect.Top to SelectedRect.Bottom do begin
    for ACol:=SelectedRect.Left to SelectedRect.Right do
      AssignLumpSumValues( a, ACol, ARow, '', inp );
  end;
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.PeriodicGridEditCut(Sender: TObject);
begin OnCut(); end;

procedure TPresentValueScreen.PeriodicGridCut();
var
  ACol, ARow: integer;
  SelectedRect: TGridRect;
begin
  SelectedRect := PeriodicGrid.Selection;
  PeriodicGrid.CutToClipboard();
  for ARow:=SelectedRect.Top to SelectedRect.Bottom do begin
    for ACol:=SelectedRect.Left to SelectedRect.Right do
      AssignPeriodicValues( b, ACol, ARow, '', inp );
  end;
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.PresentValueGridEditCut(Sender: TObject);
begin OnCut(); end;

procedure TPresentValueScreen.PresentValueGridCut();
var
  ACol, ARow: integer;
  SelectedRect: TGridRect;
begin
  SelectedRect := PresentValueGrid.Selection;
  PresentValueGrid.CutToClipboard();
  for ARow:=SelectedRect.Top to SelectedRect.Bottom do begin
    for ACol:=SelectedRect.Left to SelectedRect.Right do begin
      if( (ACol<0) or (ARow<0) ) then exit;
      AssignPresentValueValues( c, ACol, ARow, '', inp );
    end;
  end;
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.RatelineGridEditCut(Sender: TObject);
begin OnCut(); end;

procedure TPresentValueScreen.RateLineGridCut();
var
  ACol, ARow: integer;
  SelectedRect: TGridRect;
begin
  SelectedRect := RateLineGrid.Selection;
  RateLineGrid.CutToClipboard();
  for ARow:=SelectedRect.Top to SelectedRect.Bottom do begin
    for ACol:=SelectedRect.Left to SelectedRect.Right do
      AssignRateLineValues( cc, ACol, ARow, '', inp );
  end;
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.XPresValGridEditCut(Sender: TObject);
begin OnCut(); end;

procedure TPresentValueScreen.XPresValGridCut();
var
  ACol: integer;
  SelectedRect: TGridRect;
begin
  SelectedRect := XPresValGrid.Selection;
  XPresValGrid.CutToClipboard();
  for ACol:=SelectedRect.Left to SelectedRect.Right do
    AssignXPresValValues( xpresvalptr(d), ACol, '', inp );
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.LumpSumGridEditCopy(Sender: TObject);
begin OnCopy(); end;

procedure TPresentValueScreen.PeriodicGridEditCopy(Sender: TObject);
begin OnCopy(); end;

procedure TPresentValueScreen.PresentValueGridEditCopy(Sender: TObject);
begin OnCopy(); end;

procedure TPresentValueScreen.RatelineGridEditCopy(Sender: TObject);
begin OnCopy(); end;

procedure TPresentValueScreen.XPresValGridEditCopy(Sender: TObject);
begin OnCopy(); end;

procedure TPresentValueScreen.LumpSumGridEditPaste(Sender: TObject);
begin OnPaste(); end;

procedure TPresentValueScreen.LumpSumGridPaste();
var
  Col, Row: integer;
  PasteRect: TRect;
begin
  LumpSumGrid.PasteFromClipboard( PasteRect );
  for Row:=PasteRect.Top to PasteRect.Bottom do begin
    for Col:=PasteRect.Left to PasteRect.Right do
      AssignLumpSumValues( a, Col, Row, LumpSumGrid.Cells[Col,Row], LumpSumGrid.GetCellHardness(Col, Row) );
  end;
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.PeriodicGridEditPaste(Sender: TObject);
begin OnPaste(); end;

procedure TPresentValueScreen.PeriodicGridPaste();
var
  Col, Row: integer;
  PasteRect: TRect;
begin
  PeriodicGrid.PasteFromClipboard( PasteRect );
  for Row:=PasteRect.Top to PasteRect.Bottom do begin
    for Col:=PasteRect.Left to PasteRect.Right do
      AssignPeriodicValues( b, Col, Row, PeriodicGrid.Cells[Col,Row], PeriodicGrid.GetCellHardness(Col, Row) );
  end;
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.PresentValueGridEditPaste(Sender: TObject);
begin OnPaste(); end;

procedure TPresentValueScreen.PresentValueGridPaste();
var
  Col, Row: integer;
  PasteRect: TRect;
begin
  PresentValueGrid.PasteFromClipboard( PasteRect );
  for Row:=PasteRect.Top to PasteRect.Bottom do begin
    for Col:=PasteRect.Left to PasteRect.Right do
      AssignPresentValueValues( c, Col, Row, PresentValueGrid.Cells[Col,Row], PresentValueGrid.GetCellHardness(Col, Row) );
  end;
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.RatelineGridEditPaste(Sender: TObject);
begin OnPaste(); end;

procedure TPresentValueScreen.RateLineGridPaste();
var
  Col, Row: integer;
  PasteRect: TRect;
begin
  RateLineGrid.PasteFromClipboard( PasteRect );
  for Row:=PasteRect.Top to PasteRect.Bottom do begin
    for Col:=PasteRect.Left to PasteRect.Right do
      AssignRateLineValues( cc, Col, Row, RateLineGrid.Cells[Col,Row], RateLineGrid.GetCellHardness(Col, Row) );
  end;
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.XPresValGridEditPaste(Sender: TObject);
begin OnPaste(); end;

procedure TPresentValueScreen.XPresValGridPaste();
var
  Col: integer;
  PasteRect: TRect;
begin
  XPresValGrid.PasteFromClipboard( PasteRect );
  for Col:=PasteRect.Left to PasteRect.Right do
    AssignXPresValValues( xpresvalptr(d), Col, XPresValGrid.Cells[Col,0], XPresValGrid.GetCellHardness(Col, 0) );
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.LumpSumGridDelete();
var
  ACol, ARow: integer;
  SelectedRect: TGridRect;
begin
  SelectedRect := LumpSumGrid.Selection;
  LumpSumGrid.DeleteSelected();
  for ARow:=SelectedRect.Top to SelectedRect.Bottom do begin
    for ACol:=SelectedRect.Left to SelectedRect.Right do
      AssignLumpSumValues( a, ACol, ARow, '', inp );
  end;
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.PeriodicGridDelete();
var
  ACol, ARow: integer;
  SelectedRect: TGridRect;
begin
  SelectedRect := PeriodicGrid.Selection;
  PeriodicGrid.DeleteSelected();
  for ARow:=SelectedRect.Top to SelectedRect.Bottom do begin
    for ACol:=SelectedRect.Left to SelectedRect.Right do
      AssignPeriodicValues( b, ACol, ARow, '', inp );
  end;
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.PresentValueGridDelete();
var
  ACol, ARow: integer;
  SelectedRect: TGridRect;
begin
  SelectedRect := PresentValueGrid.Selection;
  PresentValueGrid.DeleteSelected();
  for ARow:=SelectedRect.Top to SelectedRect.Bottom do begin
    for ACol:=SelectedRect.Left to SelectedRect.Right do
      AssignPresentValueValues( c, ACol, ARow, '', inp );
  end;
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.RateLineGridDelete();
var
  ACol, ARow: integer;
  SelectedRect: TGridRect;
begin
  SelectedRect := RateLineGrid.Selection;
  RateLineGrid.DeleteSelected();
  for ARow:=SelectedRect.Top to SelectedRect.Bottom do begin
    for ACol:=SelectedRect.Left to SelectedRect.Right do
      AssignRateLineValues( cc, ACol, ARow, '', inp );
  end;
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.XPresValGridDelete();
var
  ACol: integer;
  SelectedRect: TGridRect;
begin
  SelectedRect := XPresValGrid.Selection;
  XPresValGrid.DeleteSelected();
  for ACol:=SelectedRect.Left to SelectedRect.Right do
    AssignXPresValValues( xpresvalptr(d), ACol, '', inp );
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.HardenLumpSumGrid();
var
  ACol, ARow: integer;
begin
  for ARow:=LumpSumGrid.Selection.Top to LumpSumGrid.Selection.Bottom do begin
    if( ARow <= LumpSumGrid.GetUsedRowCount() ) then begin
      for ACol:=LumpSumGrid.Selection.Left to LumpSumGrid.Selection.Right do begin
        case ACol of
          LSMDateCol: a[ARow+1].datestatus := inp;
          LSMAmountCol: begin
            a[ARow+1].amt0status := inp;
            a[ARow+1].amt0 := RoundToPenny( a[ARow+1].amt0 );
          end;
          LSMValueCol: begin
            a[ARow+1].val0status := inp;
            a[ARow+1].val0 := RoundToPenny( a[ARow+1].val0 );
          end;
        end;
      end;
    end;
  end;
  LumpSumValues2Grid( a, LumpSumGrid );
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.HardenPeriodicGrid();
var
  ACol, ARow: integer;
begin
  for ARow:=PeriodicGrid.Selection.Top to PeriodicGrid.Selection.Bottom do begin
    if( ARow <= PeriodicGrid.GetUsedRowCount() ) then begin
      for ACol:=PeriodicGrid.Selection.Left to PeriodicGrid.Selection.Right do begin
        case ACol of
          PERFromDateCol: b[ARow+1].fromdatestatus := inp;
          PERToDateCol: b[ARow+1].todatestatus := inp;
          PERPerYrCol: b[ARow+1].peryrstatus := inp;
          PERAmountCol: begin
            b[ARow+1].amtnstatus := inp;
            b[ARow+1].amtn := RoundToPenny( b[ARow+1].amtn );
          end;
          PERCOLACol: b[ARow+1].colastatus := inp;
          PERValueCol: begin
            b[ARow+1].valnstatus := inp;
            b[ARow+1].valn := RoundToPenny( b[ARow+1].valn );
          end;
        end;
      end;
    end;
  end;
  PeriodicValues2Grid( b, PeriodicGrid );
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.HardenRateLineGrid();
var
  ACol, ARow: integer;
begin
  for ARow:=RateLineGrid.Selection.Top to RateLineGrid.Selection.Bottom do begin
    if( ARow <= RateLineGrid.GetUsedRowCount() ) then begin
      for ACol:=RateLineGrid.Selection.Left to RateLineGrid.Selection.Right do begin
        case ACol of
          RTLDateCol: cc[ARow+1].datestatus := inp;
          RTLTrueRateCol: cc[ARow+1].r.status := fromrate;
          RTLLoanRateCol: cc[ARow+1].r.status := fromapr;
          RTLYieldCol: cc[ARow+1].r.status := fromyield;
        end;
      end;
    end;
  end;
  RateLineValues2Grid( cc, RateLineGrid );
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.HardenXPresValGrid();
var
  ACol: integer;
begin
  for ACol:=XPresValGrid.Selection.Left to XPresValGrid.Selection.Right do begin
    case ACol of
      XPRAsOfCol: d.xasofstatus := inp;
      XPRComputationCol: d.simplestatus := inp;
      XPRValueCol: d.xvaluestatus := inp;
    end;
  end;
  XPresValValues2Grid( xpresvalptr(d), XPresValGrid );
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.HardenPresentValueGrid();
var
  ACol, ARow: integer;
begin
  for ARow:=PresentValueGrid.Selection.Top to PresentValueGrid.Selection.Bottom do begin
    if( ARow <= PresentValueGrid.GetUsedRowCount() ) then begin
      for ACol:=PresentValueGrid.Selection.Left to PresentValueGrid.Selection.Right do begin
        case ACol of
          PRVAsOfCol: c[ARow+1].asofstatus := inp;
          PRVTrueRateCol: c[ARow+1].r.status := fromrate;
          PRVLoanRateCol: c[ARow+1].r.status := fromapr;
          PRVYieldCol: c[ARow+1].r.status := fromyield;
          PRVValueCol: begin
            c[ARow+1].sumvalue := RoundToPenny( c[ARow+1].sumvalue );
            c[ARow+1].sumvaluestatus := inp;
          end;
        end;
      end;
    end;
  end;
  PresentValueValues2Grid( c, PresentValueGrid );
  SetUnsavedData( true );
end;

procedure TPresentValueScreen.PeriodicGridVerifyCellString(Sender: TObject;
  ACol, ARow: Integer; Value: String; var IsError: Boolean);
var
  DoubleVal: double;
begin
  IsError := false;
  case ACol of
    PERPerYrCol: begin
      DoubleVal := StringFormat2Double( Value, IsError );
      if( IsError ) then exit;
      if( (DoubleVal<>1) and (DoubleVal<>2) and (DoubleVal<>3) and
          (DoubleVal<>4) and (DoubleVal<>6) and (DoubleVal<>12) and
          (DoubleVal<>24) and (DoubleVal<>26) and (DoubleVal<>52) ) then begin
        MainForm.SetStatusBarErrorText( 'Per Year must one of 1, 2, 3, 4, 6, 12, 24, 26, or 52' );
        IsError := true;
      end;
    end;
    PERCOLACol: begin
      DoubleVal := StringFormat2Double( Value, IsError );
      if( IsError ) then exit;
      if( (DoubleVal>=100.00) or (DoubleVal<=-100) ) then begin
        MainForm.SetStatusBarErrorText( 'COLA% must be between -100 and 100' );
        IsError := true;
      end;
    end;
  end;
end;

procedure TPresentValueScreen.PresentValueGridVerifyCellString(
  Sender: TObject; ACol, ARow: Integer; Value: String;
  var IsError: Boolean);
var
  DoubleVal: double;
begin
  IsError := false;
  if( (ACol=PRVTrueRateCol) or (ACol=PRVLoanRateCol) or (ACol=PRVYieldCol) ) then begin
    DoubleVal := StringFormat2Double( Value, IsError );
    if( IsError ) then exit;
    if( (DoubleVal>=100.00) or (DoubleVal<=-100) ) then begin
      MainForm.SetStatusBarErrorText( 'Rate must be between -100 and 100' );
      IsError := true;
    end;
  end;
end;

procedure TPresentValueScreen.RatelineGridVerifyCellString(Sender: TObject;
  ACol, ARow: Integer; Value: String; var IsError: Boolean);
var
  DoubleVal: double;
begin
  IsError := false;
  if( (ACol=RTLTrueRateCol) or (ACol=RTLLoanRateCol) or (ACol=RTLYieldCol) ) then begin
    DoubleVal := StringFormat2Double( Value, IsError );
    if( IsError ) then exit;
    if( (DoubleVal>=100.00) or (DoubleVal<=-100) ) then begin
      MainForm.SetStatusBarErrorText( 'Rate must be between -100 and 100' );
      IsError := true;
    end;
  end;
end;

procedure TPresentValueScreen.TableOutput();
var
  Output: TStringList;
  ScreenCopy: TStringList;
  Line1, Line2: string;
  bSendToFile: boolean;
  bCommaSeperated: boolean;
  FileName: string;
  Position: integer;
  hFile: integer;
  bCancelPressed: boolean;
  bSendToPrinter: boolean;
  pCurrentGrid: TPersenseGrid;
  Settings: string;
  i: integer;
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.TableOutput' );
  pCurrentGrid := GetFocusedGrid();
  if( pCurrentGrid <> nil ) then begin
    if( pCurrentGrid.EditorMode ) then
      pCurrentGrid.EditorMode := false;
  end;
  // the make table function needs the nlines variables
  nlines[PVLLumpSumBlock] := LumpSumGrid.GetUsedRowCount();
  nlines[PVLPeriodicBlock] := PeriodicGrid.GetUsedRowCount();
  if( pvlfancy ) then begin
    nlines[PVLPresValBlock] := RateLineGrid.GetUsedRowCount();
    nlines[PVLXBlock] := XPresValGrid.GetUsedRowCount();
    cc[1].date := earliest;    // not sure why, but these are locked in like this
    cc[1].datestatus := defp;
  end else
    nlines[PVLPresValBlock] := PresentValueGrid.GetUsedRowCount();
  // first check to see if there's enough data to make a table
  Enter( no_tab );
  if( errorflag ) then exit;
  if (not pvlfancy) and (c[1]^.status<contains_unknown) then begin
    InsufficientDataMessage('table', DP_InsufficientDataForTable);
    exit;
  end;
  if( m_TableOut = nil ) then begin
    m_TableOut := TTableOut.Create( Self );
    m_TableOut.ReallyHide();
    m_TableOut.OnActivate := OnActivate;
    MainForm.ChildActivating( m_TableOut );
    m_TableOut.SetScreenType( PresentValueType );
  end;
  if( not m_TableOut.GetTableOptions( bSendToFile, bCommaSeperated, bSendToPrinter, df.c.peryr ) ) then exit;
  Output := TStringList.Create();
  ScreenCopy := TStringList.Create();
  if( not bCommaSeperated ) then begin
    CreateTextOutput( ScreenCopy );
    ScreenCopy.Add( '' );
    ScreenCopy.Add( '' );
  end;
  MakeTable( Output, bCommaSeperated );
  if( not bCommaSeperated ) then begin
    Output.Add( '' );
    Output.Add( '' );
    GetPVLSettingsString( Settings );
    Output.Add( Settings );
  end;
  if( bSendToFile ) then begin
    SaveDialog1.Title := 'Save table output as';
    if( bCommaSeperated ) then
      SaveDialog1.Filter := 'Comma Seperated File (*.csv)|*.CSV'
    else
      SaveDialog1.Filter := 'Text File (*.txt)|*.TXT';
    if( not SaveDialog1.Execute() ) then begin
      Output.Free();
      exit;
    end;
    FileName := SaveDialog1.FileName;
    Position := Pos( '.', FileName );
    if( Position = 0 ) then begin
      if( bCommaSeperated ) then
        FileName := FileName + '.csv'
      else
        FileName := FileName + '.txt';
    end;
    if( not FileExists( FileName ) ) then begin
      hFile := FileCreate( FileName );
      if( hFile = -1 ) then begin
        MasterLog.Write( LVL_MED, 'SaveFile failed to create new file for csv saving' );
        Output.Free();
        exit;
      end;
      FileClose( hFile );
    end else begin
      MessageBoxWithCancel( 'File Exists, would you like to save over it?', bCancelPressed, DP_OverwriteFile );
      if( bCancelPressed ) then begin
        Output.Free();
        exit;
      end;
    end;
    for i:=ScreenCopy.Count-1 downto 0 do begin
      Output.insert( 0, ScreenCopy[i] );
    end;
    Output.SaveToFile( FileName );
    Output.Free();
  end else begin
    if( Output.Count > 0 ) then begin
      if( m_TableOut = nil ) then begin
        m_TableOut := TTableOut.Create( Self );
        m_TableOut.OnActivate := OnActivate;
        MainForm.ChildActivating( m_TableOut );
      end;
      m_TableOut.Width := 600;
      m_TableOut.Height := 500;
      Line1 := '';
      Line2 := '        Date        Payment          Value    Cumulative Value';
      m_TableOut.SetScreenType( PresentValueType );
      m_TableOut.SetHeaders( Line1, Line2 );
      m_TableOut.SetScreenCopy( ScreenCopy );
      m_TableOut.SetOutput( Output );
      m_TableOut.DrawOutput();
      if( bSendToPrinter ) then begin
        m_TableOut.OnPrint( '' );
        m_TableOut.ReallyHide();
        BringToFront();
      end else begin
        m_TableOut.ReallyShow();
        m_TableOut.BringToFront();
      end;
    end else begin
      Output.Free();
      ScreenCopy.Free();
    end;
  end;
end;

procedure TPresentValueScreen.OnContextualHelp();
begin
  if( RateLineGrid.Focused() and ((RateLineGrid.Col=1) or (RateLineGrid.Col=2) or (RateLineGrid.Col=3)) ) then
    HelpSystem.DisplayContents( HelpSystem.GetHelpString( CP_Rates ) )
  else if( PresentValueGrid.Focused() and ((PresentValueGrid.Col=1) or (PresentValueGrid.Col=2) or (PresentValueGrid.Col=3)) ) then
    HelpSystem.DisplayContents( HelpSystem.GetHelpString( CP_Rates ) )
  else if( PeriodicGrid.Focused() and (PeriodicGrid.Col=4) ) then
    HelpSystem.DisplayContents( HelpSystem.GetHelpString( CP_COLA ) )
  else if( XPresValGrid.Focused() and (XPresValGrid.Col=2) ) then
    HelpSystem.DisplayContents( HelpSystem.GetHelpString( CP_PresVal ) )
  else if( PresentValueGrid.Focused() and (PresentValueGrid.Col=4) ) then
    HelpSystem.DisplayContents( HelpSystem.GetHelpString( CP_PresVal ) )
  else if( AdvancedIsOn() ) then
    HelpSystem.DisplayContents( HelpSystem.GetHelpString( CP_MainAdvanced ) )
  else
    HelpSystem.DisplayContents( HelpSystem.GetHelpString( CP_MainBasic ) );
end;

procedure TPresentValueScreen.FixRates( OldPerYr: byte );
var
  i: integer;
  HoldRate: real;
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.FixRates' );
  for i:=1 to PresentValueGrid.GetUsedRowCount() do begin
    if( c[i].r.status <> empty ) then begin
      if( c[i].r.status = fromapr ) then begin
        HoldRate := YieldFromRate( c[i].r.rate, OldPerYr );
        c[i].r.rate := RateFromYield( HoldRate, df.c.peryr );
        c[i].r.peryr := df.c.peryr;
      end;
    end;
  end;
  PresentValueValues2Grid( c, PresentValueGrid );
  for i:=1 to RatelineGrid.GetUsedRowCount() do begin
    if( cc[i].r.status <> empty ) then begin
      if( cc[i].r.status = fromapr ) then begin
        HoldRate := YieldFromRate( cc[i].r.rate, OldPerYr );
        cc[i].r.rate := RateFromYield( HoldRate, df.c.peryr );
        cc[i].r.peryr := df.c.peryr;
      end;
    end;
  end;
  RateLineValues2Grid( cc, RatelineGrid );
end;

procedure TPresentValueScreen.LumpSumGridSelectCell(Sender: TObject; ACol,
  ARow: Integer; var CanSelect: Boolean);
begin
  inherited;
  case ACol of
    LSMDateCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_LSMDateCol) );
    LSMAmountCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_LSMAmountCol) );
    LSMValueCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_LSMValueCol) );
  end;
  if( (a[ARow+1].datestatus<>empty) or
      ((ARow>0) and LumpSumGrid.RowIsEmpty(ARow) and (a[ARow].datestatus<>empty)) ) then
    MainForm.HighlightCopyAndIncrement( true )
  else
    MainForm.HighlightCopyAndIncrement( false );
end;

procedure TPresentValueScreen.PeriodicGridSelectCell(Sender: TObject; ACol,
  ARow: Integer; var CanSelect: Boolean);
begin
  inherited;
  case ACol of
    PERFromDateCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_PERFromDateCol) );
    PERToDateCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_PERToDateCol) );
    PERPerYrCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_PERPerYrCol) );
    PERAmountCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_PERAmountCol) );
    PERCOLACol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_PERCOLACol) );
    PERValueCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_PERValueCol) );
  end;
  if( (b[ARow+1].fromdatestatus<>empty) or
      ((ARow>0) and PeriodicGrid.RowIsEmpty(ARow) and (b[ARow].fromdatestatus<>empty)) ) then
    MainForm.HighlightCopyAndIncrement( true )
  else
    MainForm.HighlightCopyAndIncrement( false );
end;

procedure TPresentValueScreen.PresentValueGridSelectCell(Sender: TObject;
  ACol, ARow: Integer; var CanSelect: Boolean);
begin
  inherited;
  case ACol of
    PRVAsOfCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_PRVAsOfCol) );
    PRVTrueRateCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_PRVTrueRateCol) );
    PRVLoanRateCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_PRVLoanRateCol) );
    PRVYieldCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_PRVYieldCol) );
    PRVValueCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_PRVValueCol) );
  end;
  MainForm.HighlightCopyAndIncrement( false );
end;

procedure TPresentValueScreen.RatelineGridSelectCell(Sender: TObject; ACol,
  ARow: Integer; var CanSelect: Boolean);
begin
  inherited;
  case ACol of
    RTLDateCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_RTLDateCol) );
    RTLTrueRateCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_RTLTrueRateCol) );
    RTLLoanRateCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_RTLLoanRateCol) );
    RTLYieldCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_RTLYieldCol) );
  end;
  MainForm.HighlightCopyAndIncrement( false );
end;

procedure TPresentValueScreen.XPresValGridSelectCell(Sender: TObject; ACol,
  ARow: Integer; var CanSelect: Boolean);
begin
  inherited;
  case ACol of
    XPRAsOfCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_XPRAsOfCol) );
    XPRComputationCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_XPRComputationCol) );
    XPRValueCol: MainForm.SetStatusBarText( HelpSystem.GetHelpString(SP_XPRValueCol) );
  end;
  MainForm.HighlightCopyAndIncrement( false );
end;

procedure TPresentValueScreen.OnComputationalSettingsChanges( OldSettings: compdefaults; NewSettings: compdefaults );
begin
  PresentValueScreen.FixRates( OldSettings.peryr );
end;

procedure TPresentValueScreen.SetSettingsString( SettingsString: string );
begin
  PresentValueStatusBar.SimpleText := SettingsString;
end;

procedure TPresentValueScreen.SetCanadianString( NewString: string );
begin
  RateLineBox.ChangeCaption( 2, NewString, 'Rate %' );
  RateLineBox.Invalidate();
  PresentValueBox.ChangeCaption( 2, NewString, 'Rate %' );
  PresentValueBox.Invalidate();
end;

procedure TPresentValueScreen.LumpSumGridIntelligentNextCell(
  Sender: TObject; ACol, ARow: Integer; var bUseSimpleMovement: Boolean);
begin
  inherited;
  if( (ACol=LSMAmountCol) and (a[ARow+1].amt0status<>empty) ) then begin
    if( (ARow+1) < LumpSumGrid.RowCount ) then begin
      LumpSumGrid.Row := ARow+1;
      LumpSumGrid.Col := 0;
      bUseSimpleMovement := false;
    end;
  end else if( ACol=LSMValueCol ) then begin
    LumpSumGridRightAfterGrid( Self, bUSeSimpleMovement );
  end;
end;

procedure TPresentValueScreen.PeriodicGridIntelligentNextCell(
  Sender: TObject; ACol, ARow: Integer; var bUseSimpleMovement: Boolean);
begin
  inherited;
  if( (ACol=PERAMountCol) and (b[ARow+1].amtnstatus<>empty) ) then begin
    if( (ARow+1) < PeriodicGrid.RowCount ) then begin
      PeriodicGrid.Row := ARow+1;
      PeriodicGrid.Col := 0;
      bUseSimpleMovement := false;
    end;
  end else if( ACol = PERValueCol ) then begin
    PeriodicGridRightAfterGrid( Self, bUseSimpleMovement );
  end;
end;

procedure TPresentValueScreen.RatelineGridIntelligentNextCell(
  Sender: TObject; ACol, ARow: Integer; var bUseSimpleMovement: Boolean);
begin
  inherited;
  if( ACol = RTLYieldCol ) then begin
    RatelineGridRightAfterGrid( Self, bUseSimpleMovement );
  end;
end;

procedure TPresentValueScreen.InsertRow();
var
  pGrid: TPersenseGrid;
  MaxRowToMove: integer;
  i: integer;
begin
  pGrid := GetFocusedGrid();
  MaxRowToMove := pGrid.Row;
  if( pGrid = LumpSumGrid ) then begin
    for i:=0 to maxlines-1 do begin
      if( not LumpSumIsEmpty( LumpSumPtr(a[i+1]) ) ) then
        MaxRowToMove := i;
    end;
    if( (MaxRowToMove+1) > pGrid.RowCount ) then exit;
    for i:=MaxRowToMove downto pGrid.Row do begin
      if( not LumpSumIsEmpty( LumpSumPtr(a[i+1]) ) ) then
        MoveLumpSumRow( i, i+1 );
    end;
  end else if( pGrid = PeriodicGrid ) then begin
    for i:=0 to maxlines-1 do begin
      if( not PeriodicIsEmpty( PeriodicPtr(b[i+1]) ) ) then
        MaxRowToMove := i;
    end;
    if( (MaxRowToMove+1) > pGrid.RowCount ) then exit;
    for i:=MaxRowToMove downto pGrid.Row do begin
      if( not PeriodicIsEmpty( PeriodicPtr(b[i+1]) ) ) then
        MovePeriodicRow( i, i+1 );
    end;
  end else if( pGrid = RateLineGrid ) then begin
    for i:=0 to maxlines-1 do begin
      if( not RatelineIsEmpty( RatelinePtr(cc[i+1]) ) ) then
        MaxRowToMove := i;
    end;
    if( (MaxRowToMove+1) > pGrid.RowCount ) then exit;
    for i:=MaxRowToMove downto pGrid.Row do begin
      if( not RatelineIsEmpty( RatelinePtr(cc[i+1]) ) ) then
        MoveRatelineRow( i, i+1 );
    end;
  end;
end;

procedure TPresentValueScreen.DeleteRow();
var
  pGrid: TPersenseGrid;
  i: integer;
begin
  pGrid := GetFocusedGrid();
  pGrid.EmptyRow( pGrid.Row );
  if( pGrid = LumpSumGrid ) then begin
    ZeroLumpSum( lumpsumptr(a[pGrid.Row+1]) );
    for i:=pGrid.Row+1 to pGrid.GetUsedRowCount()-1 do
      MoveLumpSumRow( i, i-1 );
  end else if( pGrid = PeriodicGrid ) then begin
    ZeroPeriodic( periodicptr(b[pGrid.Row+1]) );
    for i:=pGrid.Row+1 to pGrid.GetUsedRowCount()-1 do
      MovePeriodicRow( i, i-1 );
  end else if( pGrid = RateLineGrid ) then begin
    ZeroRateline( ratelineptr(cc[pGrid.Row+1]) );
    for i:=pGrid.Row+1 to pGrid.GetUsedRowCount()-1 do
      MoveRatelineRow( i, i-1 );
    if( pGrid.Row = 0 ) then
      RatelineGrid.Cells[0,0] := 'XX         '; 
  end;
end;

// source and destination are 0 based.
procedure TPresentValueScreen.MoveLumpSumRow( Source, Destination: integer );
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.MoveLumpSumRow' );
  if( (Source+1>maxlines) or (Source<0) or
      (Destination+1>maxlines) or (Destination<0) ) then begin
    MasterLog.Write( LVL_MED, 'MoveRow destination or source out of range' );
    exit;
  end;
  SetUnsavedData( true );
  a[Destination+1]^ := a[Source+1]^;
  LumpSumGrid.CopyRow( Source, Destination );
  LumpSumGrid.EmptyRow( Source );
  ZeroLumpSum( lumpsumptr(a[Source+1]) );
end;

// source and destination are 0 based.
procedure TPresentValueScreen.MovePeriodicRow( Source, Destination: integer );
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.MovePeriodicRow' );
  if( (Source+1>maxlines) or (Source<0) or
      (Destination+1>maxlines) or (Destination<0) ) then begin
    MasterLog.Write( LVL_MED, 'MoveRow destination or source out of range' );
    exit;
  end;
  SetUnsavedData( true );
  b[Destination+1]^ := b[Source+1]^;
  PeriodicGrid.CopyRow( Source, Destination );
  PeriodicGrid.EmptyRow( Source );
  ZeroPeriodic( periodicptr(b[Source+1]) );
end;

// source and destination are 0 based.
procedure TPresentValueScreen.MoveRatelineRow( Source, Destination: integer );
begin
  MasterLog.Write( LVL_LOW, 'TPresentValueScreen.MoveRatelineRow' );
  if( (Source+1>maxlines) or (Source<0) or
      (Destination+1>maxlines) or (Destination<0) ) then begin
    MasterLog.Write( LVL_MED, 'MoveRow destination or source out of range' );
    exit;
  end;
  SetUnsavedData( true );
  cc[Destination+1]^ := cc[Source+1]^;
  RatelineGrid.CopyRow( Source, Destination );
  RatelineGrid.EmptyRow( Source );
  if( Source = 0 ) then begin
    RateLineGrid.Cells[0,0] := 'XX         ';
    cc[Destination+1].datestatus := empty;
  end;
  ZeroRateLine( ratelineptr(cc[Source+1]) );
end;

procedure TPresentValueScreen.CreateTextOutput( var Output: TStringList );
var
  i: integer;
  LumpSumCount: integer;
  PeriodicCount: integer;
  LumpPeriodicCount: integer;
  Block3Count: integer;
  OutString: string;
begin
  LumpSumCount := 0;
  PeriodicCount := 0;
  LumpPeriodicCount := 0;
  Block3Count := 0;
  for i:=1 to maxlines do begin
    if( not LumpSumIsEmpty(lumpsumptr(a[i])) ) then
      LumpSumCount := i;
  end;
  for i:=1 to maxlines do begin
    if( not PeriodicIsEmpty(periodicptr(b[i])) ) then
      PeriodicCount := i;
  end;
  if( LumpSumCount > PeriodicCount ) then
    LumpPeriodicCount := LumpSumCount
  else
    LumpPeriodicCount := PeriodicCount;
  if( pvlfancy ) then begin
    for i:=1 to maxlines do begin
      if( not RatelineIsEmpty(ratelineptr(cc[i])) ) then
        Block3Count := i;
    end;
  end else begin
    for i:=1 to presvallines do begin
      if( not PresvalIsEmpty(presvalptr(c[i])) ) then
        Block3Count := i;
    end;
  end;

  OutString := 'Single Payments                                  Periodic Payments';
  Output.Add( OutString );
  OutString := 'Date        Amount           Value                From        Through     PerYr Amount          COLA%        Value';
  Output.Add( OutString );
  OutString := '----------------------------------------------    ----------------------------------------------------------------------';
  Output.Add( OutString );
  for i:=0 to LumpPeriodicCount-1 do begin
    OutString := LumpSumGrid.GetRowAsTXT( i );
    OutString := OutString + '    ';
    OutString := OutString + PeriodicGrid.GetRowAsTXT( i );
    Output.Add( OutString );
  end;
  Output.Add( '' );
  if( pvlfancy ) then begin
    OutString :='Multiple Interest Rates Used To';
    Output.Add( OutString );
    OutString :='Compute A Single Valuation                          Value Computed With Rate Table At Left';
    Output.Add( OutString );
    if (df.c.peryr and canadian >0) then
      OutString :='Effective    True        Canadian                               Interest'
    else if (df.c.peryr and daily >0) then
      OutString :='Effective    True        Daily                                  Interest'
    else
      OutString :='Effective    True        Loan                                   Interest';
    Output.Add( OutString );
    OutString :='  Date      Rate %      Rate %      Yield %         As Of       Computation     Total Value';
    Output.Add( OutString );
    OutString :='----------------------------------------------      ------------------------------------------';
    Output.Add( OutString );
    for i:=0 to Block3Count-1 do begin
      OutString := RateLineGrid.GetRowAsTXT( i );
      if( i = 0 ) then begin
        OutString := OutString + '    ';
        OutString := OutString + XPresValGrid.GetRowAsTXT( 0 );
      end;
      Output.Add( OutString );
    end;
  end else begin
    OutString :='Present Value';
    Output.Add( OutString );
    if (df.c.peryr and canadian >0) then
      OutString :='            True        Canadian'
    else if (df.c.peryr and daily >0) then
      OutString :='            True        Daily'
    else
      OutString :='            True        Loan';
    Output.Add( OutString );
    OutString :='As Of       Rate %      Rate %      Yield       Value';
    Output.Add( OutString );
    OutString :='-----------------------------------------------------------';
    Output.Add( OutString );
    for i:=0 to Block3Count-1 do begin
      OutString := PresentValueGrid.GetRowAsTXT( i );
      Output.Add( OutString );
    end;
  end;
end;

procedure TPresentValueScreen.LumpSumGridNoEditEnterKeyPressed(
  Sender: TObject; ACol, ARow: Integer);
begin
  inherited;
  DoCalculation();
end;

procedure TPresentValueScreen.PeriodicGridNoEditEnterKeyPressed(
  Sender: TObject; ACol, ARow: Integer);
begin
  inherited;
  DoCalculation();
end;

procedure TPresentValueScreen.RatelineGridNoEditEnterKeyPressed(
  Sender: TObject; ACol, ARow: Integer);
begin
  inherited;
  DoCalculation();
end;

procedure TPresentValueScreen.PresentValueGridNoEditEnterKeyPressed(
  Sender: TObject; ACol, ARow: Integer);
begin
  inherited;
  DoCalculation();
end;

procedure TPresentValueScreen.XPresValGridNoEditEnterKeyPressed(
  Sender: TObject; ACol, ARow: Integer);
begin
  inherited;
  DoCalculation();
end;

end.

