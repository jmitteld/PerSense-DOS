unit ClipboardSettingsDlgUnit;

interface

uses Windows, SysUtils, Classes, Graphics, Forms, Controls, StdCtrls, 
  Buttons, ExtCtrls, ActnList;

type
  TClipboardSettingsDlg = class(TForm)
    OKBtn: TButton;
    CancelBtn: TButton;
    Bevel1: TBevel;
    Label1: TLabel;
    Label2: TLabel;
    CellDelimiter: TComboBox;
    RowDelimiter: TComboBox;
    Label3: TLabel;
    CellContainer: TEdit;
    GroupBox1: TGroupBox;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Button1: TButton;
    ActionList1: TActionList;
    ContextualHelp: TAction;
    procedure Button1Click(Sender: TObject);
    procedure ContextualHelpExecute(Sender: TObject);
  private
  public
  end;

var
  ClipboardSettingsDlg: TClipboardSettingsDlg;

implementation

uses HelpSystemUnit;

{$R *.dfm}

procedure TClipboardSettingsDlg.Button1Click(Sender: TObject);
begin
  HelpSystem.DisplayContents( Helpsystem.GetHelpString( CO_ClipboardSettingsHelp ) );
end;

procedure TClipboardSettingsDlg.ContextualHelpExecute(Sender: TObject);
begin
  HelpSystem.DisplayContents( Helpsystem.GetHelpString( CO_ClipboardSettingsHelp ) );
end;

end.
