unit RegistrationErrorDlgUnit;

interface

uses Windows, SysUtils, Classes, Graphics, Forms, Controls, StdCtrls, 
  Buttons, ExtCtrls, ActnList;

type
  TRegistrationErrorDlg = class(TForm)
    OKBtn: TButton;
    CancelBtn: TButton;
    Bevel1: TBevel;
    Label1: TLabel;
    Label2: TLabel;
    ActionList1: TActionList;
    ContextualHelp: TAction;
    procedure OKBtnClick(Sender: TObject);
    procedure ContextualHelpExecute(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  RegistrationErrorDlg: TRegistrationErrorDlg;

implementation

uses HelpSystemUnit, MAIN, RegistrationDlgUnit;

{$R *.dfm}

procedure TRegistrationErrorDlg.OKBtnClick(Sender: TObject);
begin
  MainForm.ShowRegistration();
end;

procedure TRegistrationErrorDlg.ContextualHelpExecute(Sender: TObject);
begin
    HelpSystem.DisplayContents( HelpSystem.GetHelpString( CO_Register ) );
end;

end.
