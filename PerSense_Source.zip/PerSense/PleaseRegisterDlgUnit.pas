unit PleaseRegisterDlgUnit;

interface

uses Windows, SysUtils, Classes, Graphics, Forms, Controls, StdCtrls,
  Buttons, ExtCtrls, ActnList;
  
type
  TPleaseRegisterDlg = class(TForm)
    OKBtn: TButton;
    CancelBtn: TButton;
    Bevel1: TBevel;
    Label1: TLabel;
    Label2: TLabel;
    ActionList1: TActionList;
    ContextualHelp: TAction;
    procedure ContextualHelpExecute(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

implementation

uses HelpSystemUnit;

{$R *.dfm}

procedure TPleaseRegisterDlg.ContextualHelpExecute(Sender: TObject);
begin
    HelpSystem.DisplayContents( HelpSystem.GetHelpString( CO_Register ) );
end;

end.
