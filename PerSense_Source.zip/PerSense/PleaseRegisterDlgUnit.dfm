object PleaseRegisterDlg: TPleaseRegisterDlg
  Left = 484
  Top = 236
  BorderStyle = bsDialog
  Caption = 'Registration'
  ClientHeight = 214
  ClientWidth = 352
  Color = clBtnFace
  ParentFont = True
  OldCreateOrder = True
  Position = poScreenCenter
  PixelsPerInch = 96
  TextHeight = 13
  object Bevel1: TBevel
    Left = 8
    Top = 8
    Width = 337
    Height = 153
    Shape = bsFrame
  end
  object Label1: TLabel
    Left = 16
    Top = 64
    Width = 317
    Height = 80
    Caption = 
      'You are using an unregistered version of Per%Sense.  This versio' +
      'n has all of the calculations of the full version of Per%Sense, ' +
      'but it does not allow you to save your work.  To register this v' +
      'ersion now, please click on the "Register" button below.'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
    WordWrap = True
  end
  object Label2: TLabel
    Left = 48
    Top = 24
    Width = 227
    Height = 24
    Caption = 'Please register Per%Sense'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -21
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object OKBtn: TButton
    Left = 103
    Top = 180
    Width = 75
    Height = 25
    Caption = 'Register now'
    Default = True
    ModalResult = 1
    TabOrder = 0
  end
  object CancelBtn: TButton
    Left = 191
    Top = 180
    Width = 75
    Height = 25
    Cancel = True
    Caption = 'Register Later'
    ModalResult = 2
    TabOrder = 1
  end
  object ActionList1: TActionList
    Left = 24
    Top = 176
    object ContextualHelp: TAction
      Caption = 'ContextualHelp'
      ShortCut = 112
      OnExecute = ContextualHelpExecute
    end
  end
end
