unit RegistrationDlgUnit;

interface

uses Windows, SysUtils, Classes, Graphics, Forms, Controls, StdCtrls,
  Buttons, ExtCtrls, ActnList;

type
  TRegistrationDialog = class(TForm)
    OKBtn: TButton;
    CancelBtn: TButton;
    Bevel1: TBevel;
    Edit1: TEdit;
    Label1: TLabel;
    Label3: TLabel;
    Edit2: TEdit;
    Label2: TLabel;
    ActionList1: TActionList;
    ContextualHelp: TAction;
    procedure Edit1KeyUp(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure ContextualHelpExecute(Sender: TObject);
  private
    m_IsRegistration: boolean;
  public
    procedure SetForName();
    procedure SetForRegistrationKey( RegistrationCode: string );
    function GetText(): string;
  end;

var
  RegistrationDialog: TRegistrationDialog;

implementation

uses HelpSystemUnit;

{$R *.dfm}

function TRegistrationDialog.GetText(): string;
begin
  GetText := Edit1.Text;
end;

procedure TRegistrationDialog.SetForName();
begin
  Label1.Width := 200;
  Label2.Width := 200;
  Label1.Top := 15;
  Label1.Caption := 'Welcome to Per%Sense';
  Label2.Top := 40;
  Label2.Caption := 'Please fill in your name below:';
  Label3.Visible := false;
  Edit2.Visible := false;
  Bevel1.Height := 110;
  Height := 200;
  Edit1.Top := 80;
  OkBtn.Top := 130;
  CancelBtn.Top := 130;
  OkBtn.Enabled := false;
  m_IsRegistration := false;
  Edit1.Text := '';
end;

procedure TRegistrationDialog.SetForRegistrationKey( RegistrationCode: string );
begin
  Label1.Width := 200;
  Label2.Width := 200;
  Label3.Width := 200;
  Label1.Top := 15;
  Label1.Caption := 'To Register Per%Sense please go to ';
  Label1.Caption := Label1.Caption + 'http://www.persense.org';
  Label2.Top := 50;
  Label2.Caption := 'and register with the following code: ';
  Edit2.Top := 70;
  Edit2.Visible := true;
  Edit2.Text := RegistrationCode;
  Edit2.SelectAll();
  Edit2.CopyToClipboard();
  Edit2.SelLength := 0;
  Label3.Top := 90;
  Label3.Visible := true;
  Label3.Caption := 'Fill in the Key it gives you below';
  m_IsRegistration := true;
  Bevel1.Height := 160;
  Height := 250;
  Edit1.Top := 130;
  OkBtn.Top := 180;
  CancelBtn.Top := 180;
  Edit1.Text := '';
end;

procedure TRegistrationDialog.Edit1KeyUp(Sender: TObject; var Key: Word; Shift: TShiftState);
var
  UsableCount: integer;
  i: integer;
begin
  if( Length( Edit1.Text ) = 0 ) then exit;
  if( m_IsRegistration ) then exit;
  UsableCount := 0;
  for i:=0 to length( Edit1.Text ) do begin
    if( ((Edit1.Text[i] >= 'a') and (Edit1.Text[i] <= 'z')) or
        ((Edit1.Text[i] >= 'A') and (Edit1.Text[i] <= 'Z')) ) then
      UsableCount := UsableCount+1;
  end;
  if( UsableCount > 5 ) then
    OkBtn.Enabled := true
  else
    OkBtn.Enabled := false;
end;

procedure TRegistrationDialog.ContextualHelpExecute(Sender: TObject);
begin
    HelpSystem.DisplayContents( HelpSystem.GetHelpString( CO_Register ) );
end;

end.

