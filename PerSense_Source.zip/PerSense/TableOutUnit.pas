unit TableOutUnit;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, childwin, FileIOUnit, StdCtrls, HelpSystemUnit;

type
  TTableOut = class(TMDIChild)
    OutputBox: TMemo;
    GroupBox1: TGroupBox;
    HeaderLine1: TLabel;
    HeaderLine2: TLabel;
    SaveDialog1: TSaveDialog;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  public
    constructor Create( AOwner: TComponent ); override;
    destructor Destroy(); override;
    function GetType(): TScreenType; override;
    procedure OnPrint( Header: string ); override;
    procedure OnCopy(); override;
    procedure OnContextualHelp(); override;
    function SaveFile( FileName, ScreenName : string ): boolean; override;
    function GetTableOptions( var SendToFile: boolean; var CommaSeperated: boolean; var SendToPrinter: boolean; PerYr: integer ): boolean;
    procedure SetScreenCopy( Output: TStringList );
    procedure SetOutput( Output: TStringList );
    procedure SetHeaders( Line1: string; Line2: string );
    procedure DrawOutput();
    procedure SetScreenType( TheType: TScreenType );
  protected
    m_Output: TStringList;
    m_ScreenCopy: TStringList;
    m_ScreenType: TScreenType;
    m_CumSet: set of byte;
    m_Cum: char;
  end;

implementation

uses peData, Printers, Globals, TableOptionsDlgUnit, LogUnit,
     PersenseClipboardUnit, PersenseGrid, peTypes, StrUtils,
     PresentValueScreenUnit, AmortizationScreenUnit, PresValu, Amortize;

{$R *.dfm}
constructor TTableOut.Create( AOwner: TComponent );
begin
  inherited Create( AOwner );
  m_Output := nil;
  m_ScreenCopy := nil;
  m_ScreenType := NoType;
end;

destructor TTableOut.Destroy();
begin
  m_Output.Free();
  m_ScreenCopy.Free();
  inherited Destroy();
end;

procedure TTableOut.SetScreenType( TheType: TScreenType );
begin
  m_ScreenType := TheType;
end;

procedure TTableOut.SetOutput( Output: TStringList );
begin
  m_Output.Free();
  m_Output := Output;
end;

procedure TTableOut.SetScreenCopy( Output: TStringList );
begin
  m_ScreenCopy.Free();
  m_ScreenCopy := Output;
end;

procedure TTableOut.SetHeaders( Line1: string; Line2: string );
begin
  HeaderLine1.Caption := Line1;
  HeaderLine2.Caption := Line2;
end;

function TTableOut.GetTableOptions( var SendToFile: boolean; var CommaSeperated: boolean; var SendToPrinter: boolean; PerYr: integer ): boolean;
var
  OptionsDlg: TTableOptionsDlg;
begin
  GetTableOptions := false;
  OptionsDlg := TTableOptionsDlg.Create( Self );
  OptionsDlg.SetPerYr( PerYr );
  OptionsDlg.SetScreenType( m_ScreenType );
  OptionsDlg.ShowModal();
  if( OptionsDlg.ModalResult<>MrOK ) then exit;
  SendToFile := OptionsDlg.SendToFile();
  CommaSeperated := OptionsDlg.CommaSeperated();
  SendToPrinter := OptionsDlg.SendToPrinter();
  OptionsDlg.Free();
  // these where set in the OptionsDlg.  Save them in case
  // we need to regenerate this table without showing the dialog
  m_CumSet := cumset;
  m_Cum := cum;
  GetTableOptions := true;
end;

procedure TTableOut.DrawOutput();
var
  i: integer;
begin
  OutputBox.Clear();
  OutputBox.Height := Height-GroupBox1.Height-30;
  for i:=m_Output.Count-1 downto 0 do begin
    OutputBox.Lines.insert( 0, m_Output[i] );
  end;
  for i:=m_ScreenCopy.Count-1 downto 0 do begin
    OutputBox.Lines.insert( 0, m_ScreenCopy[i] );
  end;
end;

function TTableOut.GetType(): TScreenType;
begin
  GetType := TableOutType;
end;

procedure TTableOut.OnCopy();
var
  Values: TStringList;
  Selected: string;
  Info: TList;
  pCellInfo: ^CellInfo;
begin
  OutputBox.CopyToClipboard();
{
  Values := TStringList.Create();
  Info := TList.Create();
  new( pCellInfo );
  pCellInfo.Hardness := inp;



  PersenseClipboard.Copy( Values, Info, 1 );
  }
end;

procedure TTableOut.OnPrint( Header: string );
var
  yPos: integer;
  TextHeight: integer;
  RowsPrinted: integer;
  UsablePageWidth: integer;
  i: integer;
  yHeaderEnd: integer;
  Margin: integer;
begin
  Printer.BeginDoc();
  Printer.Title := 'Persense Amortization Screen';
  PrintHeader( Printer, yHeaderEnd, Header );
  TextHeight := Printer.Canvas.TextHeight( 'Height' );
  if( m_ScreenType = AmortizationType ) then begin
    if( AmortizationScreen <> nil ) then begin
      AmortizationScreen.PrintAMZLine( yHeaderEnd, Printer.PageHeight-2*TextHeight, yPos );
    end;
  end else if( m_ScreenType = PresentValueType ) then begin
    if( PresentValueScreen <> nil ) then begin
      PresentValueScreen.PrintInternals( yHeaderEnd, Printer.PageHeight-2*TextHeight, yPos );
    end;
  end;
  Printer.Canvas.Font.Assign( OutputBox.Font );
  Printer.Canvas.Font.Pitch := fpFixed;
  Printer.Canvas.Brush.Color := clWhite;
  Printer.Canvas.Font.Size := Printer.Canvas.Font.Size+2;
  TextHeight := Printer.Canvas.TextHeight( 'Height' );
  Margin := trunc(Printer.PageWidth * MarginPercent);
  UsablePageWidth := Printer.PageWidth - 2*Margin;
  RowsPrinted := 0;
  yPos := yPos + 2*TextHeight;
  yHeaderEnd := yPos;
  while( RowsPrinted < m_Output.Count ) do begin
    // draw headers
    Printer.Canvas.TextOut( Margin, yPos, HeaderLine1.Caption );
    yPos := yPos + TextHeight;
    Printer.Canvas.TextOut( Margin, yPos, HeaderLine2.Caption );
    yPos := yPos + TextHeight;
    // draw box
    Printer.Canvas.MoveTo( Margin-40, yHeaderEnd );
    Printer.Canvas.LineTo( UsablePageWidth, yHeaderEnd );
    Printer.Canvas.LineTo( UsablePageWidth, yPos );
    Printer.Canvas.LineTo( Margin-40, yPos );
    Printer.Canvas.LineTo( Margin-40, yHeaderEnd );
    yHeaderEnd := 0;
    yPos := yPos + TextHeight;
    for i:=RowsPrinted to m_Output.Count-1 do begin
      Printer.Canvas.TextOut( Margin, yPos, m_Output[i] );
      yPos := yPos + TextHeight;
      Inc( RowsPrinted );
      if( yPos > Printer.PageHeight - 2*Margin ) then break;
    end;
    if( yPos > Printer.PageHeight - 2*Margin ) then begin
      Printer.NewPage();
      yPos := 2*TextHeight;
    end;
  end;
  Printer.EndDoc();
end;

function TTableOut.SaveFile( FileName, ScreenName : string ): boolean;
var
  OutFile: TextFile;
  hFile: integer;
  Position: integer;
  bWarnOnOverwrite: boolean;
  bCancelPressed: boolean;
  Extension: string;
  i: integer;
  Output: TStringList;
  bIsCSV: boolean;
begin
  MasterLog.Write( LVL_LOW, 'TTableOut.SaveFile' );
  SaveFile := false;
  bWarnOnOverwrite := false;
  if( ScreenName <> '' ) then
    SaveDialog1.Title := 'Save ' + ScreenName + ' As';
  SaveDialog1.Filter := 'Text Files (*.txt)|*.TXT|Comma Seperated File (*.csv)|*.CSV';
  if( FileName = '' ) then begin
    if( not SaveDialog1.Execute() ) then begin
      SaveFile := false;
      exit;
    end;
    bWarnOnOverwrite := true;
    FileName := SaveDialog1.FileName;
  end;
  Position := Pos( '.', FileName );
  if( Position = 0 ) then begin
    if( SaveDialog1.FilterIndex = 0 ) then begin
      FileName := FileName + '.txt';
      bIsCSV := false;
    end else begin
      FileName := FileName + '.csv';
      bIsCSV := true;
    end;
  end else begin
    Extension := AnsiRightStr( FileName, 3 );
    Extension := AnsiLowerCase( Extension );
    if( Extension = 'csv' ) then
      bIsCSV := true
    else
      bIsCSV := false;
  end;
  if( not FileExists( FileName ) ) then begin
    hFile := FileCreate( FileName );
    if( hFile = -1 ) then begin
      MasterLog.Write( LVL_MED, 'SaveFile failed to create new file for saving' );
      SaveFile := false;
      exit;
    end;
    FileClose( hFile );
  end else if( bWarnOnOverwrite ) then begin
    MessageBoxWithCancel( 'File Exists, would you like to save over it?', bCancelPressed, DO_OverwriteFile );
    if( bCancelPressed ) then begin
      SaveFile := false;
      exit;
    end;
  end;
  if( bIsCSV ) then begin
    // there's no way to convert this text file to a csv.  So if
    // this is the case then we want to re-generate the table
    // but send it to a file.
    Output := TStringList.Create();
    // restore these
    CumSet := m_cumset;
    Cum := m_cum;
    if( m_ScreenType = AmortizationType ) then begin
      Amortize.MakeTable( Output, true );
    end else if( m_ScreenType = PresentValueType ) then begin
      PresValu.MakeTable( Output, true );
    end;
    Output.SaveToFile( FileName );
    Output.Free();
  end else begin
    AssignFile( OutFile, FileName );
    Rewrite( OutFile );
    WriteLn( OutFile, HeaderLine1.Caption );
    WriteLn( OutFile, HeaderLine2.Caption );
    for i:=0 to m_ScreenCopy.Count-1 do
      WriteLn( OutFile, m_ScreenCopy[i] );
    for i:=0 to m_Output.Count-1 do
      WriteLn( OutFile, m_Output[i] );
    CloseFile( OutFile );
  end;
end;

procedure TTableOut.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
  OnFormClose( Action );
end;

procedure TTableOut.OnContextualHelp();
begin
  if( m_ScreenType = AmortizationType ) then
    HelpSystem.DisplayContents( HelpSystem.GetHelpString( CA_Table ) )
  else if( m_ScreenType = PresentValueType ) then
    HelpSystem.DisplayContents( HelpSystem.GetHelpString( CP_Table ) )
end;

end.