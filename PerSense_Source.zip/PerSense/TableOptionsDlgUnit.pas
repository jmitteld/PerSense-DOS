unit TableOptionsDlgUnit;

interface

uses Windows, SysUtils, Classes, Graphics, Forms, Controls, StdCtrls, 
  Buttons, ExtCtrls, peData, peTypes, Globals, ActnList, CHILDWIN;

type
  TTableOptionsDlg = class(TForm)
    OKBtn: TButton;
    CancelBtn: TButton;
    Bevel1: TBevel;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    DetailsCombo: TComboBox;
    SummaryCombo: TComboBox;
    MonthsCombo: TComboBox;
    Label4: TLabel;
    OutputCombo: TComboBox;
    ActionList1: TActionList;
    ContextualHelp: TAction;
    procedure SummaryComboChange(Sender: TObject);
    procedure DetailsComboChange(Sender: TObject);
    procedure OKBtnClick(Sender: TObject);
    procedure OutputComboChange(Sender: TObject);
    procedure ContextualHelpExecute(Sender: TObject);
  protected
    m_bSendToFile: boolean;
    m_bCommaSeperated: boolean;
    m_bSendToPrinter: boolean;
    m_PerYr: integer;
    m_ScreenType: TScreenType;
  public
    constructor Create( AOwner: TComponent ); override;
    function SendToFile(): boolean;
    function CommaSeperated(): boolean;
    function SendToPrinter(): boolean;
    procedure SetPerYr( PerYr: integer );
    procedure SetScreenType( ScreenType : TScreenType );
  end;

var
  TableOptionsDlg: TTableOptionsDlg;

implementation

uses MAIN, AmortizationScreenUnit, HelpSystemUnit;

{$R *.dfm}

constructor TTableOptionsDlg.Create( AOwner: TComponent );
begin
  inherited Create( AOwner );
  DetailsCombo.ItemIndex := 0;
  OutputCombo.ItemIndex := 0;
  m_PerYr := df.c.peryr;
end;

procedure TTableOptionsDlg.SetPerYr( PerYr: integer );
begin
  m_PerYr := PerYr;
end;

procedure TTableOptionsDlg.SetScreenType( ScreenType : TScreenType );
begin
  m_ScreenType := ScreenType;
end;

procedure TTableOptionsDlg.SummaryComboChange(Sender: TObject);
var
  i: integer;
begin
  MonthsCombo.Clear();
  if( SummaryCombo.Items[SummaryCombo.ItemIndex] = 'Annual' ) then begin
    MonthsCombo.Items.Add( 'January' );
    MonthsCombo.Items.Add( 'February' );
    MonthsCombo.Items.Add( 'March' );
    MonthsCombo.Items.Add( 'April' );
    MonthsCombo.Items.Add( 'May' );
    MonthsCombo.Items.Add( 'June' );
    MonthsCombo.Items.Add( 'July' );
    MonthsCombo.Items.Add( 'August' );
    MonthsCombo.Items.Add( 'September' );
    MonthsCombo.Items.Add( 'October' );
    MonthsCombo.Items.Add( 'November' );
    MonthsCombo.Items.Add( 'December' );
    MonthsCombo.ItemIndex := 11;
  end else if( SummaryCombo.Items[SummaryCombo.ItemIndex] = 'Semi-Annual' ) then begin
    MonthsCombo.Items.Add( 'Jan, Jul' );
    MonthsCombo.Items.Add( 'Feb, Aug' );
    MonthsCombo.Items.Add( 'Mar, Sep' );
    MonthsCombo.Items.Add( 'Apr, Oct' );
    MonthsCombo.Items.Add( 'May, Nov' );
    MonthsCombo.Items.Add( 'Jun, Dec' );
    MonthsCombo.ItemIndex := 5;
  end else if( SummaryCombo.Items[SummaryCombo.ItemIndex] = 'Quarterly' ) then begin
    MonthsCombo.Items.Add( 'Jan, Apr, Jul, Oct' );
    MonthsCombo.Items.Add( 'Feb, May, Aug, Nov' );
    MonthsCombo.Items.Add( 'Mar, Jun, Sep, Dec' );
    MonthsCombo.ItemIndex := 2;
  end else if( SummaryCombo.Items[SummaryCombo.ItemIndex] = 'Monthly' ) then begin
    MonthsCombo.Items.Add( 'All' );
    MonthsCombo.ItemIndex := 0;
  end;
end;

procedure TTableOptionsDlg.DetailsComboChange(Sender: TObject);
var
  i: integer;
begin
  SummaryCombo.Clear();
  if( DetailsCombo.Items[DetailsCombo.ItemIndex] = 'Detail Only' ) then begin
    MonthsCombo.Clear();
  end else begin
    SummaryCombo.Items.Add( 'Annual' );
    SummaryCombo.Items.Add( 'Semi-Annual' );
    SummaryCombo.Items.Add( 'Quarterly' );
    if( m_PerYr > 12 ) then
      SummaryCombo.Items.Add( 'Monthly' );
    SummaryCombo.ItemIndex := 0;
    MonthsCombo.Items.Add( 'January' );
    MonthsCombo.Items.Add( 'February' );
    MonthsCombo.Items.Add( 'March' );
    MonthsCombo.Items.Add( 'April' );
    MonthsCombo.Items.Add( 'May' );
    MonthsCombo.Items.Add( 'June' );
    MonthsCombo.Items.Add( 'July' );
    MonthsCombo.Items.Add( 'August' );
    MonthsCombo.Items.Add( 'September' );
    MonthsCombo.Items.Add( 'October' );
    MonthsCombo.Items.Add( 'November' );
    MonthsCombo.Items.Add( 'December' );
    MonthsCombo.ItemIndex := 11;
  end;
end;

procedure TTableOptionsDlg.OKBtnClick(Sender: TObject);
var
  bUseDetail: boolean;
  Months: string;
  Month: string;
  Pos1: integer;
begin
  bUseDetail := (DetailsCombo.Items[DetailsCombo.ItemIndex] = 'Detail & Summary');
  Months := '';
  cumset := [];
  m_bSendToFile := (OutputCombo.Items[OutputCombo.ItemIndex] = 'Comma Seperated File') or
                   (OutputCombo.Items[OutputCombo.ItemIndex] = 'Raw Text File');
  m_bCommaSeperated := (OutputCombo.Items[OutputCombo.ItemIndex] = 'Comma Seperated File') or
                       (OutputCombo.Items[OutputCombo.ItemIndex] = 'Spreadsheet');
  m_bSendToPrinter := (OutputCombo.Items[OutputCombo.ItemIndex] = 'Printer');
  if( SummaryCombo.Items[SummaryCombo.ItemIndex] = 'Annual' ) then begin
    if( bUseDetail ) then
      cum := 'Y'
    else
      cum := 'y';
    cumset := [MonthsCombo.ItemIndex+1];
  end else if( SummaryCombo.Items[SummaryCombo.ItemIndex] = 'Semi-Annual' ) then begin
    if( bUseDetail ) then
      cum := 'S'
    else
      cum := 's';
    cumset := [MonthsCombo.ItemIndex+1];
    cumset := cumset + [MonthsCombo.ItemIndex+7];
  end else if( SummaryCombo.Items[SummaryCombo.ItemIndex] = 'Quarterly' ) then begin
    if( bUseDetail ) then
      cum := 'Q'
    else
      cum := 'q';
    cumset := [MonthsCombo.ItemIndex+1];
    cumset := cumset + [MonthsCombo.ItemIndex+4];
    cumset := cumset + [MonthsCombo.ItemIndex+7];
    cumset := cumset + [MonthsCombo.ItemIndex+10];
  end else if( SummaryCombo.Items[SummaryCombo.ItemIndex] = 'Monthly' ) then begin
    if( bUseDetail ) then
      cum := 'M'
    else
      cum := 'm';
    cumset := [1,2,3,4,5,6,7,8,9,10,11,12];
  end else begin
    // if the user doesn't choose anything then it's
    // monthly, deatilonly
    cum := 'm';
    cumset := [1,2,3,4,5,6,7,8,9,10,11,12];
  end;
end;

function TTableOptionsDlg.SendToFile(): boolean;
begin
  SendToFile := m_bSendToFile;
end;

function TTableOptionsDlg.CommaSeperated(): boolean;
begin
  CommaSeperated := m_bCommaSeperated;
end;

function TTableOptionsDlg.SendToPrinter(): boolean;
begin
  SendToPrinter := m_bSendToPrinter;
end;

procedure TTableOptionsDlg.OutputComboChange(Sender: TObject);
begin
  if( (OutputCombo.ItemIndex = 1) or (OutputCombo.ItemIndex = 2) or(OutputCombo.ItemIndex = 3) ) then begin
    if( not MainForm.RegisterIfNecessary() ) then
      OutputCombo.ItemIndex := 0;
  end;
end;

procedure TTableOptionsDlg.ContextualHelpExecute(Sender: TObject);
begin
  if( m_ScreenType = AmortizationType ) then
    HelpSystem.DisplayContents( HelpSystem.GetHelpString( CA_Table ) )
  else if( m_ScreenType = PresentValueType ) then
    HelpSystem.DisplayContents( HelpSystem.GetHelpString( CP_Table ) )
end;

end.
