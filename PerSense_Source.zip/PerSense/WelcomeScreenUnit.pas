unit WelcomeScreenUnit;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ChildWin, StdCtrls, FileIOUnit, ExtCtrls, ImgList;

type
  TWelcomeSelectedType = ( WelcomeNoSelection, WelcomeAMZ, WelcomeMtg,
                           WelcomePVL, WelcomeSamples, WelcomeHelp );

  TWelcomeScreen = class(TMDIChild)
    Image1: TImage;
    Image2: TImage;
    Image3: TImage;
    MTGImage: TImage;
    AMZImage: TImage;
    PVLImage: TImage;
    Image7: TImage;
    Image8: TImage;
    CaptionImage: TImage;
    BlurbLabel: TLabel;
    SamplesImage: TImage;
    HelpImage: TImage;
    procedure FormActivate(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure MTGImageMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure FormMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure Image1MouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure Image2MouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure AMZImageMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure PVLImageMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure Image3MouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure Image7MouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure Image8MouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure SamplesImageMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure HelpImageMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure MTGImageClick(Sender: TObject);
    procedure AMZImageClick(Sender: TObject);
    procedure PVLImageClick(Sender: TObject);
    procedure SamplesImageClick(Sender: TObject);
    procedure HelpImageClick(Sender: TObject);
  protected
    m_SelectedType: TWelcomeSelectedType;
    procedure HighlightNone();
    procedure HighlightMortgage();
    procedure HighlightAmortization();
    procedure HighlightPresentValue();
    procedure HighlightExamples();
    procedure HighlightHelp();
  public
    constructor Create( AOwner:TComponent ); override;
    function GetType(): TScreenType; override;
  end;

var
  WelcomeScreen: TWelcomeScreen;

implementation

uses Globals, MAIN;

{$R *.dfm}

constructor TWelcomeScreen.Create( AOwner:TComponent );
begin
  inherited Create( AOwner );
end;

function TWelcomeScreen.GetType(): TScreenType;
begin
  GetType := WelcomeType;
end;

procedure TWelcomeScreen.FormActivate(Sender: TObject);
begin
  // makes the form actually set to the size specified by the Object Inspector
  Width := 455;
  Height := 227;

  // setting the Welcome type to anything other then WelcomeTypeNone
  // will cause HighlightNone to actually do something.
  m_SelectedType := WelcomeMtg;
  HighlightNone();
  BlurbLabel.Font.Color := $005500;
  Left := trunc(MainForm.Width/2)-225;
  if( (trunc(MainForm.Height/2)-115) < 0 ) then
    Top := 0
  else
    Top := trunc(MainForm.Height/2)-225;
  MainForm.ChildActivating( Self );
end;

procedure TWelcomeScreen.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
  OnFormClose( Action );
end;

procedure TWelcomeScreen.HighlightNone();
begin
  if( m_SelectedType = WelcomeNoSelection ) then exit;

  MTGImage.Picture.Bitmap.LoadFromResourceName( hInstance, 'WELCOME_MTG_BUTTON' );
  AMZImage.Picture.Bitmap.LoadFromResourceName( hInstance, 'WELCOME_AMZ_BUTTON' );
  PVLImage.Picture.Bitmap.LoadFromResourceName( hInstance, 'WELCOME_PVL_BUTTON' );
  SamplesImage.Picture.Bitmap.LoadFromResourceName( hInstance, 'WELCOME_SAMPLES_BUTTON' );
  HelpImage.Picture.Bitmap.LoadFromResourceName( hInstance, 'WELCOME_HELP_BUTTON' );
  BlurbLabel.Caption := 'Every financial calculation you can imagine';
  m_SelectedType := WelcomeNoSelection;
end;

procedure TWelcomeScreen.HighlightMortgage();
begin
  if( m_SelectedType = WelcomeMtg ) then exit;
  HighlightNone();
  MTGImage.Picture.Bitmap.LoadFromResourceName( hInstance, 'WELCOME_MTG_HBUTTON' );
  BlurbLabel.Caption := 'Simple monthly loans and comparison for refinancing';
  m_SelectedType := WelcomeMtg;
end;

procedure TWelcomeScreen.HighlightAmortization();
begin
  if( m_SelectedType = WelcomeAMZ ) then exit;
  HighlightNone();
  AMZImage.Picture.Bitmap.LoadFromResourceName( hInstance, 'WELCOME_AMZ_HBUTTON' );
  BlurbLabel.Caption := 'Payment and calculations for simple loans, or structured, with rate changes and more';
  m_SelectedType := WelcomeAMZ;
end;

procedure TWelcomeScreen.HighlightPresentValue();
begin
  if( m_SelectedType = WelcomePVL ) then exit;
  HighlightNone();
  PVLImage.Picture.Bitmap.LoadFromResourceName( hInstance, 'WELCOME_PVL_HBUTTON' );
  BlurbLabel.Caption := 'A flexible tool for IRRs, valuations, and payment structures';
  m_SelectedType := WelcomePVL;
end;

procedure TWelcomeScreen.HighlightExamples();
begin
  if( m_SelectedType = WelcomeSamples ) then exit;
  HighlightNone();
  SamplesImage.Picture.Bitmap.LoadFromResourceName( hInstance, 'WELCOME_SAMPLES_HBUTTON' );
  BlurbLabel.Caption := 'A good place to start';
  m_SelectedType := WelcomeSamples;
end;

procedure TWelcomeScreen.HighlightHelp();
begin
  if( m_SelectedType = WelcomeHelp ) then exit;
  HighlightNone();
  HelpImage.Picture.Bitmap.LoadFromResourceName( hInstance, 'WELCOME_HELP_HBUTTON' );
  BlurbLabel.Caption := 'Your questions, answered';
  m_SelectedType := WelcomeHelp;
end;

procedure TWelcomeScreen.MTGImageMouseMove(Sender: TObject;
  Shift: TShiftState; X, Y: Integer);
begin
  inherited;
  HighlightMortgage();
end;

procedure TWelcomeScreen.FormMouseMove(Sender: TObject; Shift: TShiftState;
  X, Y: Integer);
begin
  inherited;
  HighlightNone();
end;

procedure TWelcomeScreen.Image1MouseMove(Sender: TObject;
  Shift: TShiftState; X, Y: Integer);
begin
  inherited;
  HighlightNone();
end;

procedure TWelcomeScreen.Image2MouseMove(Sender: TObject;
  Shift: TShiftState; X, Y: Integer);
begin
  inherited;
  HighlightNone();
end;

procedure TWelcomeScreen.AMZImageMouseMove(Sender: TObject;
  Shift: TShiftState; X, Y: Integer);
begin
  inherited;
  HighlightAmortization();
end;

procedure TWelcomeScreen.PVLImageMouseMove(Sender: TObject;
  Shift: TShiftState; X, Y: Integer);
begin
  inherited;
  HighlightPresentValue();
end;

procedure TWelcomeScreen.Image3MouseMove(Sender: TObject;
  Shift: TShiftState; X, Y: Integer);
begin
  inherited;
  HighlightNone();
end;

procedure TWelcomeScreen.Image7MouseMove(Sender: TObject;
  Shift: TShiftState; X, Y: Integer);
begin
  inherited;
  HighlightNone();
end;

procedure TWelcomeScreen.Image8MouseMove(Sender: TObject;
  Shift: TShiftState; X, Y: Integer);
begin
  inherited;
  HighlightNone();
end;

procedure TWelcomeScreen.SamplesImageMouseMove(Sender: TObject;
  Shift: TShiftState; X, Y: Integer);
begin
  inherited;
  HighlightExamples();
end;

procedure TWelcomeScreen.HelpImageMouseMove(Sender: TObject;
  Shift: TShiftState; X, Y: Integer);
begin
  inherited;
  HighlightHelp();
end;

procedure TWelcomeScreen.MTGImageClick(Sender: TObject);
begin
  inherited;
  MainForm.ScreenShowMortgageExecute( Self );
end;

procedure TWelcomeScreen.AMZImageClick(Sender: TObject);
begin
  inherited;
  MainForm.ScreenShowAmortizationExecute( Self );
end;

procedure TWelcomeScreen.PVLImageClick(Sender: TObject);
begin
  inherited;
  MainForm.ScreenShowPresentValueExecute( Self );
end;

procedure TWelcomeScreen.SamplesImageClick(Sender: TObject);
begin
  inherited;
  MainForm.HelpExamples1Execute( Self );
end;

procedure TWelcomeScreen.HelpImageClick(Sender: TObject);
begin
  inherited;
  MainForm.HelpContents1Execute( Self );
end;

end.
