unit AMZTableOutUnit;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, childwin, FileIOUnit, StdCtrls;

type
  TAMZTableOut = class(TMDIChild)
    OutputBox: TMemo;
    GroupBox1: TGroupBox;
    HeaderLine1: TLabel;
    HeaderLine2: TLabel;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  public
    constructor Create( AOwner: TComponent ); override;
    destructor Destroy(); override;
    function GetType(): TScreenType; override;
    procedure OnPrint(); override;
    procedure SetOutput( Output: TStringList );
    procedure DrawOutput();
  protected
    m_Output: TStringList;
  end;

implementation

uses peData, Printers, Globals;

{$R *.dfm}
constructor TAMZTableOut.Create( AOwner: TComponent );
begin
  inherited Create( AOwner );
  m_Output := nil;
end;

destructor TAMZTableOut.Destroy();
begin
  m_Output.Free();
  inherited Destroy();
end;

procedure TAMZTableOut.SetOutput( Output: TStringList );
begin
  m_Output.Free();
  m_Output := Output;
end;

procedure TAMZTableOut.DrawOutput();
var
  i: integer;
begin
  OutputBox.Clear();
  if( fancy ) then begin
    HeaderLine1.Caption := '               Payment      Interest     Principal     Principal       Interest';
    HeaderLine2.Caption := '   Date         Amount   This Period   This Period   New Balance        To Date';
  end else begin
    HeaderLine1.Caption := '                     Interest       Principal       Principal        Interest';
    HeaderLine2.Caption := '  ##     Date     This Period     This Period     New Balance         To Date';
  end;
  OutputBox.Height := Height-GroupBox1.Height-30;
  for i:=m_Output.Count-1 downto 0 do begin
    OutputBox.Lines.insert( 0, m_Output[i] );
  end;
end;

function TAMZTableOut.GetType(): TScreenType;
begin
  GetType := AMZTableOutType;
end;

procedure TAMZTableOut.OnPrint();
var
  yPos: integer;
  TextHeight: integer;
  RowsPrinted: integer;
  UsablePageWidth: integer;
  i: integer;
const
  Margin=80;
begin
  Printer.BeginDoc();
  Printer.Title := 'Persense Amortization Screen';
  Printer.Canvas.Font.Assign( OutputBox.Font );
  Printer.Canvas.Brush.Color := clWhite;
  TextHeight := Printer.Canvas.TextHeight( 'Height' );
  UsablePageWidth := Printer.PageWidth - 2*Margin;
  RowsPrinted := 0;
  yPos := 100;
  while( RowsPrinted < m_Output.Count ) do begin
    // draw headers
    Printer.Canvas.TextOut( Margin, yPos, HeaderLine1.Caption );
    yPos := yPos + TextHeight;
    Printer.Canvas.TextOut( Margin, yPos, HeaderLine2.Caption );
    yPos := yPos + TextHeight;
    // draw box
    Printer.Canvas.MoveTo( Margin, Margin );
    Printer.Canvas.LineTo( UsablePageWidth, Margin );
    Printer.Canvas.LineTo( UsablePageWidth, yPos );
    Printer.Canvas.LineTo( Margin, yPos );
    Printer.Canvas.LineTo( Margin, Margin );
    yPos := yPos + TextHeight;
    for i:=RowsPrinted to m_Output.Count-1 do begin
      Printer.Canvas.TextOut( Margin, yPos, m_Output[i] );
      yPos := yPos + TextHeight;
      Inc( RowsPrinted );
      if( yPos > Printer.PageHeight - 2*Margin ) then break;
    end;
    if( yPos > Printer.PageHeight - 2*Margin ) then begin
      yPos := 100;
      Printer.NewPage();
    end;
  end;
  Printer.EndDoc();
end;

procedure TAMZTableOut.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
  OnFormClose( Action );
end;

end.
