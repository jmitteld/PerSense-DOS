unit about;

interface

uses Windows, Classes, Graphics, Forms, Controls, StdCtrls,
  Buttons, ExtCtrls;

type
  TAboutBox = class(TForm)
    Panel1: TPanel;
    OKButton: TButton;
    ProgramIcon: TImage;
    Version: TLabel;
    Copyright: TLabel;
    RegistrationInfo: TLabel;
    Label1: TLabel;
    RegistrationButton: TButton;
  private
    { Private declarations }
  public
    procedure SetRegistered( UserName: string );
    procedure SetNotRegistered();
  end;

var
  AboutBox: TAboutBox;

implementation

{$R *.dfm}
procedure TAboutBox.SetRegistered( UserName: string );
begin
  RegistrationInfo.Visible := true;
  RegistrationButton.Visible := false;
  Height := 298;
  Panel1.Height := 210;
  OKButton.Top := 225;
  RegistrationInfo.Font.Color := clBlack;
  RegistrationInfo.Caption := 'Registered to ' + UserName;
  RegistrationInfo.Height := 13;
end;

procedure TAboutBox.SetNotRegistered();
begin
  RegistrationInfo.Visible := true;
  RegistrationButton.Visible := true;
  Height := 341;
  Panel1.Height := 257;
  OKButton.Top := 274;
end;

end.

