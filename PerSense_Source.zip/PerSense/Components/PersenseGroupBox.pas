unit PersenseGroupBox;

interface

uses
  SysUtils, Classes, Controls, StdCtrls, Graphics, Types;

const MAX_CAPTIONS = 20;

type
  TPersenseGroupBox = class(TGroupBox)
  private
    // private properties
    FBackgroundColor : TColor;
  protected
    m_CaptionLine1 : array [0..MAX_CAPTIONS] of string;
    m_CaptionLine2 : array [0..MAX_CAPTIONS] of string;
    m_CaptionPositions : array [0..MAX_CAPTIONS] of real;
    procedure Paint(); override;
  public
    constructor Create(AOwner: TComponent); override;
    procedure SetCaption( Index: integer; Line1: string; Line2: string; Position: real );
    procedure ChangeCaption( Index: integer; Line1: string; Line2: string );
  published
    property BackgroundColor : TColor read FBackgroundColor write FBackgroundColor;
  end;

procedure Register;

implementation

constructor TPersenseGroupBox.Create(AOwner: TComponent);
var
  i: integer;
begin
  inherited Create( AOwner );
  DoubleBuffered := true;
  for i:=0 to MAX_CAPTIONS do begin
    m_CaptionPositions[i] := 0;
  end;
end;

procedure TPersenseGroupBox.Paint();
var
  TopBorder: integer;
  BackgroundRect: TRect;
  i: integer;
  x: real;
  HalfHeader : TBitmap;
begin
  with Canvas do begin
    TopBorder := trunc(TextHeight( 'Lp' )/4.0);
    // do background colour fills
    BackgroundRect := ClientRect;
    BackgroundRect.Top := BackgroundRect.Top + TopBorder;
    Brush.Color := Color;
    FillRect( BackgroundRect );
    BackgroundRect.Top := 0;
    BackgroundRect.Bottom := TopBorder;
    Brush.Color := FBackgroundColor;
    FillRect( BackgroundRect );
    // border stuff
    Pen.Color := Self.Font.Color;
    MoveTo( 0, TopBorder );
    LineTo( ClientRect.Left, ClientRect.Bottom-1 );
    LineTo( ClientRect.Right-1, ClientRect.Bottom-1 );
    LineTo( ClientRect.Right-1, TopBorder );
    LineTo( TextWidth( Caption ), TopBorder );
    // header text
    HalfHeader := TBitmap.Create();
    HalfHeader.Canvas.Font := Self.Font;
    HalfHeader.Canvas.Brush.Color := FBackgroundColor;
    HalfHeader.Width := HalfHeader.Canvas.TextWidth( Caption );
    HalfHeader.Height := HalfHeader.Canvas.TextHeight( Caption );
    HalfHeader.Canvas.TextOut( 0, 0, Caption );
    HalfHeader.Height := trunc(HalfHeader.Height/2.0);
    Font := Self.Font;
    Brush.Color := Color;
    TextOut( 2, -TopBorder, Caption );
    Draw( 2, -TopBorder, HalfHeader );
    HalfHeader.Free();
    // captions
    for i:=0 to MAX_CAPTIONS do begin
      if( m_CaptionPositions[i] <> 0 ) then begin
        x := (ClientRect.Right-ClientRect.Left)*m_CaptionPositions[i] - TextWidth(m_CaptionLine1[i])/2.0;
        TextOut( trunc(x), trunc(TopBorder*3.5), m_CaptionLine1[i] );
        x := (ClientRect.Right-ClientRect.Left)*m_CaptionPositions[i] - TextWidth(m_CaptionLine2[i])/2.0;
        TextOut( trunc(x), trunc(TopBorder*7.5), m_CaptionLine2[i] );
      end;
    end;
  end;
end;

procedure TPersenseGroupBox.SetCaption( Index: integer; Line1: string; Line2: string; Position: real );
begin
  if( Index > MAX_CAPTIONS ) then
    exit;
  m_CaptionPositions[Index] := Position;
  ChangeCaption( Index, Line1, Line2 );
end;

procedure TPersenseGroupBox.ChangeCaption( Index: integer; Line1: string; Line2: string );
begin
  m_CaptionLine1[Index] := Line1;
  m_CaptionLine2[Index] := Line2;
end;

procedure Register;
begin
  RegisterComponents('MyComponents', [TPersenseGroupBox]);
end;

end.
