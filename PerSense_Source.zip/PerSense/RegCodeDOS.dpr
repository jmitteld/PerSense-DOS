program RegCodeDOS; {does arithmetic with integers up to 12 digits, coding them internally as 3 longints}
{$APPTYPE CONSOLE}
{$R+,O-}

const   NonsenseNumber:int64 = 781536741459;
var     reg,keystr   :string;
        code,key     :int64;
        ta           :integer;

function ScrambleHashCode( Reg: string ): string;
var
  i: integer;
  RetVal: string;
begin
  RetVal := Reg;
  // scrambling is done by taking every other letter (starting
  // at the second one) and replacing it with a letter.  The
  // ten letters are 'AJFDUNTERW'
  for i:=1 to length( RetVal ) do begin
    if( (i mod 2) = 0 ) then begin
      if( RetVal[i] = '1' ) then
        RetVal[i] := 'A'
      else if( RetVal[i] = '2' ) then
        RetVal[i] := 'J'
      else if( RetVal[i] = '3' ) then
        RetVal[i] := 'F'
      else if( RetVal[i] = '4' ) then
        RetVal[i] := 'D'
      else if( RetVal[i] = '5' ) then
        RetVal[i] := 'U'
      else if( RetVal[i] = '6' ) then
        RetVal[i] := 'N'
      else if( RetVal[i] = '7' ) then
        RetVal[i] := 'T'
      else if( RetVal[i] = '8' ) then
        RetVal[i] := 'E'
      else if( RetVal[i] = '9' ) then
        RetVal[i] := 'R'
      else if( RetVal[i] = '0' ) then
        RetVal[i] := 'W';
    end;
  end;
  ScrambleHashCode := RetVal;
end;

function UnscrambleHashCode( Reg: string ): string;
var
  i: integer;
  RetVal: string;
begin
  RetVal := Reg;
  // scrambling is done by taking every other letter (starting
  // at the second one) and replacing it with a letter.  The
  // ten letters are 'AJFDUNTERW'
  for i:=1 to length( RetVal ) do begin
    if( (i mod 2) = 0 ) then begin
      RetVal[i]:=Upcase(RetVal[i]);
      if( RetVal[i] = 'A' ) then
        RetVal[i] := '1'
      else if( RetVal[i] = 'J' ) then
        RetVal[i] := '2'
      else if( RetVal[i] = 'F' ) then
        RetVal[i] := '3'
      else if( RetVal[i] = 'D' ) then
        RetVal[i] := '4'
      else if( RetVal[i] = 'U' ) then
        RetVal[i] := '5'
      else if( RetVal[i] = 'N' ) then
        RetVal[i] := '6'
      else if( RetVal[i] = 'T' ) then
        RetVal[i] := '7'
      else if( RetVal[i] = 'E' ) then
        RetVal[i] := '8'
      else if( RetVal[i] = 'R' ) then
        RetVal[i] := '9'
      else if( RetVal[i] = 'W' ) then
        RetVal[i] := '0';
    end;
  end;
  result := RetVal;
end;

begin
write('Reg code: ');
if (length(paramstr(1))=10) then reg:=paramstr(1) else readln(reg);
writeln('         ',reg);
Val(UnscrambleHashCode(reg),code,ta);
key:=nonsensenumber mod code;
str(key,keystr);
write('     Key: ',keystr); readln;
end.
